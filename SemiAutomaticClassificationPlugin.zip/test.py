# -*- coding: utf-8 -*-
import numpy as np
from PyQt4.QtCore import QDataStream,QFile,QTextCodec
from PyQt4.QtGui import QImage,QPixmap
import cv2
from PIL import Image
import codecs
from PyQt4 import QtCore
import chardet
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

path = "C:/Users/lenovo/Desktop/Test_Data0415_测试/WYD/First/firstTraining_new.csv"
print(chardet.detect(path))
test_myText = unicode(path, 'gb2312', 'ignore')
print str(path)
c_path = codecs.decode(path,'utf-8')
g_path = c_path.encode('utf-8')
print g_path
# local_path = QtCore.QString.fromLocal8Bit(path)
# c_path = codecs.decode(path,'utf-8')
# u_path = unicode(c_path)
# print u_path
# q_path = QtCore.QString(u_path)
# print q_path
# s_u_path = u_path.encode('utf-8')
# print s_u_path



# path = "C:/Users/lenovo/.qgis2/python/plugins/SemiAutomaticClassificationPlugin/ui/icons/fromGIStoRS1.png"
# image = QFile(path)
# image.open(QFile.ReadOnly)
# img = cv2.imread(path)
# img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
# x = img.shape[1]
# y = img.shape[0]
# frame = QImage(img, x, y, QImage.Format_RGB888)
# image=QPixmap(frame)
#
#
#
# a = QDataStream(image)
# i_a = a.readInt32()
# print i_a



# qwebchannel_js = QtCore.QFile('://qtwebchannel/qwebchannel.js')
#             if qwebchannel_js.open(QtCore.QFile.ReadOnly):
# a = np.asarray([[0.1,0.2,0.3],[0.4,0.2,0.6],[0.7,0.8,0.9]])
# def convert_percent(a):
#     a_cc = a.copy()
#     a_cc = a_cc.astype(np.str)
#     for i in range(0,a.shape[0]):
#         for j in range(0,a.shape[1]):
#             c =  ("{:.2%}".format(a[i][j]))
#             a_cc[i][j] = c
#     return a_cc




