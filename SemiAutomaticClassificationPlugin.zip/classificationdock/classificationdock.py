# -*- coding: utf-8 -*-
from qgis.gui import *
from PyQt4.QtGui import *
from PyQt4 import QtGui
from PyQt4.QtCore import Qt

cfg = __import__(str(__name__).split(".")[0] + ".core.config", fromlist=[''])


class ClassificationDock:
    def __init__(self):
        # rubber band
        cfg.rbbrBnd = QgsRubberBand(cfg.cnvs)
        cfg.rbbrBnd.setColor(cfg.QtGuiSCP.QColor(0, 255, 255))
        cfg.rbbrBnd.setWidth(2)

################random select varibles####################



