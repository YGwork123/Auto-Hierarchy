# -*- coding: utf-8 -*-
"""
/**************************************************************************************************************************
 SemiAutomaticClassificationPlugin

 The Semi-Automatic Classification Plugin for QGIS allows for the supervised classification of remote sensing images, 
 providing tools for the download, the preprocessing and postprocessing of images.

							 -------------------
		begin				: 2012-12-29
		copyright			: (C) 2012-2017 by Luca Congedo
		email				: ing.congedoluca@gmail.com
**************************************************************************************************************************/
 
/**************************************************************************************************************************
 *
 * This file is part of Semi-Automatic Classification Plugin
 * 
 * Semi-Automatic Classification Plugin is free software: you can redistribute it and/or modify it under 
 * the terms of the GNU General Public License as published by the Free Software Foundation, 
 * version 3 of the License.
 * 
 * Semi-Automatic Classification Plugin is distributed in the hope that it will be useful, 
 * but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or 
 * FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along with 
 * Semi-Automatic Classification Plugin. If not, see <http://www.gnu.org/licenses/>. 
 * 
**************************************************************************************************************************/

"""

from PyQt4 import QtGui
from qgis.core import *
from qgis.gui import *
# from PyQt4 import QtGui, uic,QtCore
from PyQt4.QtCore import *
from PyQt4.QtGui import *
# from qgis.analysis import *
import numpy as np
# import os
import pandas as pd
import shapefile
from osgeo import ogr
import os
import re
import math
from sklearn.ensemble import RandomForestClassifier
# import csv
from qgis.analysis import *
from SemiAutomaticClassificationPlugin.accuary_access.raster_handling import *
from SemiAutomaticClassificationPlugin.accuary_access.error_matrix import *
import csv, itertools, sys
from osgeo import gdal
from sklearn.metrics import confusion_matrix
import itertools
from sklearn.svm import SVC
import codecs
from sklearn.impute import SimpleImputer
# import chardet

cfg = __import__(str(__name__).split(".")[0] + ".core.config", fromlist=[''])
# sound for Windows
try:
    import winsound
except:
    pass

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s
try:
    _encoding = QtGui.QApplication.UnicodeUTF8


    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)
########################################分层优化##################################
def kappa(confusion_matrix):
    np.seterr(divide='ignore', invalid='ignore')
    pe_rows = np.sum(confusion_matrix, axis=0)
    pe_cols = np.sum(confusion_matrix, axis=1)
    sum_total = sum(pe_cols)
    pe = np.dot(pe_rows, pe_cols) / float(sum_total ** 2)
    po = np.trace(confusion_matrix) / float(sum_total)
    return (po - pe) / (1 - pe)
def determine_every_node_varibles_name(node_varibles,verify_varibles,training_nodes,verify_nodes):
    np.seterr(divide='ignore', invalid='ignore')
    selected_everynode_varible_num = []
    for i in range(0,len(training_nodes)):
        current_OA_array = []
        for varible_id in range(2,node_varibles[i].shape[1]):
            current_training_varibles = node_varibles[i].iloc[:,0:varible_id]
            current_training_class = training_nodes[i].iloc[:,1]
            current_rf_modle = RandomForestClassifier(n_estimators=2000, random_state=0, n_jobs=-1)
            current_rf_modle.fit(current_training_varibles, current_training_class)
            current_true_class = verify_nodes[i].iloc[:,1]
            current_predict_class = current_rf_modle.predict(verify_varibles[i].iloc[:,0:varible_id])
            true_num = 0
            for j in range(0,len(current_true_class)):
                if current_true_class[j] == current_predict_class[j]:
                    true_num = true_num + 1
            current_OA = float(true_num)/len(current_true_class)
            current_OA_array.append(round(current_OA,4))

        current_max_OA = np.max(current_OA_array)
        current_max_OA_id = np.where(current_OA_array==current_max_OA)[0][0]
        selected_everynode_varible_num.append(node_varibles[i].columns[0:(current_max_OA_id+2)])
    return selected_everynode_varible_num
def  rf_select_best_variables_for_op(training_nodes,verify_nodes,sample_path):
    np.seterr(divide='ignore', invalid='ignore')
    test_class_name = []
    varibles_class = split_varibles_class(sample_path)
    url1 =training_nodes[0].copy()
    url2 = verify_nodes[0].copy()
    n = len(training_nodes)
    #x为自变量y为因变量
    node_variables = []
    verify_varibles = []
    for k in range(0, n):
        x, y = training_nodes[k].iloc[:, 2:], training_nodes[k].iloc[:, 1]
        test_class_name.append(y)
        #feat_labels = url1.columns[1:]
        feat_labels = training_nodes[k].columns[2:].values
        # n_estimators：森林中树的数量
        # n_jobs  整数 可选（默认=1） 适合和预测并行运行的作业数，如果为-1，则将作业数设置为核心数
        forest = RandomForestClassifier(n_estimators=2000, random_state=0, n_jobs=-1)
        #forest.fit(x_train, y_train)
        forest.fit(x,y)
        #下面对训练好的随机森林完成重要性评估
        importances = forest.feature_importances_
        #取出除去第一列的所有变量名
        # x_columns = training_nodes[k].columns[1:]
        #argsort函数返回的是数组从小到大的索引值
        #[::-1]表示去除数组中全部元素并按倒序排列，这样的话indices数组里存储的便是数组从大到小的索引值
        indices = np.argsort(importances)[::-1]
        # for f in range(x.shape[1]):
        #     #对于最后需要逆序排序，我认为是做了类似决策树回溯的取值，从叶子收敛
        #     #到根，根部重要程度高于叶子。
        #筛选变量(筛选重要性比较高的变量)
        x_selected_fields = feat_labels[indices[:]]
        x_selected = url1[x_selected_fields]
        #add对变量等级进行重新排序
        selected_varibles_class = varibles_class[indices[:]]
        #用选出来的变量做相关性分析
        person_varibles = np.corrcoef(x_selected,rowvar=0)
        # person_varibles = pearsonr(x_selected)
        # x_selected_test = x_selected.iloc[:,:]
        # x_corref = np.corrcoef(x_selected_test)
        #去除相关性大于0.8的变量
        for i in range(0, len(x_selected_fields)):
            for j in range(0, i):
                if abs(person_varibles[i][j]) > 0.9:
                    if i < j:
                        if x_selected_fields[j] in x_selected.columns.values:
                            x_selected = x_selected.drop(columns=x_selected_fields[j])
                            selected_varibles_class[j] = 0
                    else:
                        if x_selected_fields[i] in x_selected.columns.values:
                            x_selected = x_selected.drop(columns=x_selected_fields[i])
                            selected_varibles_class[i] = 0
        final_selected = x_selected.iloc[:, 0:5].copy()
        selected_for_random = training_nodes[k][final_selected.columns.values].copy()
        verify_selected = verify_nodes[k][final_selected.columns.values].copy()
        node_variables.append(selected_for_random)
        verify_varibles.append(verify_selected)
    return (node_variables,verify_varibles,test_class_name)
################################分层优化#########################################

###############################Auto_Get_A#########################
def get_every_class_varibles(all_varibles, unique_class):
    np.seterr(divide='ignore', invalid='ignore')
    multi_every_class_varibles = []
    n_cols = all_varibles.shape[1]
    varible_for_standized = []
    for i in range(0, len(unique_class)):
        every_class_varibles = all_varibles.loc[all_varibles['class_name'] == unique_class[i], :]
        multi_every_class_varibles.append(every_class_varibles)
    for j in range(0, n_cols - 1):
        varible_for_standized.append([])
        every_varible = all_varibles.iloc[:, j + 1]
        every_varible_min = every_varible.min()
        every_varible_max = every_varible.max()
        varible_for_standized[j].append(every_varible_min)
        varible_for_standized[j].append(every_varible_max)
    return multi_every_class_varibles, varible_for_standized



def standlize_varibles(multi_every_class_varibles, varible_for_standized):
    np.seterr(divide='ignore', invalid='ignore')
    standlize_multi_varibles = []
    conlumns = multi_every_class_varibles[0].columns[1:]
    n_cols = multi_every_class_varibles[0].shape[1]
    for i in range(0, len(multi_every_class_varibles)):
        every_class_varible = np.zeros((multi_every_class_varibles[i].shape[0], n_cols - 1))
        for j in range(0, n_cols - 1):
            for k in range(0, multi_every_class_varibles[i].shape[0]):
                every_class_varible[k][j] = (multi_every_class_varibles[i].iat[k, j + 1] - varible_for_standized[j][
                    0]) / (varible_for_standized[j][1] - varible_for_standized[j][0])
        pd_every_class_varible = pd.DataFrame(every_class_varible)
        pd_every_class_varible.columns = conlumns
        # print pd_every_class_varible
        standlize_multi_varibles.append(pd_every_class_varible)
    return standlize_multi_varibles

def get_varibles_for_z_score(standlize_multi_varibles):
    np.seterr(divide='ignore', invalid='ignore')
    varibles_for_z_score = []
    n_cols = standlize_multi_varibles[0].shape[1]
    for i in range(0, len(standlize_multi_varibles)):
        varibles_for_z_score.append([])
        for j in range(0, n_cols):
            varibles_for_z_score[i].append([])
            every_class_every_varible = standlize_multi_varibles[i].iloc[:, j]
            every_class_every_varible_mean = every_class_every_varible.mean()
            every_class_every_varible_std = every_class_every_varible.std()
            class_count = standlize_multi_varibles[i].shape[0]
            varibles_for_z_score[i][j].append(every_class_every_varible_std)
            varibles_for_z_score[i][j].append(every_class_every_varible_mean)
            varibles_for_z_score[i][j].append(class_count)
    return varibles_for_z_score


def z_score(c1_v1, c2_v1):
    np.seterr(divide='ignore', invalid='ignore')
    z_score = abs((c1_v1[1] - c2_v1[1]) / (np.sqrt((pow(c1_v1[0], 2)) / c1_v1[2] + (pow(c2_v1[0], 2)) / c2_v1[2])))
    return z_score


def calculate_all_z_score(varibles_for_z_score):
    np.seterr(divide='ignore', invalid='ignore')
    all_class_combination_z_score = []
    all_id = -1
    dict_np_all_class_combination_z_score = {}
    # 计算所有的类组合z_score
    all_combinations_ij = itertools.combinations(range(len(varibles_for_z_score)), 2)
    for combination in all_combinations_ij:
        i = combination[0]
        j = combination[1]
        for k in range(0, len(varibles_for_z_score[0])):
            all_class_combination_z_score.append([])
            all_id = all_id + 1
            current_class_z_score = z_score(varibles_for_z_score[i][k], varibles_for_z_score[j][k])
            # current_class_z_score_test = z_score(varibles_for_z_score[0][0], varibles_for_z_score[1][0])
            # print current_class_z_score_test
            all_class_combination_z_score[all_id].append(current_class_z_score)
            all_class_combination_z_score[all_id].append(i)
            all_class_combination_z_score[all_id].append(j)
            all_class_combination_z_score[all_id].append(k)
            dict_np_all_class_combination_z_score[str(i) + '_' + str(j) + '_' + str(k)] = current_class_z_score
    # for i in range(0,len(varibles_for_z_score)):
    #     for j in range(i+1,len(varibles_for_z_score)):
    #         # if i!=j and str(i)+'_'+str(j) not in all_class_combination and :
    np_all_class_combination_z_score = np.asarray(all_class_combination_z_score)
    return np_all_class_combination_z_score, dict_np_all_class_combination_z_score


def find_cluster_class(np_all_class_combination_z_score, dict_np_all_class_combination_z_score, n, last_A):
    np.seterr(divide='ignore', invalid='ignore')
    max_z_score = max(np_all_class_combination_z_score[:, 0])
    max_z_score_id = np.where(np_all_class_combination_z_score[:, 0] == max_z_score)
    max_z_score_id_i = int(np_all_class_combination_z_score[:, 1][max_z_score_id][0])
    max_z_score_id_j = int(np_all_class_combination_z_score[:, 2][max_z_score_id][0])
    max_z_score_id_k = int(np_all_class_combination_z_score[:, 3][max_z_score_id][0])
    every_A = []
    every_A_l = []
    every_A_l.append(max_z_score_id_i)
    every_A_r = []
    every_A_r.append(max_z_score_id_j)
    # 判断剩下的分别分别属于哪一类
    for m in range(0, n):
        if last_A[m] != max_z_score_id_i and last_A[m] != max_z_score_id_j:
            if last_A[m] > max_z_score_id_i:
                z_score_i = dict_np_all_class_combination_z_score[
                    str(max_z_score_id_i) + '_' + str(int(last_A[m])) + '_' + str(max_z_score_id_k)]
            else:
                z_score_i = dict_np_all_class_combination_z_score[
                    str(int(last_A[m])) + '_' + str(max_z_score_id_i) + '_' + str(max_z_score_id_k)]
            if last_A[m] > max_z_score_id_j:
                z_score_j = dict_np_all_class_combination_z_score[
                    str(max_z_score_id_j) + '_' + str(int(last_A[m])) + '_' + str(max_z_score_id_k)]
            else:
                z_score_j = dict_np_all_class_combination_z_score[
                    str(int(last_A[m])) + '_' + str(max_z_score_id_j) + '_' + str(max_z_score_id_k)]
            if z_score_i < z_score_j:
                every_A_l.append(last_A[m])
            else:
                every_A_r.append(last_A[m])
    every_A.append(every_A_l)
    every_A.append(every_A_r)
    # varibles_for_z_score_l = [varibles_for_z_score[x] for x in every_A_l]
    # varibles_for_z_score_r = [varibles_for_z_score[x] for x in every_A_r]
    true_id_l = [float(x) for x in every_A_l]
    true_id_r = [float(x) for x in every_A_r]
    # child_varibles_for_z_score = []
    # child_varibles_for_z_score.append(varibles_for_z_score_l)
    # child_varibles_for_z_score.append(varibles_for_z_score_r)
    pd_all_class_combination_z_score = pd.DataFrame(np_all_class_combination_z_score)
    # 删除区分此次两个聚类核心的所有变量
    child_np_all_class_combination_z_score = pd_all_class_combination_z_score.drop(pd_all_class_combination_z_score.loc[
                                                                                       (
                                                                                           ~pd_all_class_combination_z_score.iloc[
                                                                                            :, 1].isin(
                                                                                               [max_z_score_id_i])) & (
                                                                                           ~pd_all_class_combination_z_score.iloc[
                                                                                            :, 2].isin([
                                                                                                           max_z_score_id_j]))]).reset_index(
        drop=True)
    child_np_all_class_combination_z_score = child_np_all_class_combination_z_score.drop(
        child_np_all_class_combination_z_score.loc[
            (~child_np_all_class_combination_z_score.iloc[:, 1].isin([max_z_score_id_j])) & (
                ~child_np_all_class_combination_z_score.iloc[:, 2].isin([max_z_score_id_i]))]).reset_index(drop=True)
    # 去除左右子节点分别对应的z_score
    # print (child_np_all_class_combination_z_score.loc[(~child_np_all_class_combination_z_score.iloc[:,1].isin([max_z_score_id_j])) & (~child_np_all_class_combination_z_score.iloc[:,2].isin([max_z_score_id_i]))])

    child_np_all_class_combination_z_score_left = child_np_all_class_combination_z_score.loc[~(
                (child_np_all_class_combination_z_score.iloc[:, 1].isin(true_id_r)) | (
            child_np_all_class_combination_z_score.iloc[:, 2].isin(true_id_r)))].reset_index(drop=True)
    child_np_all_class_combination_z_score_right = child_np_all_class_combination_z_score.loc[~(
                (child_np_all_class_combination_z_score.iloc[:, 1].isin(true_id_l)) | (
            child_np_all_class_combination_z_score.iloc[:, 2].isin(true_id_l)))].reset_index(drop=True)
    # child_np_all_class_combination_z_score_right = child_np_all_class_combination_z_score.loc[(~child_np_all_class_combination_z_score.iloc[:,1].isin(true_id_l)) | (~child_np_all_class_combination_z_score.iloc[:,2].isin(true_id_l))].reset_index(drop=True)
    return every_A, child_np_all_class_combination_z_score_left, child_np_all_class_combination_z_score_right


def auto_hierarchy_class(np_all_class_combination_z_score, dict_np_all_class_combination_z_score):
    np.seterr(divide='ignore', invalid='ignore')
    A = []
    stack = []
    stack.append(np_all_class_combination_z_score)
    while stack != []:
        current_np_all_class_combination_z_score = stack.pop(-1)
        n = len(np.unique(current_np_all_class_combination_z_score[:, 1])) + 1
        current_A_L = np.unique(current_np_all_class_combination_z_score[:, 1])
        current_A_R = np.unique(current_np_all_class_combination_z_score[:, 2])
        current_A = np.unique(np.concatenate((current_A_L, current_A_R), axis=0))
        if n == 2:
            A.append(np.asarray([np.unique(current_np_all_class_combination_z_score[:, 1])[0]], dtype=int))
        else:
            every_A, child_np_all_class_combination_z_score_left, child_np_all_class_combination_z_score_right = find_cluster_class(
                current_np_all_class_combination_z_score, dict_np_all_class_combination_z_score, n, current_A)
            n_l = every_A[0]
            A.append(np.asarray(n_l, dtype=int))
            n_r = every_A[1]
            if len(n_l) >= 2:
                stack.append(child_np_all_class_combination_z_score_left.to_numpy(dtype=float))
            if len(n_r) >= 2:
                stack.append(child_np_all_class_combination_z_score_right.to_numpy(dtype=float))
    return A


#############################Auto_Get_A##############################################################################


#######################RF_Classify##################
def total_random_forest_classify_with_verify(classifier_id,totalShp,openSamplePath,unique_all_varibles,split_value):
    np.seterr(divide='ignore', invalid='ignore')
    sample_varibles = self_read_csv(openSamplePath)
    class_name = sample_varibles.loc[:,['class_name']]
    class_name =  np.unique(class_name)
    columns = sample_varibles.columns.values.tolist()
    all_random_train_varibles =None
    all_random_verify_varibles = None

    for i in range(0, len(class_name)):
        every_class_varibles = sample_varibles.loc[sample_varibles['class_name'] == class_name[i], :]
        random_every_class_varibles_values = np.random.permutation(every_class_varibles.values)
        split_break = int(every_class_varibles.shape[0]*split_value)
        pd_random_every_class_varibles_values = pd.DataFrame(random_every_class_varibles_values)
        pd_random_every_class_varibles_values.columns = columns
        if split_break < every_class_varibles.shape[0]:
            every_train_varible_train = pd_random_every_class_varibles_values.iloc[0:split_break,:]
            every_class_varibles_verify = pd_random_every_class_varibles_values.iloc[split_break:every_class_varibles.shape[0],:]
        else:
            every_train_varible_train = pd_random_every_class_varibles_values
            every_class_varibles_verify = None
        all_random_train_varibles  = pd.concat([all_random_train_varibles,every_train_varible_train],axis=0,ignore_index=True)
        all_random_verify_varibles = pd.concat([all_random_verify_varibles,every_class_varibles_verify],axis=0,ignore_index=True)
    y_train = all_random_train_varibles.loc[:,'class_name']
    x_train = all_random_train_varibles.loc[:,unique_all_varibles]
    y_verify = all_random_verify_varibles.loc[:,'class_name'].values
    x_verify = all_random_verify_varibles.loc[:,unique_all_varibles]

    totalShp_varibles = totalShp.loc[:,unique_all_varibles]
    totalShp_varibles.replace([np.inf, -np.inf], np.nan, inplace=True)
    totalShp_varibles.fillna(0,inplace=True)
    if classifier_id ==0:
        forest = SVC(C=0.4,gamma='scale',kernel='rbf')
        pass
    else:
        forest = RandomForestClassifier(class_weight='balanced', n_estimators=500, random_state=0, n_jobs=-1)
    forest.fit(x_train, y_train)
    class_verify = forest.predict(x_verify)
    class_result = forest.predict(totalShp_varibles)

    return class_result, class_verify,y_verify,class_name

def total_random_forest_classify(classifier_id,totalShp,openSamplePath,unique_all_varibles):
    np.seterr(divide='ignore', invalid='ignore')
    sample_varibles = self_read_csv(openSamplePath)
    class_name = sample_varibles.loc[:,['class_name']]
    class_name =  np.unique(class_name)
    columns = sample_varibles.columns.values.tolist()
    all_random_train_varibles =None

    for i in range(0, len(class_name)):
        every_class_varibles = sample_varibles.loc[sample_varibles['class_name'] == class_name[i], :]
        random_every_class_varibles_values = np.random.permutation(every_class_varibles.values)
        pd_random_every_class_varibles_values = pd.DataFrame(random_every_class_varibles_values)
        pd_random_every_class_varibles_values.columns = columns
        all_random_train_varibles  = pd.concat([all_random_train_varibles,pd_random_every_class_varibles_values],axis=0,ignore_index=True)
    y_train = all_random_train_varibles.loc[:,'class_name']
    x_train = all_random_train_varibles.loc[:,unique_all_varibles]

    totalShp_varibles = totalShp.loc[:,unique_all_varibles]
    totalShp_varibles.replace([np.inf, -np.inf], np.nan, inplace=True)
    totalShp_varibles.fillna(0,inplace=True)
    if classifier_id ==0:
        forest = SVC(C=0.4,gamma='scale',kernel='rbf')
        pass
    else:
        forest = RandomForestClassifier(class_weight='balanced', n_estimators=1000, random_state=0, n_jobs=-1)
    forest.fit(x_train, y_train)
    class_result = forest.predict(totalShp_varibles)

    return class_result


def every_node_randomforest_class(classifier_id,i, last_node_digit, totalShp, node_varibles,child_node_indicies,class_result,totalShp_copy,isChild,nodes):
    np.seterr(divide='ignore', invalid='ignore')
    x = None
    y = None
    y = nodes.iloc[:,1]
    x = node_varibles[i]
    if i == 0:
        #当i=0时，取出整个totalshp
        totalShpNodeVaribles = totalShp.loc[:, node_varibles[i].columns]
    else:
        if isChild != False:

            totalShpNodeVaribles = totalShp.loc[child_node_indicies, node_varibles[i].columns].reset_index(drop=True)
            totalShp = totalShp.loc[child_node_indicies, :].reset_index(drop=True)
        else:
            #如果该节点不为上一个节点的子节点，则根据从原始totalshp
            totalShpNodeVaribles = totalShp_copy.loc[child_node_indicies, node_varibles[i].columns].reset_index(drop=True)
            totalShp = totalShp_copy.loc[child_node_indicies, :].reset_index(drop=True)
    if classifier_id ==0:
        forest = SVC(C=0.4,gamma='scale',kernel='rbf')
        pass
    else:
        forest = RandomForestClassifier(class_weight='balanced', n_estimators=1000, random_state=0, n_jobs=-1)
    forest.fit(x,y)
    imp = SimpleImputer(missing_values=np.nan, strategy='mean')
    imp = imp.fit(totalShpNodeVaribles)
    # Impute our data, then train
    imp_totalShpNodeVaribles = imp.transform(totalShpNodeVaribles)
    class_n = forest.predict(imp_totalShpNodeVaribles)
    forest = None
    if i == 0:
        class_result = class_n
    else:
        j = 0
        for k in range(0,len(class_result)):
            if class_result[k] == last_node_digit[i]:
                class_result[k] = class_n[j]
                j = j + 1
    child_node_indicies = None
    if i + 1 < len(last_node_digit):
        child_node_indicies = np.where(class_n == last_node_digit[i+1])[0]
        if len(child_node_indicies) == 0:
            a = last_node_digit[i+1]
            child_node_indicies = np.where(class_result == last_node_digit[i+1])[0]
            isChild = False
        else:
            isChild = True
    class_n = None
    return class_result,child_node_indicies,totalShp,isChild


def every_node_randomforest_class_with_verify(classifier_id,i, last_node_digit, totalShp, node_varibles, verify_shp, verify_shp_vopy,
                                              verify_child_indicies, verify_class_result, child_node_indicies,
                                              class_result, totalShp_copy, isChild, test_class_name):
    np.seterr(divide='ignore', invalid='ignore')
    x = None
    y = None
    y = test_class_name.iloc[:,1]
    x = node_varibles[i]
    if i == 0:
        # 当i=0时，取出整个totalshp
        totalShpNodeVaribles = totalShp.loc[:, node_varibles[i].columns]
        verifyShpNodeVaribles = verify_shp.loc[:, node_varibles[i].columns]
    else:
        if isChild != False:

            totalShpNodeVaribles = totalShp.loc[child_node_indicies, node_varibles[i].columns].reset_index(drop=True)
            totalShp = totalShp.loc[child_node_indicies, :].reset_index(drop=True)
            verifyShpNodeVaribles = verify_shp.loc[verify_child_indicies, node_varibles[i].columns].reset_index(
                drop=True)
            verify_shp = verify_shp.loc[verify_child_indicies, :].reset_index(drop=True)
        else:
            # 如果该节点不为上一个节点的子节点，则根据从原始totalshp
            totalShpNodeVaribles = totalShp_copy.loc[child_node_indicies, node_varibles[i].columns].reset_index(
                drop=True)
            totalShp = totalShp_copy.loc[child_node_indicies, :].reset_index(drop=True)
            verifyShpNodeVaribles = verify_shp_vopy.loc[verify_child_indicies, node_varibles[i].columns].reset_index(
                drop=True)
            verify_shp = verify_shp_vopy.loc[verify_child_indicies, :].reset_index(drop=True)
    # n_jobs  整数 可选（默认=1） 适合和预测并行运行的作业数，如果为-1，则将作业数设置为核心数
    if classifier_id ==0:
        forest = SVC(C=0.4,gamma='scale',kernel='rbf')
        pass
    else:
        forest = RandomForestClassifier(class_weight='balanced', n_estimators=1000, random_state=0, n_jobs=-1)
    forest.fit(x, y)
    class_n = forest.predict(totalShpNodeVaribles)
    # print totalShpNodeVaribles
    # print verifyShpNodeVaribles
    verify_class_n = None
    verify_class_n = forest.predict(verifyShpNodeVaribles)
    forest = None
    if i == 0:
        class_result = class_n
        verify_class_result = verify_class_n
    else:
        j = 0
        m = 0
        for k in range(0, len(class_result)):
            if class_result[k] == last_node_digit[i]:
                class_result[k] = class_n[j]
                j = j + 1
        for k in range(0, len(verify_class_result)):
            if verify_class_result[k] == last_node_digit[i]:
                verify_class_result[k] = verify_class_n[m]
                m = m + 1
    child_node_indicies = None
    verify_child_indicies = None
    if i + 1 < len(last_node_digit):
        child_node_indicies = np.where(class_n == last_node_digit[i + 1])[0]
        verify_child_indicies = np.where(verify_class_n == last_node_digit[i + 1])[0]
        if len(child_node_indicies) == 0:
            a = last_node_digit[i + 1]
            child_node_indicies = np.where(class_result == last_node_digit[i + 1])[0]
            verify_child_indicies = np.where(verify_class_result == last_node_digit[i + 1])[0]
            isChild = False
        else:
            isChild = True
    class_n = None
    return class_result, child_node_indicies, totalShp, isChild, verify_class_result, verify_child_indicies, verify_shp


################################RF_Classify#############################################################

def self_read_csv(path):
    result = []
    b = csv.reader(open(path))
    # conlumn_values = next(b)
    # print conlumn_values
    # print b
    for row in b:
        conlumn_values = row
        break
    for row in b:
        result.append(row)
    pd_result = pd.DataFrame(result, dtype=float)
    pd_result.columns = conlumn_values
    return pd_result


def read_shp_to_pd(file_path):
    total_shp = shapefile.Reader(file_path)
    fields = total_shp.fields
    records = total_shp.records()
    # print(records)
    pd_records = pd.DataFrame(records)
    pd_fields = pd.DataFrame(fields)
    shp_columns = pd_fields.iloc[1:, 0].values.tolist()
    # print(shp_columns)
    pd_records.columns = shp_columns
    return pd_records


def read_shpaefile(path, class_result):
    gdal.SetConfigOption("GDAL_FILENAME_IS_UTF8", "NO")
    gdal.SetConfigOption("SHAPE_ENCODING", "")
    ogr.RegisterAll()
    driver = ogr.GetDriverByName('ESRI Shapefile')
    ds = driver.Open(path, 1)
    shp_layer = ds.GetLayer(0)
    fieldDefn = ogr.FieldDefn('class_res', ogr.OFTInteger)
    shp_layer.CreateField(fieldDefn)
    # defn = shp_layer.GetLayerDefn()
    # iFieldCount = defn.GetFieldCount()
    feature = shp_layer.GetNextFeature()
    i = 0
    while feature is not None:
        # print feature.GetFID()
        # feature.SetField("class_res", class_result[i, 0])
        feature.SetField("class_res", i + 1)
        # print feature.GetFieldAsInteger("result4")
        shp_layer.SetFeature(feature)
        feature.Destroy()
        feature = shp_layer.GetNextFeature()
        i = i + 1
    # for index in range(iFieldCount):
    #     oField = defn.GetFieldDefn(index)
    #     print('%s: %s(%d.%d)' % (
    #         oField.GetNameRef(), oField.GetFieldTypeName(oField.GetType()), oField.GetWidth(), oField.GetPrecision()))
    return shp_layer


def save_shape_rf(class_result, inShapefile, outShapefile):
    ogr.RegisterAll()
    gdal.SetConfigOption("GDAL_FILENAME_IS_UTF8", "NO")
    gdal.SetConfigOption("SHAPE_ENCODING", "")
    # gdal.GetConfigOption()

    inDriver = ogr.GetDriverByName("ESRI Shapefile")
    inDataSource = inDriver.Open(inShapefile, 0)
    inLayer = inDataSource.GetLayer()
    # inLayer.SetAttributeFilter("minor = 'HYDR'")

    # Create the output LayerS
    outDriver = ogr.GetDriverByName("ESRI Shapefile")

    # Remove output shapefile if it already exists
    if os.path.exists(outShapefile):
        outDriver.DeleteDataSource(outShapefile)

    # Create the output shapefile
    outDataSource = outDriver.CreateDataSource(outShapefile)
    out_lyr_name = os.path.split(os.path.split(outShapefile)[1])[0]
    out_lyr_name = str(out_lyr_name)
    outLayer = outDataSource.CreateLayer(out_lyr_name, srs=inLayer.GetSpatialRef(), geom_type=ogr.wkbMultiPolygon)

    # Get the output Layer's Feature Definition
    fieldDefn = ogr.FieldDefn('class_res', ogr.OFTInteger)
    outLayer.CreateField(fieldDefn)
    outLayerDefn = outLayer.GetLayerDefn()

    # Add features to the ouput Layer
    i = 0
    for inFeature in inLayer:
        # Create output Feature
        outFeature = ogr.Feature(outLayerDefn)

        # Set geometry as centroid
        # geom = inFeature.GetGeometryRef()
        geom = inFeature.geometry()
        outFeature.SetGeometry(geom.Clone())
        outFeature.SetField("class_res", class_result[i])
        i = i + 1
        # Add new feature to output Layer
        outLayer.CreateFeature(outFeature)
        outFeature = None
    outDataSource = None
    # Save and close DataSources
    inDataSource = None
    out_ds = None
    return 0


def save_shape(class_result, inShapefile, outShapefile):
    gdal.SetConfigOption("GDAL_FILENAME_IS_UTF8", "NO")
    gdal.SetConfigOption("SHAPE_ENCODING", "")
    ogr.RegisterAll()
    inDriver = ogr.GetDriverByName("ESRI Shapefile")
    inDataSource = inDriver.Open(inShapefile, 0)
    inLayer = inDataSource.GetLayer()
    # inLayer.SetAttributeFilter("minor = 'HYDR'")

    # Create the output LayerS
    # outShapefile = os.path.join( os.path.split( inShapefile )[0], "ogr_api_filter.shp" )
    outDriver = ogr.GetDriverByName("ESRI Shapefile")

    # Remove output shapefile if it already exists
    if os.path.exists(outShapefile):
        outDriver.DeleteDataSource(outShapefile)

    # Create the output shapefile
    outDataSource = outDriver.CreateDataSource(outShapefile)
    # outDataSource.SetProjection(inDataSource.GetProjection())
    # outDataSource.SetGeoTransform(inDataSource.GetTransform())
    out_lyr_name = os.path.split(outShapefile)[1].split('.')[0]
    out_lyr_name = str(out_lyr_name)
    outLayer = outDataSource.CreateLayer(out_lyr_name, srs=inLayer.GetSpatialRef(), geom_type=ogr.wkbMultiPolygon)
    # out_lyr_name
    # Add input Layer Fields to the output Layer if it is the one we want
    # inLayerDefn = inLayer.GetLayerDefn()
    # for i in range(0, inLayerDefn.GetFieldCount()):
    #     fieldDefn = inLayerDefn.GetFieldDefn(i)
    #     fieldName = fieldDefn.GetName()
    #     if fieldName not in field_name_target:
    #         continue
    #     outLayer.CreateField(fieldDefn)

    # Get the output Layer's Feature Definition
    fieldDefn = ogr.FieldDefn('class_res', ogr.OFTInteger)
    outLayer.CreateField(fieldDefn)
    outLayerDefn = outLayer.GetLayerDefn()

    # Add features to the ouput Layer
    i = 0
    for inFeature in inLayer:
        # Create output Feature
        outFeature = ogr.Feature(outLayerDefn)
        geom = inFeature.geometry()
        outFeature.SetGeometry(geom.Clone())
        outFeature.SetField("class_res", class_result[i, 0])
        i = i + 1
        # Add new feature to output Layer
        outLayer.CreateFeature(outFeature)
        outFeature = None

    outDataSource = None
    inDataSource = None
    out_ds = None
    return 0


def every_node_sample(n, B, nrow, node):
    for i in range(0, nrow):
        if node.iat[i, 0] in B:
            node.iat[i, 1] = (n + 1) * 10 + 1
        else:
            node.iat[i, 1] = (n + 1) * 10 + 2
    new_node_z = node.loc[node['class_split'] == (n + 1) * 10 + 1, :].copy()
    new_node_y = node.loc[node['class_split'] == (n + 1) * 10 + 2, :].copy()
    new_nodes = (new_node_z, new_node_y, node)
    return new_nodes


def is_include(a, A):
    for i in range(0, len(a)):
        if a[i] not in A:
            return False
    return True


def split_varibles_class(sample_path):
    np.seterr(divide='ignore', invalid='ignore')
    url1 = self_read_csv(sample_path)
    varibles_class = url1.iloc[0, 1:].values
    return varibles_class


def pub_split_nodes(sample_path, n, A):
    np.seterr(divide='ignore', invalid='ignore')
    url1 = self_read_csv(sample_path)
    node1 = url1.copy()
    node1.insert(1, 'class_split', 0)
    nodes = []
    # nodes_indicat = np.zeros([n],dtype = int)
    # nodes_indicat[0] = 1
    # judge_tree = TreeNode(np.unique(node1.iloc[:,0].values))
    # start_judge_tree = judge_tree
    # judge_tree.be_travel = True
    istravel = np.zeros((n, 2), dtype=np.int)
    for i in range(1, n + 1):
        new_node_z = every_node_sample(i, A[i - 1], node1.shape[0], node1)[0].copy()
        new_node_y = every_node_sample(i, A[i - 1], node1.shape[0], node1)[1].copy()
        node1 = every_node_sample(i, A[i - 1], node1.shape[0], node1)[2].copy()
        nodes.append(node1.copy())
        if is_include(A[i - 1], np.unique(new_node_z.iloc[:, 0].values)):
            if (i < n):
                if is_include(A[i], np.unique(new_node_z.iloc[:, 0].values)):
                    node1 = new_node_z.copy()
                    istravel[i - 1][0] = 1
                else:
                    j = 0
                    while (j < i):
                        if istravel[j][0] == 0 and is_include(A[i], np.unique(
                                nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, :].copy()
                            istravel[j][0] = 1
                            break
                        elif istravel[j][1] == 0 and is_include(A[i], np.unique(
                                nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, :].copy()
                            istravel[j][1] = 1
                            break
                        j = j + 1
        # nodes_indicat[i] = 1
        # judge_tree.left.be_travel = True
        # judge_tree = judge_tree.left
        elif is_include(A[i - 1], np.unique(new_node_y.iloc[:, 0].values)):
            # 判断是否为叶子结点
            if (i < n):
                if is_include(A[i], np.unique(new_node_y.iloc[:, 0].values)):
                    node1 = new_node_y.copy()
                    istravel[i][1] = 0
                else:
                    j = 0
                    while (j < i):
                        if istravel[j][0] == 0 and is_include(A[i], np.unique(
                                nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, :].copy()
                            istravel[j][0] = 1
                            break
                        elif istravel[j][1] == 0 and is_include(A[i], np.unique(
                                nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, :].copy()
                            istravel[j][1] = 1
                            break
                        j = j + 1
    return nodes

def hierarchy_class_sample(pd_node_z,split_value):
    np.seterr(divide='ignore', invalid='ignore')
    class_name_z = np.unique(pd_node_z.loc[:,'class_name'])
    all_class_training = None
    all_class_verify = None
    for i in range(0,len(class_name_z)):
        every_class_pd = pd_node_z.loc[pd_node_z['class_name'] == class_name_z[i],:]
        split_break = int(every_class_pd.shape[0]*float(split_value))
        every_class_training = every_class_pd.iloc[0:split_break,:]
        every_class_verify = every_class_pd.iloc[split_break+1:every_class_pd.shape[0],:]
        all_class_training = pd.concat([all_class_training, every_class_training], axis=0, ignore_index=True)
        all_class_verify = pd.concat([all_class_verify,every_class_verify],axis=0,ignore_index=True)
    return all_class_training,all_class_verify

def split_samples(sample_path, n, A,split_value):
    np.seterr(divide='ignore', invalid='ignore')
    nodes = pub_split_nodes(sample_path, n, A)
    traning_samples = []
    verify_samples = []
    node_columns = nodes[0].columns
    for i in range(0, n):
        np_node = nodes[i].values
        pd_node = np.random.permutation(np_node)
        pd_node = pd.DataFrame(pd_node)
        pd_node.columns = node_columns
        pd_node[['class_name', 'class_split']] = pd_node[['class_name', 'class_split']].astype(int)
        ###########################add###############################
        pd_node_z = pd_node.loc[pd_node['class_split'] == (i + 2) * 10 + 1, :]
        pd_node_y = pd_node.loc[pd_node['class_split'] == (i + 2) * 10 + 2, :]
        # split_break_z = int(pd_node_z.shape[0] * 0.7)
        # split_break_y = int(pd_node_y.shape[0] * 0.7)
        # traning_node_z = pd_node_z.iloc[0:split_break_z, :]
        # traning_node_y = pd_node_y.iloc[0:split_break_y, :]
        # verify_sample_z = pd_node_z.iloc[split_break_z:pd_node_z.shape[0], :]
        # verify_sample_y = pd_node_y.iloc[split_break_y:pd_node_y.shape[0], :]
        # df_training = pd.concat([traning_node_z, traning_node_y], axis=0, ignore_index=True)
        # df_verify = pd.concat([verify_sample_z, verify_sample_y], axis=0, ignore_index=True)
        (traning_node_z_new,verify_node_z_new) = hierarchy_class_sample(pd_node_z,split_value)
        (traning_node_y_new,verify_node_y_new) = hierarchy_class_sample(pd_node_y,split_value)
        df_training = pd.concat([traning_node_z_new, traning_node_y_new], axis=0, ignore_index=True)
        df_verify = pd.concat([verify_node_z_new, verify_node_y_new], axis=0, ignore_index=True)
        ###########################add###############################
        # split_break = int(nodes[i].shape[0]*0.7)
        # traning_node = pd_node.iloc[0:split_break, :]
        # traning_samples.append(traning_node)
        # verify_samples.append(pd_node.iloc[split_break:nodes[i].shape[0], :])
        traning_samples.append(df_training)
        verify_samples.append(df_verify)
    return (traning_samples, verify_samples)
def split_samples_for_op(nodes,split_value):
    np.seterr(divide='ignore', invalid='ignore')
    traning_samples = []
    verify_samples = []
    n = len(nodes)
    node_columns = nodes[0].columns
    for i in range(0, n):
        np_node = nodes[i].values
        pd_node = np.random.permutation(np_node)
        pd_node = pd.DataFrame(pd_node)
        pd_node.columns = node_columns
        pd_node[['class_name', 'class_split']] = pd_node[['class_name', 'class_split']].astype(int)
        ###########################add###############################
        pd_node_z = pd_node.loc[pd_node['class_split'] == (i + 2) * 10 + 1, :]
        pd_node_y = pd_node.loc[pd_node['class_split'] == (i + 2) * 10 + 2, :]
        # split_break_z = int(pd_node_z.shape[0] * 0.7)
        # split_break_y = int(pd_node_y.shape[0] * 0.7)
        # traning_node_z = pd_node_z.iloc[0:split_break_z, :]
        # traning_node_y = pd_node_y.iloc[0:split_break_y, :]
        # verify_sample_z = pd_node_z.iloc[split_break_z:pd_node_z.shape[0], :]
        # verify_sample_y = pd_node_y.iloc[split_break_y:pd_node_y.shape[0], :]
        # df_training = pd.concat([traning_node_z, traning_node_y], axis=0, ignore_index=True)
        # df_verify = pd.concat([verify_sample_z, verify_sample_y], axis=0, ignore_index=True)
        (traning_node_z_new,verify_node_z_new) = hierarchy_class_sample(pd_node_z,split_value)
        (traning_node_y_new,verify_node_y_new) = hierarchy_class_sample(pd_node_y,split_value)
        df_training = pd.concat([traning_node_z_new, traning_node_y_new], axis=0, ignore_index=True)
        df_verify = pd.concat([verify_node_z_new, verify_node_y_new], axis=0, ignore_index=True)
        ###########################add###############################
        # split_break = int(nodes[i].shape[0]*0.7)
        # traning_node = pd_node.iloc[0:split_break, :]
        # traning_samples.append(traning_node)
        # verify_samples.append(pd_node.iloc[split_break:nodes[i].shape[0], :])
        traning_samples.append(df_training)
        verify_samples.append(df_verify)
    return (traning_samples, verify_samples)


def get_class_modle(button, A):
    np.seterr(divide='ignore', invalid='ignore')
    if button.left_button != None and button.is_find == 0:
        A.append(button.left_button.class_list)
        button.is_find = 1
        if button.left_button.left_button != None:
            get_class_modle(button.left_button)
        if button.right_button.left_button != None:
            get_class_modle(button.right_button)


def get_lastnodes(sample_path, n, A):
    np.seterr(divide='ignore', invalid='ignore')
    url1 = self_read_csv(sample_path)
    node1 = url1.copy()
    node1.insert(1, 'class_split', 0)
    nodes = []
    lastnodes = np.zeros([n], dtype=np.int)
    istravel = np.zeros((n, 2), dtype=np.int)
    for i in range(1, n + 1):
        new_node_z = every_node_sample(i, A[i - 1], node1.shape[0], node1)[0].copy()
        new_node_y = every_node_sample(i, A[i - 1], node1.shape[0], node1)[1].copy()
        node1 = every_node_sample(i, A[i - 1], node1.shape[0], node1)[2].copy()
        nodes.append(node1.copy())
        if is_include(A[i - 1], np.unique(new_node_z.iloc[:, 0].values)):
            if (i < n):
                if is_include(A[i], np.unique(new_node_z.iloc[:, 0].values)):
                    node1 = new_node_z.copy()
                    istravel[i - 1][0] = 1
                    if i > 0 and i < n:
                        lastnodes[i] = (i + 1) * 10 + 1
                else:
                    j = 0
                    while (j < i):
                        if istravel[j][0] == 0 and is_include(A[i], np.unique(
                                nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, :].copy()
                            istravel[j][0] = 1
                            lastnodes[i] = (j + 2) * 10 + 1
                            break
                        elif istravel[j][1] == 0 and is_include(A[i], np.unique(
                                nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, :].copy()
                            istravel[j][1] = 1
                            lastnodes[i] = (j + 2) * 10 + 2
                            break
                        j = j + 1
        elif is_include(A[i - 1], np.unique(new_node_y.iloc[:, 0].values)):
            # 判断是否为叶子结点
            if (i < n):
                if is_include(A[i], np.unique(new_node_y.iloc[:, 0].values)):
                    node1 = new_node_y.copy()
                    istravel[i][1] = 0
                    if i > 0 and i < n:
                        lastnodes[i] = (i + 1) * 10 + 2
                else:
                    j = 0
                    while (j < i):
                        if istravel[j][0] == 0 and is_include(A[i], np.unique(
                                nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, :].copy()
                            istravel[j][0] = 1
                            lastnodes[i] = (j + 2) * 10 + 1
                            break
                        elif istravel[j][1] == 0 and is_include(A[i], np.unique(
                                nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, :].copy()
                            istravel[j][1] = 1
                            lastnodes[i] = (j + 2) * 10 + 2
                            break
                        j = j + 1
    return lastnodes

def all_selected_field(node_varibles):
    np.seterr(divide='ignore', invalid='ignore')
    all_varibles =[]
    for i in range(0,len(node_varibles)):
        all_varibles.append(node_varibles[i].columns)
    np_all_varibles = np.asarray(all_varibles)
    from itertools import chain
    a_a = list(chain.from_iterable(np_all_varibles))
    unique_all_varibles = np.unique(a_a)
    return unique_all_varibles

def rf_select_best_variables(training_nodes, verify_nodes, sample_path):
    np.seterr(divide='ignore', invalid='ignore')
    varibles_class = split_varibles_class(sample_path)
    url1 = training_nodes[0].copy()
    url2 = verify_nodes[0].copy()
    n = len(training_nodes)
    # x为自变量y为因变量
    node_variables = []
    verify_varibles = []
    for k in range(0, n):
        x, y = training_nodes[k].iloc[:, 2:], training_nodes[k].iloc[:, 1]
        # feat_labels = url1.columns[1:]
        feat_labels = training_nodes[k].columns[2:].values
        # n_estimators：森林中树的数量
        # n_jobs  整数 可选（默认=1） 适合和预测并行运行的作业数，如果为-1，则将作业数设置为核心数
        forest = RandomForestClassifier(n_estimators=2000, random_state=0, n_jobs=-1)
        # forest.fit(x_train, y_train)
        forest.fit(x, y)
        # 下面对训练好的随机森林完成重要性评估
        importances = forest.feature_importances_
        # 取出除去第一列的所有变量名
        # x_columns = training_nodes[k].columns[1:]
        # argsort函数返回的是数组从小到大的索引值
        # [::-1]表示去除数组中全部元素并按倒序排列，这样的话indices数组里存储的便是数组从大到小的索引值
        indices = np.argsort(importances)[::-1]
        # for f in range(x.shape[1]):
        #     #对于最后需要逆序排序，我认为是做了类似决策树回溯的取值，从叶子收敛
        #     #到根，根部重要程度高于叶子。
        # 筛选变量(筛选重要性比较高的变量)
        x_selected_fields = feat_labels[indices[:]]
        x_selected = url1[x_selected_fields]
        # add对变量等级进行重新排序
        selected_varibles_class = varibles_class[indices[:]]
        # 用选出来的变量做相关性分析
        person_varibles = np.corrcoef(x_selected, rowvar=0)
        # person_varibles = pearsonr(x_selected)
        # x_selected_test = x_selected.iloc[:,:]
        # x_corref = np.corrcoef(x_selected_test)
        # 去除相关性大于0.8的变量
        for i in range(0, len(x_selected_fields)):
            for j in range(0, i):
                if abs(person_varibles[i][j]) > 0.9:
                    if i < j:
                        if x_selected_fields[j] in x_selected.columns.values:
                            x_selected = x_selected.drop(columns=x_selected_fields[j])
                            selected_varibles_class[j] = 0
                    else:
                        if x_selected_fields[i] in x_selected.columns.values:
                            x_selected = x_selected.drop(columns=x_selected_fields[i])
                            selected_varibles_class[i] = 0
        final_selected = x_selected.iloc[:,:].copy()
        verify_selected = url2[final_selected.columns.values].copy()
        node_variables.append(final_selected)
        verify_varibles.append(verify_selected)
    return (node_variables, verify_varibles)


def rf_select_variables_for_RF(training_nodes, verify_nodes):
    np.seterr(divide='ignore', invalid='ignore')
    test_class_name = []
    # varibles_class = split_varibles_class(sample_path)
    url1 = training_nodes[0].copy()
    # url2 = verify_nodes[0].copy()
    n = len(training_nodes)
    # x为自变量y为因变量
    node_variables = []
    verify_varibles = []
    for k in range(0, n):
        x, y = training_nodes[k].iloc[:, 2:], training_nodes[k].iloc[:, 1]
        test_class_name.append(y)
        # feat_labels = url1.columns[1:]
        feat_labels = training_nodes[k].columns[2:].values
        # n_estimators：森林中树的数量
        # n_jobs  整数 可选（默认=1） 适合和预测并行运行的作业数，如果为-1，则将作业数设置为核心数
        forest = RandomForestClassifier(n_estimators=2000, random_state=0, n_jobs=-1)
        # forest.fit(x_train, y_train)
        forest.fit(x, y)
        # 下面对训练好的随机森林完成重要性评估
        importances = forest.feature_importances_
        # 取出除去第一列的所有变量名
        # x_columns = training_nodes[k].columns[1:]
        # argsort函数返回的是数组从小到大的索引值
        # [::-1]表示去除数组中全部元素并按倒序排列，这样的话indices数组里存储的便是数组从大到小的索引值
        indices = np.argsort(importances)[::-1]
        cfg.uiUtls.updateBar(8)
        #     #对于最后需要逆序排序，我认为是做了类似决策树回溯的取值，从叶子收敛
        #     #到根，根部重要程度高于叶子。
        # 筛选变量(筛选重要性比较高的变量)
        x_selected_fields = feat_labels[indices[:]]
        x_selected = url1[x_selected_fields]
        # add对变量等级进行重新排序
        # selected_varibles_class = varibles_class[indices[:]]
        cfg.uiUtls.updateBar(9)
        # 用选出来的变量做相关性分析
        # QMessageBox.information(None, '', str(feat_labels))
        person_varibles = np.corrcoef(x_selected, rowvar=0)

        # 去除相关性大于0.8的变量
        for i in range(0, len(x_selected_fields)):
            for j in range(0, i):
                if abs(person_varibles[i][j]) > 0.9:
                    if i < j:
                        if x_selected_fields[j] in x_selected.columns.values:
                            x_selected = x_selected.drop(columns=x_selected_fields[j])
                        # selected_varibles_class[j] = 0
                    else:
                        if x_selected_fields[i] in x_selected.columns.values:
                            x_selected = x_selected.drop(columns=x_selected_fields[i])
                        # selected_varibles_class[i] = 0
        final_selected = x_selected.iloc[:, 0:5].copy()
        selected_for_random = training_nodes[k][final_selected.columns.values].copy()
        verify_selected = verify_nodes[k][final_selected.columns.values].copy()
        node_variables.append(selected_for_random)
        verify_varibles.append(verify_selected)
    return (node_variables, verify_varibles, test_class_name)

def  rf_select_best_variables_without_verify(sample_path):
    np.seterr(divide='ignore', invalid='ignore')
    training_nodes = self_read_csv(sample_path)
    url1 =training_nodes.copy()
    #x为自变量y为因变量
    x, y = training_nodes.iloc[:, 1:], training_nodes.iloc[:, 0]
    #feat_labels = url1.columns[1:]
    feat_labels = training_nodes.columns[1:].values
    # n_estimators：森林中树的数量
    # n_jobs  整数 可选（默认=1） 适合和预测并行运行的作业数，如果为-1，则将作业数设置为核心数
    forest = RandomForestClassifier(n_estimators=2000, random_state=0, n_jobs=-1)
    #forest.fit(x_train, y_train)
    forest.fit(x,y)
    #下面对训练好的随机森林完成重要性评估
    importances = forest.feature_importances_
    #argsort函数返回的是数组从小到大的索引值
    #[::-1]表示去除数组中全部元素并按倒序排列，这样的话indices数组里存储的便是数组从大到小的索引值
    indices = np.argsort(importances)[::-1]
    # for f in range(x.shape[1]):
    #     #对于最后需要逆序排序，我认为是做了类似决策树回溯的取值，从叶子收敛
    #     #到根，根部重要程度高于叶子。
    #筛选变量(筛选重要性比较高的变量)
    x_selected_fields = feat_labels[indices[:]]
    x_selected = url1[x_selected_fields]
    #用选出来的变量做相关性分析
    person_varibles = np.corrcoef(x_selected,rowvar=0)
    # person_varibles = pearsonr(x_selected)
    # x_selected_test = x_selected.iloc[:,:]
    # x_corref = np.corrcoef(x_selected_test)
    #去除相关性大于0.8的变量
    for i in range(0, len(x_selected_fields)):
        for j in range(0, i):
            if abs(person_varibles[i][j]) > 0.9:
                if i < j:
                    if x_selected_fields[j] in x_selected.columns.values:
                        x_selected = x_selected.drop(columns=x_selected_fields[j])
                else:
                    if x_selected_fields[i] in x_selected.columns.values:
                        x_selected = x_selected.drop(columns=x_selected_fields[i])
    final_selected = x_selected.iloc[:, :].copy()
    selected_for_random = training_nodes[final_selected.columns.values].copy()
    return selected_for_random


def  rf_select_best_variables_all_nodes(training_nodes,sample_path):
    np.seterr(divide='ignore', invalid='ignore')
    # test_class_name = []
    varibles_class = split_varibles_class(sample_path)
    url1 =training_nodes[0].copy()
    n = len(training_nodes)
    #x为自变量y为因变量
    node_variables = []
    for k in range(0, n):
        x, y = training_nodes[k].iloc[:, 2:], training_nodes[k].iloc[:, 1]
        # test_class_name.append(y)
        #feat_labels = url1.columns[1:]
        feat_labels = training_nodes[k].columns[2:].values
        # n_estimators：森林中树的数量
        # n_jobs  整数 可选（默认=1） 适合和预测并行运行的作业数，如果为-1，则将作业数设置为核心数
        forest = RandomForestClassifier(n_estimators=2000, random_state=0, n_jobs=-1)
        #forest.fit(x_train, y_train)
        forest.fit(x,y)
        #下面对训练好的随机森林完成重要性评估
        importances = forest.feature_importances_
        #取出除去第一列的所有变量名
        # x_columns = training_nodes[k].columns[1:]
        #argsort函数返回的是数组从小到大的索引值
        #[::-1]表示去除数组中全部元素并按倒序排列，这样的话indices数组里存储的便是数组从大到小的索引值
        indices = np.argsort(importances)[::-1]
        # for f in range(x.shape[1]):
        #     #对于最后需要逆序排序，我认为是做了类似决策树回溯的取值，从叶子收敛
        #     #到根，根部重要程度高于叶子。
        #筛选变量(筛选重要性比较高的变量)
        x_selected_fields = feat_labels[indices[:]]
        x_selected = url1[x_selected_fields]
        #add对变量等级进行重新排序
        selected_varibles_class = varibles_class[indices[:]]
        #用选出来的变量做相关性分析
        person_varibles = np.corrcoef(x_selected,rowvar=0)
        # person_varibles = pearsonr(x_selected)
        # x_selected_test = x_selected.iloc[:,:]
        # x_corref = np.corrcoef(x_selected_test)
        #去除相关性大于0.8的变量
        for i in range(0, len(x_selected_fields)):
            for j in range(0, i):
                if abs(person_varibles[i][j]) > 0.9:
                    if i < j:
                        if x_selected_fields[j] in x_selected.columns.values:
                            x_selected = x_selected.drop(columns=x_selected_fields[j])
                            selected_varibles_class[j] = 0
                    else:
                        if x_selected_fields[i] in x_selected.columns.values:
                            x_selected = x_selected.drop(columns=x_selected_fields[i])
                            selected_varibles_class[i] = 0
        final_selected = x_selected.iloc[:, :].copy()
        selected_for_random = training_nodes[k][final_selected.columns.values].copy()
        node_variables.append(selected_for_random)
    return node_variables


def creat_tests(training_nodes, verify_nodes, last_nodes, A):
    np.seterr(divide='ignore', invalid='ignore')
    # url1 = pd.read_csv(sample_path, header=0)
    # node1 = url1.copy()
    # node1 = split_samples(sample_path,n,A)
    n = len(training_nodes)
    node1 = training_nodes[0].iloc[:, 0:3].copy()
    node2 = verify_nodes[0].iloc[:, 0:3].copy()
    training_tests = []
    training_tests.append(node1.copy())
    verify_tests = []
    verify_tests.append(node2.copy())
    for j in range(2, n + 1):
        for i in range(0, node1.shape[0]):
            if node1.iat[i, 1] == last_nodes[j - 1]:
                if node1.iat[i, 0] in A[j - 1]:
                    node1.iat[i, 1] = (j + 1) * 10 + 1
                else:
                    node1.iat[i, 1] = (j + 1) * 10 + 2
        for i in range(0, node2.shape[0]):
            if node2.iat[i, 1] == last_nodes[j - 1]:
                if node2.iat[i, 0] in A[j - 1]:
                    node2.iat[i, 1] = (j + 1) * 10 + 1
                else:
                    node2.iat[i, 1] = (j + 1) * 10 + 2
        training_tests.append(node1.copy())
        verify_tests.append(node2.copy())
    return (training_tests, verify_tests)


def str_to_digit(str):
    np.seterr(divide='ignore', invalid='ignore')
    A = str.split(';')
    res_A = []
    for i in range(0, len(A) - 1):
        res_A.append([])
        every = A[i].split(',')
        for j in range(0, len(every)):
            res_A[i].append(int(every[j]))
    return res_A


def ConvertELogStrToValue(eLogStr):
    np.seterr(divide='ignore', invalid='ignore')
    """
	convert string of natural logarithm base of E to value
	return (convertOK, convertedValue)
	eg:
	input:  -1.1694737e-03
	output: -0.001169
	input:  8.9455025e-04
	output: 0.000895
	"""

    (convertOK, convertedValue) = (False, 0.0)
    foundEPower = re.search("(?P<coefficientPart>-?\d+\.\d+)e(?P<ePowerPart>-\d+)", eLogStr, re.I)
    if (foundEPower):
        coefficientPart = foundEPower.group("coefficientPart")
        ePowerPart = foundEPower.group("ePowerPart")
        coefficientValue = float(coefficientPart)
        coefficientValue = int(coefficientValue)
        ePowerValue = float(ePowerPart)
        if int(ePowerValue) < 0:
            coefficientValue = round(coefficientValue, abs(int(ePowerValue)))
        else:
            coefficientValue = round(coefficientValue, int(ePowerValue))
        # math.e= 2.71828182846
        # wholeOrigValue = coefficientValue * math.pow(math.e, ePowerValue)
        wholeOrigValue = coefficientValue * math.pow(10, ePowerValue)

        (convertOK, convertedValue) = (True, wholeOrigValue)
    else:
        (convertOK, convertedValue) = (False, 0.0)

    # return (convertOK, convertedValue)
    return convertedValue


def decimal_digits(s):
    np.seterr(divide='ignore', invalid='ignore')
    s = str(s)
    ncount = 1
    if s.count(".") == 1:
        s_list = s.split(".")
        # left = s_list[0]
        right = s_list[1]
        for i in range(0, len(right)):
            if right[i] == "0":
                ncount = ncount + 1
            else:
                break
    return ncount
def creat_result_sample_combination(sample_path,last_nodes,A):
    np.seterr(divide='ignore', invalid='ignore')
    url1 = self_read_csv(sample_path)
    node1 = url1.copy()
    node1.insert(1, 'class_split', 0)
    n = len(A)
    node1 = node1.iloc[:,0:3].copy()
    for j in range(1,n+1):
        for i in range(0, node1.shape[0]):
            if node1.iat[i,1] == last_nodes[j-1]:
                if node1.iat[i, 0] in A[j-1]:
                    node1.iat[i, 1] = (j + 1) * 10 + 1
                else:
                    node1.iat[i, 1] = (j + 1) * 10 + 2
    # print node1.loc[:,'class_name']
    # print node1.loc[:,'class_split']
    class_split_temp = node1.loc[:,'class_split'].astype(np.int).tolist()
    class_split_final = list(set(class_split_temp))
    class_split_final.sort(key=class_split_temp.index)
    class_name_temp  = node1.loc[:,'class_name'].astype(np.int).tolist()
    #QMessageBox.information(cfg.uidc, ' ', str(2))
    class_name_final = list(set(class_name_temp))
    class_name_final.sort(key=class_name_temp.index)
    dict_class = {}
    for i in range(0,len(class_name_final)):
        dict_class[str(class_split_final[i])] = class_name_final[i]
    return dict_class

######################循环法数据准备########################################
def get_varible_all(nodes, node_varibles, everynodes, n, i):
    np.seterr(divide='ignore', invalid='ignore')
    node1_v1_s1 = nodes[n - 1].loc[
        nodes[n - 1]['class_split'] == (n + 1) * 10 + 1, node_varibles[n - 1].columns[i]].std()
    node1_v1_s2 = nodes[n - 1].loc[
        nodes[n - 1]['class_split'] == (n + 1) * 10 + 2, node_varibles[n - 1].columns[i]].std()
    node1_v1_m1 = nodes[n - 1].loc[
        nodes[n - 1]['class_split'] == (n + 1) * 10 + 1, node_varibles[n - 1].columns[i]].mean()
    node1_v1_m2 = nodes[n - 1].loc[
        nodes[n - 1]['class_split'] == (n + 1) * 10 + 2, node_varibles[n - 1].columns[i]].mean()
    if node1_v1_m1 > node1_v1_m2:
        node1_v1_m = (node1_v1_m1 - node1_v1_m2) / (node1_v1_s1 + node1_v1_s2)
        node1_v1_t = node1_v1_m * node1_v1_s2 + node1_v1_m2
        node1_v1_T_min = node1_v1_t - node1_v1_s2
        node1_v1_T_max = node1_v1_t + node1_v1_s1
    else:
        node1_v1_m = (node1_v1_m2 - node1_v1_m1) / (node1_v1_s1 + node1_v1_s2)
        node1_v1_t = node1_v1_m * node1_v1_s1 + node1_v1_m1
        node1_v1_T_min = node1_v1_t - node1_v1_s1
        node1_v1_T_max = node1_v1_t + node1_v1_s2
    difference_max_min = (node1_v1_T_max - node1_v1_T_min) / 50
    if str(difference_max_min).count("e") == 1:
        step1 = ConvertELogStrToValue(str(difference_max_min))
        if step1 == 0:
            step1 = difference_max_min
    else:
        ncount1_v1 = decimal_digits(difference_max_min)
        step1 = round(difference_max_min, ncount1_v1)
    everynodes.append([])
    everynodes[i].append(node1_v1_T_min)
    everynodes[i].append(node1_v1_T_max)
    everynodes[i].append(step1)
    everynodes[i].append(node1_v1_m1)
    everynodes[i].append(node1_v1_m2)
    return everynodes


def get_everynode_all(nodes, node_varibles, n):
    np.seterr(divide='ignore', invalid='ignore')
    everynodes = []
    for i in range(0, 4):
        everynodes = get_varible_all(nodes, node_varibles, everynodes, n, i)
    return everynodes


def get_all_value(nodes, node_varibles):
    np.seterr(divide='ignore', invalid='ignore')
    n = len(nodes)
    nodes_t_value = []
    for i in range(1, n + 1):
        node_t = get_everynode_all(nodes, node_varibles, i)
        nodes_t_value.append(node_t)
    return nodes_t_value


######################循环法数据准备########################################


def cycle_select_best_threshold(last_node_digit, node_varibles, tests, gauss, verify_nodes, verify_varibles,
                                verify_tests):
    np.seterr(divide='ignore', invalid='ignore')
    n = len(tests)
    best_thresholds = []
    M = node_varibles[0].shape[0]
    N = verify_nodes[0].shape[0]
    C1 = np.zeros(M, dtype=int)
    C2 = np.zeros(M, dtype=int)
    C3 = np.zeros(N, dtype=int)
    C4 = np.zeros(N, dtype=int)
    Data_YL_thres = []
    Data_YL_accuracy = []
    for i in range(1, n + 1):
        # QMessageBox.information(cfg.uidc,'',str(i))
        Data_YL_thres.append([])
        Data_YL_accuracy.append([])
        if i > 1:
            if len(best_thresholds[i - 2]) == 1:
                for k in range(0, M):
                    if gauss[i - 2][0][3] > gauss[i - 2][0][4]:
                        if C1[k] != last_node_digit[i - 2]:
                            C2[k] = C1[k]
                        else:
                            if node_varibles[i - 2].iat[k, 0] > best_thresholds[i - 2][0]:
                                C2[k] = i * 10 + 1
                            else:
                                C2[k] = i * 10 + 2
                    elif gauss[i - 2][1][3] < gauss[i - 2][1][4]:
                        if C1[k] != last_node_digit[i - 2]:
                            C2[k] = C1[k]
                        else:
                            if node_varibles[i - 2].iat[k, 1] < best_thresholds[i - 2][1]:
                                C2[k] = i * 10 + 1
                            else:
                                C2[k] = i * 10 + 2
            elif len(best_thresholds[i - 2]) == 2:
                for k in range(0, M):
                    if gauss[i - 2][0][3] > gauss[i - 2][0][4] and gauss[i - 2][1][3] > gauss[i - 2][1][4]:
                        if C1[k] != last_node_digit[i - 2]:
                            C2[k] = C1[k]
                        else:
                            if node_varibles[i - 2].iat[k, 0] > best_thresholds[i - 2][0] and node_varibles[i - 2].iat[
                                k, 1] > best_thresholds[i - 2][1]:
                                C2[k] = i * 10 + 1
                            else:
                                C2[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] > gauss[i - 2][0][4] and gauss[i - 2][1][3] < gauss[i - 2][1][4]:
                        if C1[k] != last_node_digit[i - 2]:
                            C2[k] = C1[k]
                        else:
                            if node_varibles[i - 2].iat[k, 0] > best_thresholds[i - 2][0] and node_varibles[i - 2].iat[
                                k, 1] < best_thresholds[i - 2][1]:
                                C2[k] = i * 10 + 1
                            else:
                                C2[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] < gauss[i - 2][0][4] and gauss[i - 2][1][3] > gauss[i - 2][1][4]:
                        if C1[k] != last_node_digit[i - 2]:
                            C2[k] = C1[k]
                        else:
                            if node_varibles[i - 2].iat[k, 0] < best_thresholds[i - 2][0] and node_varibles[i - 2].iat[
                                k, 1] > best_thresholds[i - 2][1]:
                                C2[k] = i * 10 + 1
                            else:
                                C2[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] < gauss[i - 2][0][4] and gauss[i - 2][1][3] < gauss[i - 2][1][4]:
                        if C1[k] != last_node_digit[i - 2]:
                            C2[k] = C1[k]
                        else:
                            if node_varibles[i - 2].iat[k, 0] < best_thresholds[i - 2][0] and node_varibles[i - 2].iat[
                                k, 1] < best_thresholds[i - 2][1]:
                                C2[k] = i * 10 + 1
                            else:
                                C2[k] = i * 10 + 2
            elif len(best_thresholds[i - 2]) == 3:
                for k in range(0, M):
                    if gauss[i - 2][0][3] > gauss[i - 2][0][4] and gauss[i - 2][1][3] > gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] > gauss[i - 2][2][4]:
                        if C1[k] != last_node_digit[i - 2]:
                            C2[k] = C1[k]
                        else:
                            if node_varibles[i - 2].iat[k, 0] > best_thresholds[i - 2][0] and node_varibles[i - 2].iat[
                                k, 1] > best_thresholds[i - 2][1] and node_varibles[i - 2].iat[k, 2] > \
                                    best_thresholds[i - 2][2]:
                                C2[k] = i * 10 + 1
                            else:
                                C2[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] > gauss[i - 2][0][4] and gauss[i - 2][1][3] > gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] < gauss[i - 2][2][4]:
                        if C1[k] != last_node_digit[i - 2]:
                            C2[k] = C1[k]
                        else:
                            if node_varibles[i - 2].iat[k, 0] > best_thresholds[i - 2][0] and node_varibles[i - 2].iat[
                                k, 1] > best_thresholds[i - 2][1] and node_varibles[i - 2].iat[k, 2] < \
                                    best_thresholds[i - 2][2]:
                                C2[k] = i * 10 + 1
                            else:
                                C2[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] > gauss[i - 2][0][4] and gauss[i - 2][1][3] < gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] > gauss[i - 2][2][4]:
                        if C1[k] != last_node_digit[i - 2]:
                            C2[k] = C1[k]
                        else:
                            if node_varibles[i - 2].iat[k, 0] > best_thresholds[i - 2][0] and node_varibles[i - 2].iat[
                                k, 1] < best_thresholds[i - 2][1] and node_varibles[i - 2].iat[k, 2] > \
                                    best_thresholds[i - 2][2]:
                                C2[k] = i * 10 + 1
                            else:
                                C2[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] > gauss[i - 2][0][4] and gauss[i - 2][1][3] < gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] < gauss[i - 2][2][4]:
                        if C1[k] != last_node_digit[i - 2]:
                            C2[k] = C1[k]
                        else:
                            if node_varibles[i - 2].iat[k, 0] > best_thresholds[i - 2][0] and node_varibles[i - 2].iat[
                                k, 1] < best_thresholds[i - 2][1] and node_varibles[i - 2].iat[k, 2] < \
                                    best_thresholds[i - 2][2]:
                                C2[k] = i * 10 + 1
                            else:
                                C2[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] < gauss[i - 2][0][4] and gauss[i - 2][1][3] < gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] < gauss[i - 2][2][4]:
                        if C1[k] != last_node_digit[i - 2]:
                            C2[k] = C1[k]
                        else:
                            if node_varibles[i - 2].iat[k, 0] < best_thresholds[i - 2][0] and node_varibles[i - 2].iat[
                                k, 1] < best_thresholds[i - 2][1] and node_varibles[i - 2].iat[k, 2] < \
                                    best_thresholds[i - 2][2]:
                                C2[k] = i * 10 + 1
                            else:
                                C2[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] < gauss[i - 2][0][4] and gauss[i - 2][1][3] < gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] > gauss[i - 2][2][4]:
                        if C1[k] != last_node_digit[i - 2]:
                            C2[k] = C1[k]
                        else:
                            if node_varibles[i - 2].iat[k, 0] < best_thresholds[i - 2][0] and node_varibles[i - 2].iat[
                                k, 1] < best_thresholds[i - 2][1] and node_varibles[i - 2].iat[k, 2] > \
                                    best_thresholds[i - 2][2]:
                                C2[k] = i * 10 + 1
                            else:
                                C2[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] < gauss[i - 2][0][4] and gauss[i - 2][1][3] > gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] < gauss[i - 2][2][4]:
                        if C1[k] != last_node_digit[i - 2]:
                            C2[k] = C1[k]
                        else:
                            if node_varibles[i - 2].iat[k, 0] < best_thresholds[i - 2][0] and node_varibles[i - 2].iat[
                                k, 1] > best_thresholds[i - 2][1] and node_varibles[i - 2].iat[k, 2] < \
                                    best_thresholds[i - 2][2]:
                                C2[k] = i * 10 + 1
                            else:
                                C2[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] < gauss[i - 2][0][4] and gauss[i - 2][1][3] > gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] > gauss[i - 2][2][4]:
                        if C1[k] != last_node_digit[i - 2]:
                            C2[k] = C1[k]
                        else:
                            if node_varibles[i - 2].iat[k, 0] < best_thresholds[i - 2][0] and node_varibles[i - 2].iat[
                                k, 1] > best_thresholds[i - 2][1] and node_varibles[i - 2].iat[k, 2] > \
                                    best_thresholds[i - 2][2]:
                                C2[k] = i * 10 + 1
                            else:
                                C2[k] = i * 10 + 2
            # print(C2)
            C1 = C2
            C2 = np.zeros(M, dtype=int)
        ##############################add对百分之三十的验证样本进行处理###############################################
        if i > 1:
            if len(best_thresholds[i - 2]) == 2:
                for k in range(0, N):
                    if gauss[i - 2][0][3] > gauss[i - 2][0][4] and gauss[i - 2][1][3] > gauss[i - 2][1][4]:
                        if C3[k] != last_node_digit[i - 2]:
                            C4[k] = C3[k]
                        else:
                            if verify_varibles[i - 2].iat[k, 0] > best_thresholds[i - 2][0] and \
                                    verify_varibles[i - 2].iat[k, 1] > best_thresholds[i - 2][1]:
                                C4[k] = i * 10 + 1
                            else:
                                C4[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] > gauss[i - 2][0][4] and gauss[i - 2][1][3] < gauss[i - 2][1][4]:
                        if C3[k] != last_node_digit[i - 2]:
                            C4[k] = C3[k]
                        else:
                            if verify_varibles[i - 2].iat[k, 0] > best_thresholds[i - 2][0] and \
                                    verify_varibles[i - 2].iat[k, 1] < best_thresholds[i - 2][1]:
                                C4[k] = i * 10 + 1
                            else:
                                C4[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] < gauss[i - 2][0][4] and gauss[i - 2][1][3] > gauss[i - 2][1][4]:
                        if C3[k] != last_node_digit[i - 2]:
                            C4[k] = C3[k]
                        else:
                            if verify_varibles[i - 2].iat[k, 0] < best_thresholds[i - 2][0] and \
                                    verify_varibles[i - 2].iat[k, 1] > best_thresholds[i - 2][1]:
                                C4[k] = i * 10 + 1
                            else:
                                C4[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] < gauss[i - 2][0][4] and gauss[i - 2][1][3] < gauss[i - 2][1][4]:
                        if C3[k] != last_node_digit[i - 2]:
                            C4[k] = C3[k]
                        else:
                            if verify_varibles[i - 2].iat[k, 0] < best_thresholds[i - 2][0] and \
                                    verify_varibles[i - 2].iat[k, 1] < best_thresholds[i - 2][1]:
                                C4[k] = i * 10 + 1
                            else:
                                C4[k] = i * 10 + 2
            elif len(best_thresholds[i - 2]) == 3:
                for k in range(0, N):
                    if gauss[i - 2][0][3] > gauss[i - 2][0][4] and gauss[i - 2][1][3] > gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] > gauss[i - 2][2][4]:
                        if C3[k] != last_node_digit[i - 2]:
                            C4[k] = C3[k]
                        else:
                            if verify_varibles[i - 2].iat[k, 0] > best_thresholds[i - 2][0] and \
                                    verify_varibles[i - 2].iat[k, 1] > best_thresholds[i - 2][1] and \
                                    verify_varibles[i - 2].iat[k, 2] > best_thresholds[i - 2][2]:
                                C4[k] = i * 10 + 1
                            else:
                                C4[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] > gauss[i - 2][0][4] and gauss[i - 2][1][3] > gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] < gauss[i - 2][2][4]:
                        if C3[k] != last_node_digit[i - 2]:
                            C4[k] = C3[k]
                        else:
                            if verify_varibles[i - 2].iat[k, 0] > best_thresholds[i - 2][0] and \
                                    verify_varibles[i - 2].iat[k, 1] > best_thresholds[i - 2][1] and \
                                    verify_varibles[i - 2].iat[k, 2] < best_thresholds[i - 2][2]:
                                C4[k] = i * 10 + 1
                            else:
                                C4[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] > gauss[i - 2][0][4] and gauss[i - 2][1][3] < gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] > gauss[i - 2][2][4]:
                        if C3[k] != last_node_digit[i - 2]:
                            C4[k] = C3[k]
                        else:
                            if verify_varibles[i - 2].iat[k, 0] > best_thresholds[i - 2][0] and \
                                    verify_varibles[i - 2].iat[k, 1] < best_thresholds[i - 2][1] and \
                                    verify_varibles[i - 2].iat[k, 2] > best_thresholds[i - 2][2]:
                                C4[k] = i * 10 + 1
                            else:
                                C4[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] > gauss[i - 2][0][4] and gauss[i - 2][1][3] < gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] < gauss[i - 2][2][4]:
                        if C3[k] != last_node_digit[i - 2]:
                            C4[k] = C3[k]
                        else:
                            if verify_varibles[i - 2].iat[k, 0] > best_thresholds[i - 2][0] and \
                                    verify_varibles[i - 2].iat[k, 1] < best_thresholds[i - 2][1] and \
                                    verify_varibles[i - 2].iat[k, 2] < best_thresholds[i - 2][2]:
                                C4[k] = i * 10 + 1
                            else:
                                C4[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] < gauss[i - 2][0][4] and gauss[i - 2][1][3] < gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] < gauss[i - 2][2][4]:
                        if C3[k] != last_node_digit[i - 2]:
                            C4[k] = C3[k]
                        else:
                            if verify_varibles[i - 2].iat[k, 0] < best_thresholds[i - 2][0] and \
                                    verify_varibles[i - 2].iat[k, 1] < best_thresholds[i - 2][1] and \
                                    verify_varibles[i - 2].iat[k, 2] < best_thresholds[i - 2][2]:
                                C4[k] = i * 10 + 1
                            else:
                                C4[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] < gauss[i - 2][0][4] and gauss[i - 2][1][3] < gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] > gauss[i - 2][2][4]:
                        if C3[k] != last_node_digit[i - 2]:
                            C4[k] = C3[k]
                        else:
                            if verify_varibles[i - 2].iat[k, 0] < best_thresholds[i - 2][0] and \
                                    verify_varibles[i - 2].iat[k, 1] < best_thresholds[i - 2][1] and \
                                    verify_varibles[i - 2].iat[k, 2] > best_thresholds[i - 2][2]:
                                C4[k] = i * 10 + 1
                            else:
                                C4[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] < gauss[i - 2][0][4] and gauss[i - 2][1][3] > gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] < gauss[i - 2][2][4]:
                        if C3[k] != last_node_digit[i - 2]:
                            C4[k] = C3[k]
                        else:
                            if verify_varibles[i - 2].iat[k, 0] < best_thresholds[i - 2][0] and \
                                    verify_varibles[i - 2].iat[k, 1] > best_thresholds[i - 2][1] and \
                                    verify_varibles[i - 2].iat[k, 2] < best_thresholds[i - 2][2]:
                                C4[k] = i * 10 + 1
                            else:
                                C4[k] = i * 10 + 2
                    elif gauss[i - 2][0][3] < gauss[i - 2][0][4] and gauss[i - 2][1][3] > gauss[i - 2][1][4] and \
                            gauss[i - 2][2][3] > gauss[i - 2][2][4]:
                        if C3[k] != last_node_digit[i - 2]:
                            C4[k] = C3[k]
                        else:
                            if verify_varibles[i - 2].iat[k, 0] < best_thresholds[i - 2][0] and \
                                    verify_varibles[i - 2].iat[k, 1] > best_thresholds[i - 2][1] and \
                                    verify_varibles[i - 2].iat[k, 2] > best_thresholds[i - 2][2]:
                                C4[k] = i * 10 + 1
                            else:
                                C4[k] = i * 10 + 2
            # print(C4)
            C3 = C4
            C4 = np.zeros(N, dtype=int)
        ##############################add添加只一个变量的循环###############################################
        OA2 = np.zeros((int((gauss[i - 1][0][1] - gauss[i - 1][0][0]) / gauss[i - 1][0][2]) + 1,
                        int((gauss[i - 1][1][1] - gauss[i - 1][1][0]) / gauss[i - 1][1][2]) + 1), dtype=float)
        j1 = gauss[i - 1][0][0]
        j2 = gauss[i - 1][1][0]
        data_every_node_two = np.zeros((int((gauss[i - 1][0][1] - gauss[i - 1][0][0]) / gauss[i - 1][0][2]) + 1,
                                        int((gauss[i - 1][1][1] - gauss[i - 1][1][0]) / gauss[i - 1][1][2]) + 1, 2),
                                       dtype=float)
        while (j1 < gauss[i - 1][0][1]):
            while (j2 < gauss[i - 1][1][1]):
                data_every_node_two[int((j1 - gauss[i - 1][0][0]) /
                                        gauss[i - 1][0][2])][
                    int((j2 - gauss[i - 1][1][0]) /
                        gauss[i - 1][1][2])][0] = j1
                data_every_node_two[int((j1 - gauss[i - 1][0][0]) /
                                        gauss[i - 1][0][2])][
                    int((j2 - gauss[i - 1][1][0]) /
                        gauss[i - 1][1][2])][1] = j2
                n1 = 0
                if gauss[i - 1][0][3] > gauss[i - 1][0][4] and gauss[i - 1][1][3] > gauss[i - 1][1][4]:
                    for j in range(0, M):
                        if C1[j] == last_node_digit[i - 1]:
                            if node_varibles[i - 1].iat[j, 0] > j1 and node_varibles[i - 1].iat[
                                j, 1] > j2:
                                C2[j] = (i + 1) * 10 + 1
                            else:
                                C2[j] = (i + 1) * 10 + 2
                        else:
                            C2[j] = C1[j]
                        if C2[j] == tests[i - 1].iat[j, 1]:
                            n1 = n1 + 1
                    OA2[int((j1 - gauss[i - 1][0][0]) /
                            gauss[i - 1][0][2])][
                        int((j2 - gauss[i - 1][1][0]) /
                            gauss[i - 1][1][2])] = round(float(n1) / M, 4)
                elif gauss[i - 1][0][3] > gauss[i - 1][0][4] and gauss[i - 1][1][3] < gauss[i - 1][1][4]:
                    for j in range(0, M):
                        if C1[j] == last_node_digit[i - 1]:
                            if node_varibles[i - 1].iat[j, 0] > j1 and node_varibles[i - 1].iat[
                                j, 1] < j2:
                                C2[j] = (i + 1) * 10 + 1
                            else:
                                C2[j] = (i + 1) * 10 + 2
                        else:
                            C2[j] = C1[j]
                        if C2[j] == tests[i - 1].iat[j, 1]:
                            n1 = n1 + 1
                    OA2[int((j1 - gauss[i - 1][0][0]) /
                            gauss[i - 1][0][2])][
                        int((j2 - gauss[i - 1][1][0]) /
                            gauss[i - 1][1][2])] = round(float(n1) / M, 4)
                elif gauss[i - 1][0][3] < gauss[i - 1][0][4] and gauss[i - 1][1][3] > gauss[i - 1][1][4]:
                    for j in range(0, M):
                        if C1[j] == last_node_digit[i - 1]:
                            if node_varibles[i - 1].iat[j, 0] < j1 and node_varibles[i - 1].iat[
                                j, 1] > j2:
                                C2[j] = (i + 1) * 10 + 1
                            else:
                                C2[j] = (i + 1) * 10 + 2
                        else:
                            C2[j] = C1[j]
                        if C2[j] == tests[i - 1].iat[j, 1]:
                            n1 = n1 + 1
                    OA2[int((j1 - gauss[i - 1][0][0]) /
                            gauss[i - 1][0][2])][
                        int((j2 - gauss[i - 1][1][0]) /
                            gauss[i - 1][1][2])] = round(float(n1) / M, 4)
                elif gauss[i - 1][0][3] < gauss[i - 1][0][4] and gauss[i - 1][1][3] < gauss[i - 1][1][4]:
                    for j in range(0, M):
                        if C1[j] == last_node_digit[i - 1]:
                            if node_varibles[i - 1].iat[j, 0] < j1 and node_varibles[i - 1].iat[
                                j, 1] < j2:
                                C2[j] = (i + 1) * 10 + 1
                            else:
                                C2[j] = (i + 1) * 10 + 2
                        else:
                            C2[j] = C1[j]
                        if C2[j] == tests[i - 1].iat[j, 1]:
                            n1 = n1 + 1
                    OA2[int((j1 - gauss[i - 1][0][0]) /
                            gauss[i - 1][0][2])][
                        int((j2 - gauss[i - 1][1][0]) /
                            gauss[i - 1][1][2])] = round(float(n1) / M, 4)
                j2 = j2 + gauss[i - 1][1][2]
            j1 = j1 + gauss[i - 1][0][2]
            j2 = gauss[i - 1][1][0]
        OA2_max = np.amax(OA2)
        Data_YL_thres[i - 1].append(data_every_node_two)
        Data_YL_accuracy[i - 1].append(OA2)
        # 找出验证精度最大值的所有下标
        index1_max_temp = np.where(OA2 == OA2_max)
        # 把最大值下标变成np数组
        index1_max = np.asarray(index1_max_temp)
        thres1 = []
        # 把最大精度的阈值组合拿出来存储在二维数组里
        for k in range(0, len(index1_max[0])):
            thres1.append([])
            thres1[k].append(round((gauss[i - 1][0][0] + index1_max[0][k] * gauss[i - 1][0][2]), 4))
            thres1[k].append(round((gauss[i - 1][1][0] + index1_max[1][k] * gauss[i - 1][1][2]), 4))
        best_thres1 = thres1[len(thres1) / 2]
        ######################add#############################
        n_verify = 0
        if gauss[i - 1][0][3] > gauss[i - 1][0][4] and gauss[i - 1][1][3] > gauss[i - 1][1][4]:
            for k in range(0, N):
                if C3[k] != last_node_digit[i - 1]:
                    C4[k] = C3[k]
                else:
                    if verify_varibles[i - 1].iat[k, 0] > best_thres1[0] and verify_varibles[i - 1].iat[
                        k, 1] > best_thres1[1]:
                        C4[k] = (i + 1) * 10 + 1
                    else:
                        C4[k] = (i + 1) * 10 + 2
                if verify_tests[i - 1].iat[k, 1] == C4[k]:
                    n_verify = n_verify + 1
        elif gauss[i - 1][0][3] > gauss[i - 1][0][4] and gauss[i - 1][1][3] < gauss[i - 1][1][4]:
            for k in range(0, N):
                if C3[k] != last_node_digit[i - 1]:
                    C4[k] = C3[k]
                else:
                    if verify_varibles[i - 1].iat[k, 0] > best_thres1[0] and verify_varibles[i - 1].iat[
                        k, 1] < best_thres1[1]:
                        C4[k] = (i + 1) * 10 + 1
                    else:
                        C4[k] = (i + 1) * 10 + 2
                if verify_tests[i - 1].iat[k, 1] == C4[k]:
                    n_verify = n_verify + 1
        elif gauss[i - 1][0][3] < gauss[i - 1][0][4] and gauss[i - 1][1][3] > gauss[i - 1][1][4]:
            for k in range(0, N):
                if C3[k] != last_node_digit[i - 1]:
                    C4[k] = C3[k]
                else:
                    if verify_varibles[i - 1].iat[k, 0] < best_thres1[0] and verify_varibles[i - 1].iat[
                        k, 1] > best_thres1[1]:
                        C4[k] = (i + 1) * 10 + 1
                    else:
                        C4[k] = (i + 1) * 10 + 2
                if verify_tests[i - 1].iat[k, 1] == C4[k]:
                    n_verify = n_verify + 1
        elif gauss[i - 1][0][3] < gauss[i - 1][0][4] and gauss[i - 1][1][3] < gauss[i - 1][1][4]:
            for k in range(0, N):
                if C3[k] != last_node_digit[i - 1]:
                    C4[k] = C3[k]
                else:
                    if verify_varibles[i - 1].iat[k, 0] < best_thres1[0] and verify_varibles[i - 1].iat[
                        k, 1] < best_thres1[1]:
                        C4[k] = (i + 1) * 10 + 1
                    else:
                        C4[k] = (i + 1) * 10 + 2
                if verify_tests[i - 1].iat[k, 1] == C4[k]:
                    n_verify = n_verify + 1
        OA_V = round(float(n_verify) / N, 4)
        ####################addd##################
        if OA_V > 0:
            best_thresholds.append(best_thres1)
        # 如果两个变量的最大精度小于0.9则再增加第3个变量
        else:
            OA3 = np.zeros((int((gauss[i - 1][0][1] - gauss[i - 1][0][0]) / gauss[i - 1][0][2]) + 1,
                            int((gauss[i - 1][1][1] - gauss[i - 1][1][0]) / gauss[i - 1][1][2]) + 1,
                            int((gauss[i - 1][2][1] - gauss[i - 1][2][0]) / gauss[i - 1][2][2]) + 1), dtype=float)
            j1 = gauss[i - 1][0][0]
            j2 = gauss[i - 1][1][0]
            j3 = gauss[i - 1][2][0]
            data_every_node_three = np.zeros((int((gauss[i - 1][0][1] - gauss[i - 1][0][0]) / gauss[i - 1][0][2]) + 1,
                                              int((gauss[i - 1][1][1] - gauss[i - 1][1][0]) / gauss[i - 1][1][2]) + 1,
                                              int((gauss[i - 1][2][1] - gauss[i - 1][2][0]) / gauss[i - 1][2][2]) + 1,
                                              3), dtype=float)
            while (j1 < gauss[i - 1][0][1]):
                while (j2 < gauss[i - 1][1][1]):
                    while (j3 < gauss[i - 1][2][1]):
                        data_every_node_three[int((j1 - gauss[i - 1][0][0]) /
                                                  gauss[i - 1][0][2])][
                            int((j2 - gauss[i - 1][1][0]) /
                                gauss[i - 1][1][2])][int((j3 - gauss[i - 1][2][0]) / gauss[i - 1][2][2])][0] = j1
                        data_every_node_three[int((j1 - gauss[i - 1][0][0]) /
                                                  gauss[i - 1][0][2])][
                            int((j2 - gauss[i - 1][1][0]) /
                                gauss[i - 1][1][2])][int((j3 - gauss[i - 1][2][0]) / gauss[i - 1][2][2])][1] = j2
                        data_every_node_three[int((j1 - gauss[i - 1][0][0]) /
                                                  gauss[i - 1][0][2])][
                            int((j2 - gauss[i - 1][1][0]) /
                                gauss[i - 1][1][2])][int((j3 - gauss[i - 1][2][0]) / gauss[i - 1][2][2])][2] = j3
                        n1 = 0
                        if gauss[i - 1][0][3] > gauss[i - 1][0][4] and gauss[i - 1][1][3] > gauss[i - 1][1][4] and \
                                gauss[i - 1][2][3] > gauss[i - 1][2][4]:
                            for j in range(0, M):
                                if C1[j] == last_node_digit[i - 1]:
                                    if node_varibles[i - 1].iat[j, 0] > j1 and node_varibles[i - 1].iat[
                                        j, 1] > j2 and node_varibles[i - 1].iat[j, 2] > j3:
                                        C2[j] = (i + 1) * 10 + 1
                                    else:
                                        C2[j] = (i + 1) * 10 + 2
                                else:
                                    C2[j] = C1[j]
                                if C2[j] == tests[i - 1].iat[j, 1]:
                                    n1 = n1 + 1
                            OA3[int((j1 - gauss[i - 1][0][0]) /
                                    gauss[i - 1][0][2])][int((j2 - gauss[i - 1][1][0]) / gauss[i - 1][1][2])][
                                int((j3 - gauss[i - 1][2][0]) / gauss[i - 1][2][2])] = round(float(n1) / M, 4)
                        elif gauss[i - 1][0][3] > gauss[i - 1][0][4] and gauss[i - 1][1][3] > gauss[i - 1][1][4] and \
                                gauss[i - 1][2][3] < gauss[i - 1][2][4]:
                            for j in range(0, M):
                                if C1[j] == last_node_digit[i - 1]:
                                    if node_varibles[i - 1].iat[j, 0] > j1 and node_varibles[i - 1].iat[
                                        j, 1] > j2 and node_varibles[i - 1].iat[j, 2] < j3:
                                        C2[j] = (i + 1) * 10 + 1
                                    else:
                                        C2[j] = (i + 1) * 10 + 2
                                else:
                                    C2[j] = C1[j]
                                if C2[j] == tests[i - 1].iat[j, 1]:
                                    n1 = n1 + 1
                            OA3[int((j1 - gauss[i - 1][0][0]) /
                                    gauss[i - 1][0][2])][
                                int((j2 - gauss[i - 1][1][0]) /
                                    gauss[i - 1][1][2])][int((j3 - gauss[i - 1][2][0]) / gauss[i - 1][2][2])] = round(
                                float(n1) / M, 4)
                        elif gauss[i - 1][0][3] > gauss[i - 1][0][4] and gauss[i - 1][1][3] < gauss[i - 1][1][4] and \
                                gauss[i - 1][2][3] > gauss[i - 1][2][4]:
                            for j in range(0, M):
                                if C1[j] == last_node_digit[i - 1]:
                                    if node_varibles[i - 1].iat[j, 0] > j1 and node_varibles[i - 1].iat[
                                        j, 1] < j2 and node_varibles[i - 1].iat[j, 2] > j3:
                                        C2[j] = (i + 1) * 10 + 1
                                    else:
                                        C2[j] = (i + 1) * 10 + 2
                                else:
                                    C2[j] = C1[j]
                                if C2[j] == tests[i - 1].iat[j, 1]:
                                    n1 = n1 + 1
                            OA3[int((j1 - gauss[i - 1][0][0]) /
                                    gauss[i - 1][0][2])][
                                int((j2 - gauss[i - 1][1][0]) /
                                    gauss[i - 1][1][2])][int((j3 - gauss[i - 1][2][0]) / gauss[i - 1][2][2])] = round(
                                float(n1) / M, 4)
                        elif gauss[i - 1][0][3] > gauss[i - 1][0][4] and gauss[i - 1][1][3] < gauss[i - 1][1][4] and \
                                gauss[i - 1][2][3] < gauss[i - 1][2][4]:
                            for j in range(0, M):
                                if C1[j] == last_node_digit[i - 1]:
                                    if node_varibles[i - 1].iat[j, 0] > j1 and node_varibles[i - 1].iat[
                                        j, 1] < j2 and node_varibles[i - 1].iat[j, 2] < j3:
                                        C2[j] = (i + 1) * 10 + 1
                                    else:
                                        C2[j] = (i + 1) * 10 + 2
                                else:
                                    C2[j] = C1[j]
                                if C2[j] == tests[i - 1].iat[j, 1]:
                                    n1 = n1 + 1
                            OA3[int((j1 - gauss[i - 1][0][0]) /
                                    gauss[i - 1][0][2])][
                                int((j2 - gauss[i - 1][1][0]) /
                                    gauss[i - 1][1][2])][int((j3 - gauss[i - 1][2][0]) / gauss[i - 1][2][2])] = round(
                                float(n1) / M, 4)
                        elif gauss[i - 1][0][3] < gauss[i - 1][0][4] and gauss[i - 1][1][3] < gauss[i - 1][1][4] and \
                                gauss[i - 1][2][3] < gauss[i - 1][2][4]:
                            for j in range(0, M):
                                if C1[j] == last_node_digit[i - 1]:
                                    if node_varibles[i - 1].iat[j, 0] < j1 and node_varibles[i - 1].iat[
                                        j, 1] < j2 and node_varibles[i - 1].iat[j, 2] < j3:
                                        C2[j] = (i + 1) * 10 + 1
                                    else:
                                        C2[j] = (i + 1) * 10 + 2
                                else:
                                    C2[j] = C1[j]
                                if C2[j] == tests[i - 1].iat[j, 1]:
                                    n1 = n1 + 1
                            OA3[int((j1 - gauss[i - 1][0][0]) /
                                    gauss[i - 1][0][2])][
                                int((j2 - gauss[i - 1][1][0]) /
                                    gauss[i - 1][1][2])][int((j3 - gauss[i - 1][2][0]) / gauss[i - 1][2][2])] = round(
                                float(n1) / M, 4)
                        elif gauss[i - 1][0][3] < gauss[i - 1][0][4] and gauss[i - 1][1][3] < gauss[i - 1][1][4] and \
                                gauss[i - 1][2][3] > gauss[i - 1][2][4]:
                            for j in range(0, M):
                                if C1[j] == last_node_digit[i - 1]:
                                    if node_varibles[i - 1].iat[j, 0] < j1 and node_varibles[i - 1].iat[
                                        j, 1] < j2 and node_varibles[i - 1].iat[j, 2] > j3:
                                        C2[j] = (i + 1) * 10 + 1
                                    else:
                                        C2[j] = (i + 1) * 10 + 2
                                else:
                                    C2[j] = C1[j]
                                if C2[j] == tests[i - 1].iat[j, 1]:
                                    n1 = n1 + 1
                            OA3[int((j1 - gauss[i - 1][0][0]) /
                                    gauss[i - 1][0][2])][
                                int((j2 - gauss[i - 1][1][0]) /
                                    gauss[i - 1][1][2])][int((j3 - gauss[i - 1][2][0]) / gauss[i - 1][2][2])] = round(
                                float(n1) / M, 4)
                        elif gauss[i - 1][0][3] < gauss[i - 1][0][4] and gauss[i - 1][1][3] > gauss[i - 1][1][4] and \
                                gauss[i - 1][2][3] < gauss[i - 1][2][4]:
                            for j in range(0, M):
                                if C1[j] == last_node_digit[i - 1]:
                                    if node_varibles[i - 1].iat[j, 0] < j1 and node_varibles[i - 1].iat[
                                        j, 1] > j2 and node_varibles[i - 1].iat[j, 2] < j3:
                                        C2[j] = (i + 1) * 10 + 1
                                    else:
                                        C2[j] = (i + 1) * 10 + 2
                                else:
                                    C2[j] = C1[j]
                                if C2[j] == tests[i - 1].iat[j, 1]:
                                    n1 = n1 + 1
                            OA3[int((j1 - gauss[i - 1][0][0]) /
                                    gauss[i - 1][0][2])][
                                int((j2 - gauss[i - 1][1][0]) /
                                    gauss[i - 1][1][2])][int((j3 - gauss[i - 1][2][0]) / gauss[i - 1][2][2])] = round(
                                float(n1) / M, 4)
                        elif gauss[i - 1][0][3] < gauss[i - 1][0][4] and gauss[i - 1][1][3] > gauss[i - 1][1][4] and \
                                gauss[i - 1][2][3] > gauss[i - 1][2][4]:
                            for j in range(0, M):
                                if C1[j] == last_node_digit[i - 1]:
                                    if node_varibles[i - 1].iat[j, 0] < j1 and node_varibles[i - 1].iat[
                                        j, 1] > j2 and node_varibles[i - 1].iat[j, 2] > j3:
                                        C2[j] = (i + 1) * 10 + 1
                                    else:
                                        C2[j] = (i + 1) * 10 + 2
                                else:
                                    C2[j] = C1[j]
                                if C2[j] == tests[i - 1].iat[j, 1]:
                                    n1 = n1 + 1
                            OA3[int((j1 - gauss[i - 1][0][0]) /
                                    gauss[i - 1][0][2])][
                                int((j2 - gauss[i - 1][1][0]) /
                                    gauss[i - 1][1][2])][int((j3 - gauss[i - 1][2][0]) / gauss[i - 1][2][2])] = round(
                                float(n1) / M, 4)
                        j3 = j3 + gauss[i - 1][2][2]
                    j2 = j2 + gauss[i - 1][1][2]
                    j3 = gauss[i - 1][2][0]
                j1 = j1 + gauss[i - 1][0][2]
                j2 = gauss[i - 1][1][0]
            OA3_max = np.amax(OA3)
            Data_YL_thres[i - 1].append(data_every_node_three)
            Data_YL_accuracy[i - 1].append(OA3)
            # 找出验证精度最大值的所有下标
            index1_max_temp = np.where(OA3 == OA3_max)
            # 把最大值下标变成np数组
            index1_max = np.asarray(index1_max_temp)
            thres1 = []
            # 把最大精度的阈值组合拿出来存储在二维数组里
            for k in range(0, len(index1_max[0])):
                thres1.append([])
                thres1[k].append(round((gauss[i - 1][0][0] + index1_max[0][k] * gauss[i - 1][0][2]), 4))
                thres1[k].append(round((gauss[i - 1][1][0] + index1_max[1][k] * gauss[i - 1][1][2]), 4))
                thres1[k].append(round((gauss[i - 1][2][0] + index1_max[2][k] * gauss[i - 1][2][2]), 4))
            best_thres2 = thres1[len(thres1) / 2]
            ######################add#############################
            n_verify3 = 0
            if gauss[i - 1][0][3] > gauss[i - 1][0][4] and gauss[i - 1][1][3] > gauss[i - 1][1][4] and gauss[i - 1][2][
                3] > \
                    gauss[i - 1][2][4]:
                for k in range(0, N):
                    if C3[k] != last_node_digit[i - 1]:
                        C4[k] = C3[k]
                    else:
                        if verify_varibles[i - 1].iat[k, 0] > best_thres2[0] and verify_varibles[i - 1].iat[
                            k, 1] > \
                                best_thres2[1] and verify_varibles[i - 1].iat[k, 2] > best_thres2[
                            2]:
                            C4[k] = (i + 1) * 10 + 1
                        else:
                            C4[k] = (i + 1) * 10 + 2
                    if verify_tests[i - 1].iat[k, 1] == C4[k]:
                        n_verify3 = n_verify3 + 1
            elif gauss[i - 1][0][3] > gauss[i - 1][0][4] and gauss[i - 1][1][3] > gauss[i - 1][1][4] and \
                    gauss[i - 1][2][
                        3] < gauss[i - 1][2][4]:
                for k in range(0, N):
                    if C3[k] != last_node_digit[i - 1]:
                        C4[k] = C3[k]
                    else:
                        if verify_varibles[i - 1].iat[k, 0] > best_thres2[0] and verify_varibles[i - 1].iat[
                            k, 1] > \
                                best_thres2[1] and verify_varibles[i - 1].iat[k, 2] < best_thres2[
                            2]:
                            C4[k] = (i + 1) * 10 + 1
                        else:
                            C4[k] = (i + 1) * 10 + 2
                    if verify_tests[i - 1].iat[k, 1] == C4[k]:
                        n_verify3 = n_verify3 + 1
            elif gauss[i - 1][0][3] > gauss[i - 1][0][4] and gauss[i - 1][1][3] < gauss[i - 1][1][4] and \
                    gauss[i - 1][2][
                        3] > gauss[i - 1][2][4]:
                for k in range(0, N):
                    if C3[k] != last_node_digit[i - 1]:
                        C4[k] = C3[k]
                    else:
                        if verify_varibles[i - 1].iat[k, 0] > best_thres2[0] and verify_varibles[i - 1].iat[
                            k, 1] < \
                                best_thres2[1] and verify_varibles[i - 1].iat[k, 2] > best_thres2[
                            2]:
                            C4[k] = (i + 1) * 10 + 1
                        else:
                            C4[k] = (i + 1) * 10 + 2
                    if verify_tests[i - 1].iat[k, 1] == C4[k]:
                        n_verify3 = n_verify3 + 1
            elif gauss[i - 1][0][3] > gauss[i - 1][0][4] and gauss[i - 1][1][3] < gauss[i - 1][1][4] and \
                    gauss[i - 1][2][
                        3] < gauss[i - 1][2][4]:
                for k in range(0, N):
                    if C3[k] != last_node_digit[i - 1]:
                        C4[k] = C3[k]
                    else:
                        if verify_varibles[i - 1].iat[k, 0] > best_thres2[0] and verify_varibles[i - 1].iat[
                            k, 1] < \
                                best_thres2[1] and verify_varibles[i - 1].iat[k, 2] < best_thres2[
                            2]:
                            C4[k] = (i + 1) * 10 + 1
                        else:
                            C4[k] = (i + 1) * 10 + 2
                    if verify_tests[i - 1].iat[k, 1] == C4[k]:
                        n_verify3 = n_verify3 + 1
            elif gauss[i - 1][0][3] < gauss[i - 1][0][4] and gauss[i - 1][1][3] < gauss[i - 1][1][4] and \
                    gauss[i - 1][2][
                        3] < gauss[i - 1][2][4]:
                for k in range(0, N):
                    if C3[k] != last_node_digit[i - 1]:
                        C4[k] = C3[k]
                    else:
                        if verify_varibles[i - 1].iat[k, 0] < best_thres2[0] and verify_varibles[i - 1].iat[
                            k, 1] < \
                                best_thres2[1] and verify_varibles[i - 1].iat[k, 2] < best_thres2[
                            2]:
                            C4[k] = (i + 1) * 10 + 1
                        else:
                            C4[k] = (i + 1) * 10 + 2
                    if verify_tests[i - 1].iat[k, 1] == C4[k]:
                        n_verify3 = n_verify3 + 1
            elif gauss[i - 1][0][3] < gauss[i - 1][0][4] and gauss[i - 1][1][3] < gauss[i - 1][1][4] and \
                    gauss[i - 1][2][
                        3] > gauss[i - 1][2][4]:
                for k in range(0, N):
                    if C3[k] != last_node_digit[i - 1]:
                        C4[k] = C3[k]
                    else:
                        if verify_varibles[i - 1].iat[k, 0] < best_thres2[0] and verify_varibles[i - 1].iat[
                            k, 1] < \
                                best_thres2[1] and verify_varibles[i - 1].iat[k, 2] > best_thres2[
                            2]:
                            C4[k] = (i + 1) * 10 + 1
                        else:
                            C4[k] = (i + 1) * 10 + 2
                    if verify_tests[i - 1].iat[k, 1] == C4[k]:
                        n_verify3 = n_verify3 + 1
            elif gauss[i - 1][0][3] < gauss[i - 1][0][4] and gauss[i - 1][1][3] > gauss[i - 1][1][4] and \
                    gauss[i - 1][2][
                        3] < gauss[i - 1][2][4]:
                for k in range(0, N):
                    if C3[k] != last_node_digit[i - 1]:
                        C4[k] = C3[k]
                    else:
                        if verify_varibles[i - 1].iat[k, 0] < best_thres2[0] and verify_varibles[i - 1].iat[
                            k, 1] > \
                                best_thres2[1] and verify_varibles[i - 1].iat[k, 2] < best_thres2[
                            2]:
                            C4[k] = (i + 1) * 10 + 1
                        else:
                            C4[k] = (i + 1) * 10 + 2
                    if verify_tests[i - 1].iat[k, 1] == C4[k]:
                        n_verify3 = n_verify3 + 1
            elif gauss[i - 1][0][3] < gauss[i - 1][0][4] and gauss[i - 1][1][3] > gauss[i - 1][1][4] and \
                    gauss[i - 1][2][
                        3] > gauss[i - 1][2][4]:
                for k in range(0, N):
                    if C3[k] != last_node_digit[i - 1]:
                        C4[k] = C3[k]
                    else:
                        if verify_varibles[i - 1].iat[k, 0] < best_thres2[0] and verify_varibles[i - 1].iat[
                            k, 1] > \
                                best_thres2[1] and verify_varibles[i - 1].iat[k, 2] > best_thres2[
                            2]:
                            C4[k] = (i + 1) * 10 + 1
                        else:
                            C4[k] = (i + 1) * 10 + 2
                    if verify_tests[i - 1].iat[k, 1] == C4[k]:
                        n_verify3 = n_verify3 + 1
            OA_V_max = round(float(n_verify3) / N, 4)
            if OA_V_max > OA_V:
                best_thresholds.append(best_thres2)
            else:
                best_thresholds.append(best_thres1)
    return best_thresholds

def every_node_class(i, last_node_digit, totalShp, row_id, node_varibles, nodes_t_value, class_n, best_thresholds):
    if len(best_thresholds[i - 1]) == 2:
        if class_n[row_id, 0] == last_node_digit:

            if nodes_t_value[i - 1][0][3] > nodes_t_value[i - 1][0][4] and nodes_t_value[i - 1][1][3] > \
                    nodes_t_value[i - 1][1][4]:
                if totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 0] > \
                        best_thresholds[i - 1][0] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 1] > \
                        best_thresholds[i - 1][1]:
                    class_n[row_id, 0] = (i + 1) * 10 + 1
                else:
                    class_n[row_id, 0] = (i + 1) * 10 + 2
            elif nodes_t_value[i - 1][0][3] < nodes_t_value[i - 1][0][4] and nodes_t_value[i - 1][1][3] < \
                    nodes_t_value[i - 1][1][4]:
                if totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 0] < \
                        best_thresholds[i - 1][0] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 1] < \
                        best_thresholds[i - 1][1]:
                    class_n[row_id, 0] = (i + 1) * 10 + 1
                else:
                    class_n[row_id, 0] = (i + 1) * 10 + 2
            elif nodes_t_value[i - 1][0][3] > nodes_t_value[i - 1][0][4] and nodes_t_value[i - 1][1][3] < \
                    nodes_t_value[i - 1][1][4]:
                if totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 0] > \
                        best_thresholds[i - 1][0] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 1] < \
                        best_thresholds[i - 1][1]:
                    class_n[row_id, 0] = (i + 1) * 10 + 1
                else:
                    class_n[row_id, 0] = (i + 1) * 10 + 2
            elif nodes_t_value[i - 1][0][3] < nodes_t_value[i - 1][0][4] and nodes_t_value[i - 1][1][3] > \
                    nodes_t_value[i - 1][1][4]:
                if totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 0] < \
                        best_thresholds[i - 1][0] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 1] > \
                        best_thresholds[i - 1][1]:
                    class_n[row_id, 0] = (i + 1) * 10 + 1
                else:
                    class_n[row_id, 0] = (i + 1) * 10 + 2
    elif len(best_thresholds[i - 1]) == 3:
        if class_n[row_id, 0] == last_node_digit:
            if nodes_t_value[i - 1][0][3] > nodes_t_value[i - 1][0][4] and nodes_t_value[i - 1][1][3] > \
                    nodes_t_value[i - 1][1][4] and nodes_t_value[i - 1][2][3] > \
                    nodes_t_value[i - 1][2][4]:
                if totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 0] > best_thresholds[i - 1][0] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 1] > best_thresholds[i - 1][1] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 2] > best_thresholds[i - 1][2]:
                    class_n[row_id, 0] = (i + 1) * 10 + 1
                else:
                    class_n[row_id, 0] = (i + 1) * 10 + 2
            elif nodes_t_value[i - 1][0][3] > nodes_t_value[i - 1][0][4] and nodes_t_value[i - 1][1][3] > \
                    nodes_t_value[i - 1][1][4] and nodes_t_value[i - 1][2][3] < nodes_t_value[i - 1][2][4]:
                if totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 0] > best_thresholds[i - 1][0] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 1] > best_thresholds[i - 1][1] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 2] < best_thresholds[i - 1][2]:
                    class_n[row_id, 0] = (i + 1) * 10 + 1
                else:
                    class_n[row_id, 0] = (i + 1) * 10 + 2
            elif nodes_t_value[i - 1][0][3] > nodes_t_value[i - 1][0][4] and nodes_t_value[i - 1][1][3] < \
                    nodes_t_value[i - 1][1][4] and nodes_t_value[i - 1][2][
                3] > nodes_t_value[i - 1][2][4]:
                if totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 0] > best_thresholds[i - 1][0] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 1] < best_thresholds[i - 1][1] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 2] > best_thresholds[i - 1][2]:
                    class_n[row_id, 0] = (i + 1) * 10 + 1
                else:
                    class_n[row_id, 0] = (i + 1) * 10 + 2
            elif nodes_t_value[i - 1][0][3] > nodes_t_value[i - 1][0][4] and nodes_t_value[i - 1][1][3] < \
                    nodes_t_value[i - 1][1][4] and nodes_t_value[i - 1][2][
                3] < nodes_t_value[i - 1][2][4]:
                if totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 0] > best_thresholds[i - 1][0] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 1] < best_thresholds[i - 1][1] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 2] < best_thresholds[i - 1][2]:
                    class_n[row_id, 0] = (i + 1) * 10 + 1
                else:
                    class_n[row_id, 0] = (i + 1) * 10 + 2
            elif nodes_t_value[i - 1][0][3] < nodes_t_value[i - 1][0][4] and nodes_t_value[i - 1][1][3] < \
                    nodes_t_value[i - 1][1][4] and nodes_t_value[i - 1][2][
                3] < nodes_t_value[i - 1][2][4]:
                if totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 0] < best_thresholds[i - 1][0] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 1] < best_thresholds[i - 1][1] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 2] < best_thresholds[i - 1][2]:
                    class_n[row_id, 0] = (i + 1) * 10 + 1
                else:
                    class_n[row_id, 0] = (i + 1) * 10 + 2
            elif nodes_t_value[i - 1][0][3] < nodes_t_value[i - 1][0][4] and nodes_t_value[i - 1][1][3] < \
                    nodes_t_value[i - 1][1][4] and nodes_t_value[i - 1][2][
                3] > nodes_t_value[i - 1][2][4]:
                if totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 0] < best_thresholds[i - 1][0] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 1] < best_thresholds[i - 1][1] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 2] > best_thresholds[i - 1][2]:
                    class_n[row_id, 0] = (i + 1) * 10 + 1
                else:
                    class_n[row_id, 0] = (i + 1) * 10 + 2
            elif nodes_t_value[i - 1][0][3] < nodes_t_value[i - 1][0][4] and nodes_t_value[i - 1][1][3] > \
                    nodes_t_value[i - 1][1][4] and nodes_t_value[i - 1][2][
                3] < nodes_t_value[i - 1][2][4]:
                if totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 0] < best_thresholds[i - 1][0] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 1] > best_thresholds[i - 1][1] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 2] < best_thresholds[i - 1][2]:
                    class_n[row_id, 0] = (i + 1) * 10 + 1
                else:
                    class_n[row_id, 0] = (i + 1) * 10 + 2
            elif nodes_t_value[i - 1][0][3] < nodes_t_value[i - 1][0][4] and nodes_t_value[i - 1][1][3] > \
                    nodes_t_value[i - 1][1][4] and nodes_t_value[i - 1][2][
                3] > nodes_t_value[i - 1][2][4]:
                if totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 0] < best_thresholds[i - 1][0] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 1] > best_thresholds[i - 1][1] and \
                        totalShp.loc[:, node_varibles[i - 1].columns].iat[row_id, 2] > best_thresholds[i - 1][2]:
                    class_n[row_id, 0] = (i + 1) * 10 + 1
                else:
                    class_n[row_id, 0] = (i + 1) * 10 + 2
    return class_n


class Utils:
    def __init__(self):
        pass

    ##################################
        """自定义分类模块功能 """

    ##################################
    def set_groupBox(self):
        cfg.uidc.lineEditOpenSample.setEnabled(True)
        cfg.uidc.pButtonOpenSample.setEnabled(True)
        cfg.uidc.lineEditOpenSample_2.setEnabled(True)
        cfg.uidc.lineEditOpenTotalShp.setEnabled(True)
        cfg.uidc.pButtonOpenTotalShp.setEnabled(True)

        cfg.uidc.lineEditOpenOrignalTiff.setEnabled(False)
        cfg.uidc.pButtonOpenOrignalTiff.setEnabled(False)
        cfg.uidc.pButtonLoadOrignalTiff.setEnabled(False)
        cfg.uidc.lineEditOpenWithoutShp.setEnabled(False)
        cfg.uidc.pButtonOpenWithoutShp.setEnabled(False)
        cfg.uidc.pButtonLoadWithoutShp.setEnabled(False)

    def set_groupBox_5(self):
        cfg.uidc.lineEditOpenSample.setEnabled(False)
        cfg.uidc.pButtonOpenSample.setEnabled(False)
        cfg.uidc.lineEditOpenSample_2.setEnabled(False)
        cfg.uidc.lineEditOpenTotalShp.setEnabled(False)
        cfg.uidc.pButtonOpenTotalShp.setEnabled(False)

        cfg.uidc.lineEditOpenOrignalTiff.setEnabled(True)
        cfg.uidc.pButtonOpenOrignalTiff.setEnabled(True)
        cfg.uidc.pButtonLoadOrignalTiff.setEnabled(True)
        cfg.uidc.lineEditOpenWithoutShp.setEnabled(True)
        cfg.uidc.pButtonOpenWithoutShp.setEnabled(True)
        cfg.uidc.pButtonLoadWithoutShp.setEnabled(True)

    # def setManualClassModle(self):
    # 	cfg.uidc.widget_class_modle.setEnabled(True)
    # 	cfg.uidc.scrollArea.setEnabled(True)
    # 	# cfg.uidc.button = new_button(cfg.uidc.widget_class_modle, cfg.uidc)
    # 	# cfg.uidc.button.set_button_center(40, 20)
    # 	# sample_path = cfg.uidc.lineEditOpenSample.text()
    # 	# records = pd.read_csv(sample_path, header=0)
    # 	# class_name = records.loc[:, ['class_name']].values
    # 	# class_name = np.unique(class_name)
    # 	# cfg.uidc.button.class_list = class_name
    # def setAutoClassModle(self):
    # 	cfg.uidc.widget_class_modle.setEnabled(False)
    # 	cfg.uidc.scrollArea.setEnabled(False)

    def select_open_total_shp(self):
        cfg.uidc.lineEditOpenTotalShp.clear()
        filename = QFileDialog.getOpenFileName(cfg.uidc, 'Select Input File', '', '*.shp')
        if filename:
            cfg.uidc.lineEditOpenTotalShp.setText(filename)

    def select_open_sample(self):
        cfg.uidc.lineEditOpenSample.clear()
        filename = QFileDialog.getOpenFileName(cfg.uidc, "Select Input File", '', '*.csv')
        if filename:
            cfg.uidc.lineEditOpenSample.setText(filename)

    # 打开输出文件
    def select_output_file(self):
        cfg.uidc.openOutFilelineEdit.clear()
        filename = QFileDialog.getSaveFileName(cfg.uidc, "Select Output File", '.', '*.shp')
        cfg.uidc.openOutFilelineEdit.setText(filename)
        cfg.uidc.button_processLoadStack.setEnabled(True)

    # 打开MTL文件
    def open_without_shp(self):
        cfg.uidc.lineEditOpenWithoutShp.clear()
        filename = QFileDialog.getOpenFileName(cfg.uidc, 'Select Input File', '', '*.shp')
        cfg.uidc.lineEditOpenWithoutShp.setText(filename)

    def open_original_Tiff(self):
        cfg.uidc.lineEditOpenOrignalTiff.clear()
        filename = QFileDialog.getOpenFileName(cfg.uidc, "select original raster", '.',
                                               "GTiff (*.tif *tiff *.TIF *.TIFF)")
        cfg.uidc.lineEditOpenOrignalTiff.setText(filename)

    def load_without_shp(self):
        filepath = cfg.uidc.lineEditOpenWithoutShp.text()
        # os.environ['QGIS_PREFIX_PATH'] = 'D:\\Program Files\\QGIS 2.18\\apps\\qgis-ltr\\'
        out_lyr_name = os.path.split(_fromUtf8(filepath))[1].split('.')[0]
        current_vector_layer = QgsVectorLayer(cfg.uidc.lineEditOpenWithoutShp.text(),out_lyr_name, "ogr")
        QgsMapLayerRegistry.instance().addMapLayers([current_vector_layer])

    def load_original_Tiff(self):
        filepath = self.cfg.uidc.lineEditOpenOrignalTiff.text()
        # lyr_name = os.path.split(os.path.split(filepath)[1])[0]
        # lyr_name = str(lyr_name)
        out_lyr_name = os.path.split(_fromUtf8(filepath))[1].split('.')[0]
        rasterLayer = QgsRasterLayer(cfg.uidc.lineEditOpenOrignalTiff.text(), out_lyr_name)
        QgsMapLayerRegistry.instance().addMapLayers([rasterLayer])
    #打开帮助文档
    # def show_help(self):


    ##################################
    """ Download functions """

    ##################################

    # download html file
    def downloadHtmlFileQGIS(self, url, url2=None, timeOutSec=1):
        cfg.htmlW = url2
        r = cfg.QNetworkRequestSCP(cfg.QtCoreSCP.QUrl(url))
        cfg.reply = cfg.qgisCoreSCP.QgsNetworkAccessManager.instance().get(r)
        cfg.reply.finished.connect(self.replyInTextBrowser)
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
        return "No"

    # load reply in text browser
    def replyInTextBrowser(self):
        cfg.reply.deleteLater()
        html = str(cfg.reply.readAll())
        # Github file not found
        if "<h1>404</h1>" in html:
            r = cfg.QNetworkRequestSCP(cfg.QtCoreSCP.QUrl(cfg.htmlW))
            cfg.reply2 = cfg.qgisCoreSCP.QgsNetworkAccessManager.instance().get(r)
            cfg.reply2.finished.connect(self.replyInTextBrowser2)
        cfg.reply.finished.disconnect()
        cfg.reply.abort()
        cfg.reply.close()
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # load reply in text browser
    def replyInTextBrowser2(self):
        cfg.reply2.deleteLater()
        html = str(cfg.reply2.readAll())
        cfg.reply2.finished.disconnect()
        cfg.reply2.abort()
        cfg.reply2.close()
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # get proxy opener
    def getProxyHandler(self):
        cfg.utls.getQGISProxySettings()
        if str(cfg.proxyEnabled) == "true" and len(cfg.proxyHost) > 0:
            if len(cfg.proxyUser) > 0:
                proxyHandler = cfg.urllib2SCP.ProxyHandler({
                                                               'http': 'http://' + cfg.proxyUser + ":" + cfg.proxyPassword + "@" + cfg.proxyHost + ':' + cfg.proxyPort})
            else:
                proxyHandler = cfg.urllib2SCP.ProxyHandler({'http': 'http://' + cfg.proxyHost + ':' + cfg.proxyPort})
        else:
            proxyHandler = None
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
        return proxyHandler

    # get password opener
    def getPasswordHandler(self, user, password, topLevelUrl):
        pswMng = cfg.urllib2SCP.HTTPPasswordMgrWithDefaultRealm()
        pswMng.add_password(None, topLevelUrl, user.encode(cfg.sysSCP.getfilesystemencoding()),
                            password.encode(cfg.sysSCP.getfilesystemencoding()))
        passwordHandler = cfg.urllib2SCP.HTTPBasicAuthHandler(pswMng)
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
        return passwordHandler

    # reply Finish
    def replyFinish(self):
        cfg.replyP.deleteLater()
        cfg.fileP = cfg.replyP.readAll()
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # replyText
    def replyText(self):
        cfg.replyP.deleteLater()
        cfg.htmlP = cfg.replyP.readAll()
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # progress
    def downloadProgress(self, value, total):
        cfg.uiUtls.updateBar(self.progressP,
                             "(" + str(value / 1048576) + "/" + str(total / 1048576) + " MB) " + self.urlP,
                             "Downloading")
        if cfg.actionCheck == "No":
            cfg.replyP.finished.disconnect()
            cfg.replyP.abort()
            cfg.replyP.close()

    # reply redirect
    def replyRedirect(self):
        cfg.replyR.deleteLater()
        rA = cfg.replyR.attribute(cfg.QNetworkRequestSCP.RedirectionTargetAttribute)
        if rA is not None:
            cfg.replyRURL = rA.toString()
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # reply redirect
    def replyRedirect2(self):
        cfg.replyR2.deleteLater()
        rA = cfg.replyR2.attribute(cfg.QNetworkRequestSCP.RedirectionTargetAttribute)
        if rA is not None:
            cfg.replyRURL2 = rA.toString()
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # reply redirect
    def replyRedirect3(self):
        cfg.replyR3.deleteLater()
        rA = cfg.replyR3.attribute(cfg.QNetworkRequestSCP.RedirectionTargetAttribute)
        if rA is not None:
            cfg.replyRURL3 = rA.toString()
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # connect with password
    def passwordConnect(self, user, password, url, topLevelUrl, outputPath=None, progress=None, quiet="No",
                        redirect="No"):
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              " " + url)
        # auth
        base64UP = cfg.base64SCP.encodestring(user + ":" + password)[:-1]
        h = "Basic " + base64UP
        hKey = cfg.QtCoreSCP.QByteArray("Authorization")
        hValue = cfg.QtCoreSCP.QByteArray(h)
        r = cfg.QNetworkRequestSCP(cfg.QtCoreSCP.QUrl(url))
        r.setRawHeader(hKey, hValue)
        qnamI = cfg.qgisCoreSCP.QgsNetworkAccessManager.instance()
        if redirect is not "No":
            cfg.replyR = qnamI.get(r)
            cfg.replyR.finished.connect(self.replyRedirect)
            # loop
            eL = cfg.QtCoreSCP.QEventLoop()
            cfg.replyR.finished.connect(eL.quit)
            eL.exec_()
            cfg.replyR.finished.disconnect(eL.quit)
            cfg.replyR.finished.disconnect()
            cfg.replyR.abort()
            cfg.replyR.close()
            r2 = cfg.QNetworkRequestSCP(cfg.QtCoreSCP.QUrl(cfg.replyRURL))
            r2.setRawHeader(hKey, hValue)
            cfg.replyR2 = qnamI.get(r2)
            cfg.replyR2.finished.connect(self.replyRedirect2)
            # loop
            eL = cfg.QtCoreSCP.QEventLoop()
            cfg.replyR2.finished.connect(eL.quit)
            eL.exec_()
            cfg.replyR2.finished.disconnect(eL.quit)
            cfg.replyR2.finished.disconnect()
            cfg.replyR2.abort()
            cfg.replyR2.close()
            r3 = cfg.QNetworkRequestSCP(cfg.QtCoreSCP.QUrl(cfg.replyRURL2))
            r3.setRawHeader(hKey, hValue)
            cfg.replyR3 = qnamI.get(r3)
            cfg.replyR3.finished.connect(self.replyRedirect3)
            # loop
            eL = cfg.QtCoreSCP.QEventLoop()
            cfg.replyR3.finished.connect(eL.quit)
            eL.exec_()
            cfg.replyR3.finished.disconnect(eL.quit)
            cfg.replyR3.finished.disconnect()
            cfg.replyR3.abort()
            cfg.replyR3.close()
        try:
            if outputPath is None:
                cfg.replyP = qnamI.get(r)
                cfg.replyP.finished.connect(self.replyText)
                # loop
                eL = cfg.QtCoreSCP.QEventLoop()
                cfg.replyP.finished.connect(eL.quit)
                eL.exec_()
                cfg.replyP.finished.disconnect(eL.quit)
                cfg.replyP.finished.disconnect()
                cfg.replyP.abort()
                cfg.replyP.close()
                return cfg.htmlP
            else:
                self.urlP = url
                self.progressP = progress
                cfg.replyP = qnamI.get(r)
                cfg.replyP.finished.connect(self.replyFinish)
                cfg.replyP.downloadProgress.connect(self.downloadProgress)
                # loop
                eL = cfg.QtCoreSCP.QEventLoop()
                cfg.replyP.finished.connect(eL.quit)
                eL.exec_()
                cfg.replyP.finished.disconnect(eL.quit)
                cfg.replyP.finished.disconnect()
                cfg.replyP.abort()
                cfg.replyP.close()
                with open(outputPath, "wb") as file:
                    file.write(cfg.fileP)

                if cfg.actionCheck == "No":
                    raise ValueError('Cancel action')
                if cfg.osSCP.path.getsize(outputPath) > 500:
                    cfg.fileP = None
                    return "Yes"
                else:
                    if "problem" in cfg.fileP:
                        cfg.fileP = None
                        return "No"
                    else:
                        cfg.fileP = None
                        return "Yes"

        except Exception, err:
            if unicode(err) != 'Cancel action':
                if quiet == "No":
                    if "ssl" in unicode(err):
                        cfg.mx.msgErr56()
                    else:
                        cfg.mx.msgErr50(unicode(err))
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return "No"

    # connect with password Python
    def passwordConnectPython(self, user, password, url, topLevelUrl, outputPath=None, progress=None, quiet="No"):
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              " " + url)
        proxyHandler = cfg.utls.getProxyHandler()
        passwordHandler = cfg.utls.getPasswordHandler(user, password, topLevelUrl)
        cookieHandler = cfg.urllib2SCP.HTTPCookieProcessor()
        if proxyHandler is None:
            opener = cfg.urllib2SCP.build_opener(cookieHandler, passwordHandler)
        else:
            opener = cfg.urllib2SCP.build_opener(proxyHandler, cookieHandler, passwordHandler)
        cfg.urllib2SCP.install_opener(opener)
        try:
            if outputPath is None:
                response = opener.open(url)
                return response
            else:
                f = cfg.urllib2SCP.urlopen(url)
                total_size = int(f.headers["Content-Length"])
                MB_size = total_size / 1048576
                block_size = 1024 * 1024
                with open(outputPath, "wb") as file:
                    while True:
                        block = f.read(block_size)
                        dSize = int(cfg.osSCP.stat(outputPath).st_size) / 1048576
                        cfg.uiUtls.updateBar(progress, "(" + str(dSize) + "/" + str(MB_size) + " MB) " + url,
                                             "Downloading")
                        cfg.QtGuiSCP.qApp.processEvents()
                        if not block:
                            break
                        file.write(block)
                        if cfg.actionCheck == "No":
                            raise ValueError('Cancel action')
                return "Yes"
        except Exception, err:
            if unicode(err) != 'Cancel action':
                if quiet == "No":
                    if "ssl" in unicode(err):
                        cfg.mx.msgErr56()
                    else:
                        cfg.mx.msgErr50(unicode(err))
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return "No"

    # encrypt password
    def encryptPassword(self, password):
        e = cfg.base64SCP.b64encode(password.encode(cfg.sysSCP.getfilesystemencoding()))
        return e

    # decrypt password
    def decryptPassword(self, password):
        d = cfg.base64SCP.b64decode(password)
        return d

    # download file
    def downloadFile(self, url, outputPath, fileName=None, progress=None):
        try:
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
            proxyHandler = cfg.utls.getProxyHandler()
            if proxyHandler is not None:
                opener = cfg.urllib2SCP.build_opener(proxyHandler)
                cfg.urllib2SCP.install_opener(opener)
            else:
                opener = cfg.urllib2SCP.build_opener()
            f = cfg.urllib2SCP.urlopen(url)
            try:
                total_size = int(f.headers["Content-Length"])
                MB_size = total_size / 1048576
            except:
                total_size = 1
            block_size = 1024 * 1024
            if block_size >= total_size:
                response = f.read()
                l = open(outputPath, 'wb')
                l.write(str(response))
                l.close()
            else:
                with open(outputPath, "wb") as file:
                    while True:
                        block = f.read(block_size)
                        dSize = int(cfg.osSCP.stat(outputPath).st_size) / 1048576
                        cfg.uiUtls.updateBar(progress, "(" + str(dSize) + "/" + str(MB_size) + " MB) " + url,
                                             "Downloading")
                        cfg.QtGuiSCP.qApp.processEvents()
                        if not block:
                            break
                        file.write(block)
                        if cfg.actionCheck == "No":
                            raise ValueError('Cancel action')
            return "Yes"
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return err

    ##################################
    """ LOG functions """

    ##################################

    # Clear log file
    def clearLogFile(self):
        if cfg.osSCP.path.isfile(cfg.logFile):
            try:
                l = open(cfg.logFile, 'w')
            except:
                pass
            try:
                l.write("Date	Function	Message \n")
                l.write(str(cfg.sysSCPInfo) + "\n")
                l.close()
            except:
                cfg.mx.msg2()

    # Get the code line number for log file
    def lineOfCode(self):
        return str(cfg.inspectSCP.currentframe().f_back.f_lineno)

    # logger condition
    def logCondition(self, function, message=""):
        if cfg.logSetVal == "Yes":
            cfg.utls.logToFile(function, message)

    # Logger of function
    def logToFile(self, function, message):
        # message string
        m = cfg.datetimeSCP.datetime.now().strftime(
            "%Y-%m-%d %H.%M.%S.%f") + "	" + function + "	" + message + "\n"
        if cfg.osSCP.path.isfile(cfg.logFile):
            try:
                l = open(cfg.logFile, 'a')
            except:
                pass
        else:
            l = open(cfg.logFile, 'w')
            try:
                l.write("Date	Function	Message \n")
                l.write(m)
                l.close()
            except:
                pass
        try:
            l.write(m)
            l.close()
        except:
            pass

    ##################################
    """ Time functions """

    ##################################

    # get  time
    def getTime(self):
        t = cfg.datetimeSCP.datetime.now().strftime("%Y%m%d_%H%M%S%f")
        return t

    # convert seconds to H M S
    def timeToHMS(self, time):
        min, sec = divmod(time, 60)
        hour, min = divmod(min, 60)
        if hour > 0:
            m = str("%.f" % round(hour)) + " H " + str("%.f" % round(min)) + " min"
        else:
            m = str("%.f" % round(min)) + " min " + str("%.f" % round(sec)) + " sec"
        return m

    ##################################
    """ Symbology functions """

    ##################################

    # set layer color for ROIs
    def ROISymbol(self, layer):
        st = {'color': '0,0,0,230', 'color_border': '0,0,0,230', 'style': 'solid', 'style_border': 'solid'}
        r = QgsFillSymbolV2.createSimple(st)
        renderer = layer.rendererV2()
        renderer.setSymbol(r)

    # Define vector symbology
    def vectorSymbol(self, layer, signatureList, macroclassCheck):
        c = []
        n = []
        # class count
        mc = []
        v = signatureList
        s = QgsSymbolV2.defaultSymbol(layer.geometryType())
        s.setColor(cfg.QtGuiSCP.QColor("#000000"))
        c.append(QgsRendererCategoryV2(0, s, "0 - " + cfg.uncls))
        for i in range(0, len(v)):
            if macroclassCheck == "Yes":
                if int(v[i][0]) not in mc:
                    mc.append(int(v[i][0]))
                    n.append([int(v[i][0]), v[i][6], str(v[i][1])])
            else:
                n.append([int(v[i][2]), v[i][6], str(v[i][3])])
        for b in sorted(n, key=lambda c: c[0]):
            s = QgsSymbolV2.defaultSymbol(layer.geometryType())
            s.setColor(b[1])
            ca = QgsRendererCategoryV2(b[0], s, str(b[0]) + " - " + b[2])
            c.append(ca)
        f = str(cfg.fldID_class)
        r = QgsCategorizedSymbolRendererV2(f, c)
        layer.setRendererV2(r)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # Define class symbology
    def rasterSymbol(self, classLayer, signatureList, macroclassCheck):
        classLayer.setDrawingStyle("SingleBandPseudoColor")
        # The band of classLayer
        cLB = 1
        # Color list for ramp
        cL = []
        n = []
        # class count
        mc = []
        v = signatureList
        if cfg.unclassValue is not None:
            cL.append(QgsColorRampShader.ColorRampItem(cfg.unclassValue, cfg.QtGuiSCP.QColor("#4d4d4d"), cfg.overlap))
        cL.append(QgsColorRampShader.ColorRampItem(0, cfg.QtGuiSCP.QColor("#000000"), "0 - " + cfg.uncls))
        for i in range(0, len(v)):
            if macroclassCheck == "Yes":
                if int(v[i][0]) not in mc and int(v[i][0]) != 0:
                    mc.append(int(v[i][0]))
                    n.append([int(v[i][0]), v[i][6], str(v[i][1])])
            else:
                if int(v[i][2]) != 0:
                    n.append([int(v[i][2]), v[i][6], str(v[i][3])])
        for b in sorted(n, key=lambda c: c[0]):
            cL.append(QgsColorRampShader.ColorRampItem(b[0], b[1], str(b[0]) + " - " + b[2]))
        # Create the shader
        lS = QgsRasterShader()
        # Create the color ramp function
        cR = QgsColorRampShader()
        cR.setColorRampType(QgsColorRampShader.EXACT)
        cR.setColorRampItemList(cL)
        # Set the raster shader function
        lS.setRasterShaderFunction(cR)
        # Create the renderer
        lR = QgsSingleBandPseudoColorRenderer(classLayer.dataProvider(), cLB, lS)
        # Apply the renderer to classLayer
        classLayer.setRenderer(lR)
        # refresh legend
        if hasattr(classLayer, "setCacheImage"):
            classLayer.setCacheImage(None)
        classLayer.triggerRepaint()
        cfg.lgnd.refreshLayerSymbology(classLayer)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "" + unicode(classLayer.source()))

    # Define class symbology
    def rasterSymbolLCSAlgorithmRaster(self, classLayer):
        classLayer.setDrawingStyle("SingleBandPseudoColor")
        # The band of classLayer
        cLB = 1
        # Color list for ramp
        cL = []
        if cfg.unclassValue is not None:
            cL.append(QgsColorRampShader.ColorRampItem(cfg.unclassValue, cfg.QtGuiSCP.QColor("#4d4d4d"), cfg.overlap))
        cL.append(QgsColorRampShader.ColorRampItem(0, cfg.QtGuiSCP.QColor("#000000"), "0 " + cfg.uncls))
        cL.append(QgsColorRampShader.ColorRampItem(1, cfg.QtGuiSCP.QColor("#ffffff"), "1 " + cfg.clasfd))
        # Create the shader
        lS = QgsRasterShader()
        # Create the color ramp function
        cR = QgsColorRampShader()
        cR.setColorRampType(QgsColorRampShader.EXACT)
        cR.setColorRampItemList(cL)
        # Set the raster shader function
        lS.setRasterShaderFunction(cR)
        # Create the renderer
        lR = QgsSingleBandPseudoColorRenderer(classLayer.dataProvider(), cLB, lS)
        # Apply the renderer to classLayer
        classLayer.setRenderer(lR)
        # refresh legend
        if hasattr(classLayer, "setCacheImage"):
            classLayer.setCacheImage(None)
        classLayer.triggerRepaint()
        cfg.lgnd.refreshLayerSymbology(classLayer)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "" + unicode(classLayer.source()))

    # Define class symbology pseudo color
    def rasterSymbolPseudoColor(self, layer):
        layer.setDrawingStyle("SingleBandPseudoColor")
        # Band statistics
        bndStat = layer.dataProvider().bandStatistics(1)
        max = bndStat.maximumValue
        min = bndStat.minimumValue
        # The band of layer
        cLB = 1
        # Color list for ramp
        cL = []
        colorMin = cfg.QtGuiSCP.QColor("#ffffff")
        colorMax = cfg.QtGuiSCP.QColor("#000000")
        cL.append(QgsColorRampShader.ColorRampItem(min, colorMin, str(min)))
        cL.append(QgsColorRampShader.ColorRampItem(max, colorMax, str(max)))
        # Create the shader
        lS = QgsRasterShader()
        # Create the color ramp function
        cR = QgsColorRampShader()
        cR.setColorRampType(QgsColorRampShader.INTERPOLATED)
        cR.setColorRampItemList(cL)
        # Set the raster shader function
        lS.setRasterShaderFunction(cR)
        # Create the renderer
        lR = QgsSingleBandPseudoColorRenderer(layer.dataProvider(), cLB, lS)
        # Apply the renderer to layer
        layer.setRenderer(lR)
        # refresh legend
        if hasattr(layer, "setCacheImage"):
            layer.setCacheImage(None)
        layer.triggerRepaint()
        cfg.lgnd.refreshLayerSymbology(layer)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "" + unicode(layer.source()))

    # Define class symbology single band grey
    def rasterSymbolSingleBandGray(self, layer):
        layer.setDrawingStyle("SingleBandGray")
        layer.setContrastEnhancement(QgsContrastEnhancement.StretchToMinimumMaximum,
                                     QgsRaster.ContrastEnhancementCumulativeCut)
        # refresh legend
        if hasattr(layer, "setCacheImage"):
            layer.setCacheImage(None)
        layer.triggerRepaint()
        cfg.lgnd.refreshLayerSymbology(layer)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "" + unicode(layer.source()))

    # Define raster symbology
    def rasterSymbolGeneric(self, rasterLayer, zeroValue="Unchanged"):
        rasterLayer.setDrawingStyle("SingleBandPseudoColor")
        # The band of classLayer
        classLyrBnd = 1
        # Band statistics
        bndStat = rasterLayer.dataProvider().bandStatistics(1)
        classMax = bndStat.maximumValue
        # Color list for ramp
        clrLst = [QgsColorRampShader.ColorRampItem(0, cfg.QtGuiSCP.QColor(0, 0, 0), zeroValue),
                  QgsColorRampShader.ColorRampItem(1, cfg.QtGuiSCP.QColor(0, 0, 255), "1"),
                  QgsColorRampShader.ColorRampItem(round(classMax / 2), cfg.QtGuiSCP.QColor(255, 0, 0),
                                                   str(round(classMax / 2))),
                  QgsColorRampShader.ColorRampItem(classMax, cfg.QtGuiSCP.QColor(0, 255, 0), str(classMax))]
        # Create the shader
        lyrShdr = QgsRasterShader()
        # Create the color ramp function
        clrFnctn = QgsColorRampShader()
        clrFnctn.setColorRampType(QgsColorRampShader.INTERPOLATED)
        clrFnctn.setColorRampItemList(clrLst)
        # Set the raster shader function
        lyrShdr.setRasterShaderFunction(clrFnctn)
        # Create the renderer
        lyrRndr = QgsSingleBandPseudoColorRenderer(rasterLayer.dataProvider(), classLyrBnd, lyrShdr)
        # Apply the renderer to rasterLayer
        rasterLayer.setRenderer(lyrRndr)
        # refresh legend
        if hasattr(rasterLayer, "setCacheImage"):
            rasterLayer.setCacheImage(None)
        rasterLayer.triggerRepaint()
        cfg.lgnd.refreshLayerSymbology(rasterLayer)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "symbology")

    # Define scatter raster symbology
    def rasterScatterSymbol(self, valueColorList):
        # Color list for ramp
        cL = []
        for i in valueColorList:
            cL.append(QgsColorRampShader.ColorRampItem(i[0], cfg.QtGuiSCP.QColor(i[1]), str(i[0])))
        # Create the shader
        lS = QgsRasterShader()
        # Create the color ramp function
        cR = QgsColorRampShader()
        cR.setColorRampType(QgsColorRampShader.EXACT)
        cR.setColorRampItemList(cL)
        # Set the raster shader function
        lS.setRasterShaderFunction(cR)
        return lS

    # set scatter raster symbology
    def setRasterScatterSymbol(self, classLayer, shader):
        classLayer.setDrawingStyle("SingleBandPseudoColor")
        # The band of classLayer
        cLB = 1
        # Create the renderer
        lR = QgsSingleBandPseudoColorRenderer(classLayer.dataProvider(), cLB, shader)
        # Apply the renderer to classLayer
        classLayer.setRenderer(lR)
        # refresh legend
        if hasattr(classLayer, "setCacheImage"):
            classLayer.setCacheImage(None)
        classLayer.triggerRepaint()
        cfg.lgnd.refreshLayerSymbology(classLayer)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "" + unicode(classLayer.source()))

    # copy renderer
    def copyRenderer(self, inputRaster, outputRaster):
        try:
            outputRaster.setDrawingStyle("SingleBandPseudoColor")
            r = inputRaster.renderer()
            cR = r.shader()
            # The band of classLayer
            classLyrBnd = 1
            # Create the renderer
            lyrRndr = QgsSingleBandPseudoColorRenderer(outputRaster.dataProvider(), classLyrBnd, cR)
            # Apply the renderer to rasterLayer
            outputRaster.setRenderer(lyrRndr)
            outputRaster.triggerRepaint()
            cfg.lgnd.refreshLayerSymbology(outputRaster)
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
        except Exception, err:
            list = "No"
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))

    ##################################
    """ Classification functions """

    ##################################

    # calculate covariance matrix from array list
    def calculateCovMatrix(self, arrayList):
        # create empty array
        d = arrayList[0].shape
        arrCube = cfg.np.zeros((d[0], d[1], len(arrayList)), dtype=cfg.np.float32)
        i = 0
        try:
            for a in arrayList:
                arrCube[:, :, i] = a
                i = i + 1
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return "No"
        matrix = arrCube.reshape(d[0] * d[1], len(arrayList))
        # find No data
        NoDt = cfg.np.where(cfg.np.isnan(matrix[:, 0]))
        # delete No data
        GMatrix = cfg.np.delete(matrix, NoDt, axis=0)
        TMatrix = GMatrix.T
        # covariance matrix (degree of freedom = 1 for unbiased estimate)
        CovMatrix = cfg.np.cov(TMatrix, ddof=1)
        try:
            if cfg.np.isnan(CovMatrix[0, 0]):
                CovMatrix = "No"
            try:
                inv = cfg.np.linalg.inv(CovMatrix)
                if cfg.np.isnan(inv[0, 0]):
                    CovMatrix = "No"
            except:
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    "TEST matrix: " + str(CovMatrix))
                CovMatrix = "No"
        except Exception, err:
            CovMatrix = "No"
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "cov matrix: " + str(CovMatrix))
        return CovMatrix

    # convert list to covariance array
    def listToCovarianceMatrix(self, list):
        try:
            covMat = cfg.np.zeros((len(list), len(list)), dtype=cfg.np.float32)
            i = 0
            for x in list:
                covMat[i, :] = x
                i = i + 1
            return covMat
        except Exception, err:
            list = "No"
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
        return "No"

    # convert covariance array to list
    def covarianceMatrixToList(self, covarianceArray):
        try:
            d = covarianceArray.shape
            list = []
            for i in range(0, d[0]):
                list.append(covarianceArray[i, :].tolist())
        except Exception, err:
            list = "No"
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
        return list

    # create one raster for each signature class
    def createSignatureClassRaster(self, signatureList, gdalRasterRef, outputDirectory, nodataValue=None,
                                   outputName=None, previewSize=0, previewPoint=None, compress="No",
                                   compressFormat="DEFLATE21"):
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "start createSignatureClassRaster")
        dT = self.getTime()
        outputRasterList = []
        for s in range(0, len(signatureList)):
            if outputName == None:
                o = outputDirectory + "/" + cfg.sigRasterNm + "_" + str(signatureList[s][0]) + "_" + str(
                    signatureList[s][2]) + "_" + dT + ".tif"
            else:
                o = outputDirectory + "/" + outputName + "_" + str(signatureList[s][0]) + "_" + str(
                    signatureList[s][2]) + ".tif"
            outputRasterList.append(o)
        oRL = self.createRasterFromReference(gdalRasterRef, 1, outputRasterList, nodataValue, "GTiff",
                                             cfg.rasterDataType, previewSize, previewPoint, compress, compressFormat)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "end createSignatureClassRaster")
        return oRL, outputRasterList

    ###############accuary_access#####################
    def showFileSelectDialog(self):
        fname = QFileDialog.getSaveFileName(cfg.uidc, 'Save File', os.path.expanduser('~'))
        cfg.uidc.outFileLineEdit.setText(fname)

    def showMatrixCSVSelectDialog(self):
        fname = QFileDialog.getSaveFileName(cfg.uidc, 'Save File', os.path.expanduser('~'))
        cfg.uidc.lEditAccuaryAccess.setText(fname)
    #
    # def refreshClassificationLayer(self):
    # 	ls = cfg.lgnd.layers()
    # 	cfg.ui.classification_name_combo.clear()
    # 	# classification name
    # 	self.clssfctnNm = None
    # 	for l in ls:
    # 		if (l.type()==QgsMapLayer.RasterLayer):
    # 			if l.bandCount() == 1:
    # 				cfg.dlg.classification_layer_combo(l.name())
    # 				cfg.dlg.classification_layer_combo_2(l.name())
    # 				cfg.dlg.classification_report_combo(l.name())
    # 	# logger
    # 	cfg.utls.logCondition(str(cfg.inspectSCP.stack()[0][3])+ " " + cfg.utls.lineOfCode(), "classification layers refreshed")

    def initreferenceComboBoLayerCombobox(self):
        cfg.uidc.referenceComboBox.clear()
        reg = QgsMapLayerRegistry.instance()
        for (key, layer) in reg.mapLayers().iteritems():

            if layer.type() == QgsMapLayer.RasterLayer or layer.type() == QgsMapLayer.VectorLayer:  # This doesn't work in QGIS2.0. Can I do without?: and ( layer.usesProvider() and layer.providerKey() == 'gdal' ):
                cfg.uidc.referenceComboBox.addItem(layer.name(), key)

        idx = cfg.uidc.referenceComboBox.findData('key_of_default_layer')
        if idx != -1:
            cfg.uidc.referenceComboBox.setCurrentIndex(idx)

    def initcomparisonComboBoxLayerCombobox(self):
        cfg.uidc.comparisonComboBox.clear()
        reg = QgsMapLayerRegistry.instance()
        for (key, layer) in reg.mapLayers().iteritems():

            if layer.type() == QgsMapLayer.RasterLayer or layer.type() == QgsMapLayer.VectorLayer:  # This doesn't work in QGIS2.0. Can I do without?: and ( layer.usesProvider() and layer.providerKey() == 'gdal' ):
                cfg.uidc.comparisonComboBox.addItem(layer.name(), key)

        idx = cfg.uidc.comparisonComboBox.findData('key_of_default_layer')
        if idx != -1:
            cfg.uidc.comparisonComboBox.setCurrentIndex(idx)

    # <editor-fold desc="fold classify result">
    ##########################合并分类后结果模块#########################
    def initComboBoxSelectClassResult(self):
        cfg.uidc.comBoxSelectClassResult.clear()
        reg = QgsMapLayerRegistry.instance()
        for (key, layer) in reg.mapLayers().iteritems():

            if layer.type() == QgsMapLayer.RasterLayer or layer.type() == QgsMapLayer.VectorLayer:  # This doesn't work in QGIS2.0. Can I do without?: and ( layer.usesProvider() and layer.providerKey() == 'gdal' ):
                cfg.uidc.comBoxSelectClassResult.addItem(layer.name(), key)
        self.loadClassBySelectClassResult()
        idx = cfg.uidc.comBoxSelectClassResult.findData('key_of_default_layer')
        if idx != -1:
            cfg.uidc.comBoxSelectClassResult.setCurrentIndex(idx)
    def initComBoxSelectClassForMerged(self):
        cfg.uidc.comBoxSelectClassForMerged.clear()
        #QMessageBox.information(cfg.uidc, "   ", str(1))
        for i in range(0,cfg.uidc.select_class_list_ToMerge.count()):
            #QMessageBox.information(cfg.uidc, "   ", str(2))
            cfg.uidc.comBoxSelectClassForMerged.addItem(cfg.uidc.select_class_list_ToMerge.item(i).text())
    def getAllClass(self,current_layer):
        unique_class_list = []
        for feature in current_layer.getFeatures():
            current_class = feature.attributes()[0]
            if current_class not in unique_class_list:
                unique_class_list.append(current_class)
            else:
                pass
        return unique_class_list
    def loadClassBySelectClassResult(self):
        cfg.uidc.avaliable_class_list_ToMerge.clear()
        cfg.uidc.select_class_list_ToMerge.clear()
        current_result_layer = self.layerFromComboBox(cfg.uidc.comBoxSelectClassResult)
        unique_class_list = self.getAllClass(current_result_layer)
        for i in range(0,len(unique_class_list)):
            cfg.uidc.avaliable_class_list_ToMerge.addItem(str(unique_class_list[i]))
        cfg.uidc.avaliable_class_list_ToMerge.sortItems()

        cfg.uidc.comBoxSelectClassForMerged.clear()
        # class_records_dataProvider = current_result_layer.dataProvider()
        # class_records = class_records_dataProvider.fields()
    def doubleClickToMergeItem(self):
        cfg.uidc.select_class_list_ToMerge.addItem(str(cfg.uidc.avaliable_class_list_ToMerge.currentItem().text()))
        cfg.uidc.avaliable_class_list_ToMerge.takeItem(cfg.uidc.avaliable_class_list_ToMerge.currentRow())
        cfg.uidc.select_class_list_ToMerge.sortItems()

    def doubleClickSelectedItem(self):
        cfg.uidc.avaliable_class_list_ToMerge.addItem(str(cfg.uidc.select_class_list_ToMerge.currentItem().text()))
        cfg.uidc.select_class_list_ToMerge.takeItem(cfg.uidc.select_class_list_ToMerge.currentRow())
        cfg.uidc.avaliable_class_list_ToMerge.sortItems()

    def startMergeClass(self):
        cfg.uiUtls.addProgressBar()
        QgsApplication.processEvents()
        cfg.uiUtls.updateBar(1)
        class_list_toMerge = []
        class_list_forMerge = None
        class_list_forMerge = int(cfg.uidc.comBoxSelectClassForMerged.itemText(cfg.uidc.comBoxSelectClassForMerged.currentIndex()))
        [class_list_toMerge.append(int(cfg.uidc.select_class_list_ToMerge.item(i).text())) for i in range(cfg.uidc.select_class_list_ToMerge.count())]
        current_result_layer = self.layerFromComboBox(cfg.uidc.comBoxSelectClassResult)
        current_result_layer.startEditing()
        for current_feat in current_result_layer.getFeatures():
            current_class = current_feat.attributes()[0]
            if current_class in class_list_toMerge:
                current_result_layer.changeAttributeValue(current_feat.id(), 0, class_list_forMerge)
        current_result_layer.commitChanges()
        cfg.uiUtls.updateBar(100)
        cfg.uiUtls.removeProgressBar()
        QgsApplication.processEvents()
        QMessageBox.information(cfg.uidc, "   ", u"成功")
    ##########################合并分类后结果模块#########################
    # </editor-fold>


    def layerFromComboBox(self, combox):
        layerID = str(combox.itemData(combox.currentIndex()))
        return QgsMapLayerRegistry.instance().mapLayer(layerID)

    ###############accuary_access#####################

    ##############Classification分类#################################################
    # perform classification
    def load_stack(self, *args):
        np.seterr(divide='ignore', invalid='ignore')
        cfg.uiUtls.addProgressBar()
        cfg.uiUtls.updateBar(1)
        # A = [[7],[6,8,9,14],[8,9],[3,12],[8],[6],[12],[4,5,11],[11],[1,2],[4],[1],[10]]
        # A = [[6,7,8],[9,14],[7],[1,2,10,12],[9],[6],[1,12],[2,10],[3,13],[1],[2],[3],[11],[4]]
        # 获取输出分层混淆矩阵csv的路径
        hierarchy_matrix_csv_path = cfg.uidc.lEditAccuaryAccess.text()
        hierarchy_matrix_csv = open(_fromUtf8(hierarchy_matrix_csv_path + ".csv"), 'wb')
        writer_hierarchy_matrix_csv = csv.writer(hierarchy_matrix_csv)
        # 得到样本数据的路径
        #QtCore.QString.fromLocal8Bit()
        openSamplePath = cfg.uidc.lineEditOpenSample.text()
        if cfg.uidc.radioButtonHierarchy.isChecked():
            if cfg.uidc.radioButtonManuaClassModel.isChecked():
                A = []
                B = []
                B.append(cfg.uidc.button)
                B_index = 0
                while B_index != -1:
                    A.append(B[B_index].left_button.class_list)
                    # QMessageBox.information(cfg.uidc, ' ', str(B[B_index].left_button.class_list))
                    current_button = B.pop(B_index)
                    B_index = B_index - 1
                    if current_button.left_button.left_button != None:
                        B.append(current_button.left_button)
                        B_index = B_index + 1
                    if current_button.right_button.left_button != None:
                        B.append(current_button.right_button)
                        B_index = B_index + 1
            else:
                all_varibles = self_read_csv(_fromUtf8(openSamplePath))
                unique_class = np.unique(all_varibles.loc[:, 'class_name'].values).astype(dtype=int)
                (a, b) = get_every_class_varibles(all_varibles, unique_class)
                standlize_varibles_result = standlize_varibles(a, b)
                varibles_for_z_score = get_varibles_for_z_score(standlize_varibles_result)
                (np_all_class_combination_z_score, dict_np_all_class_combination_z_score) = calculate_all_z_score(varibles_for_z_score)
                A_index = auto_hierarchy_class(np_all_class_combination_z_score, dict_np_all_class_combination_z_score)
                A = []
                for i in range(0, len(A_index)):
                    A.append([unique_class[x] for x in A_index[i]])
                    #QMessageBox.information(cfg.uidc, ' ', str(A))
            n = len(A)
            last_node_digit = get_lastnodes(_fromUtf8(openSamplePath), n, A)
            dict_class = creat_result_sample_combination(_fromUtf8(openSamplePath), last_node_digit, A)
        else:
            pass

        QgsApplication.processEvents()
        cfg.uiUtls.updateBar(2)
        # 根据样本利用随机算法得到筛选出的每个节点的变量组合
        outFilePath = cfg.uidc.openOutFilelineEdit.text()

        QgsApplication.processEvents()
        cfg.uiUtls.updateBar(5)
        # 得到分割后shp数据的路径
        totalShpPath = cfg.uidc.lineEditOpenTotalShp.text()
        totalShp = read_shp_to_pd(_fromUtf8(totalShpPath))
        QgsApplication.processEvents()
        cfg.uiUtls.updateBar(6)
        if cfg.uidc.radioButtonHierarchy.isChecked():
            if cfg.uidc.radioButtonOutMatrix.isChecked():
                split_value = float(cfg.uidc.lineEditOpenSample_2.text())
                (traing_nodes, verify_nodes) = split_samples(_fromUtf8(openSamplePath), n, A, split_value)
                (training_tests, verify_tests) = creat_tests(traing_nodes, verify_nodes, last_node_digit, A)
                QgsApplication.processEvents()
                cfg.uiUtls.updateBar(7)
                if cfg.uidc.radioCycle.isChecked():
                    (node_varibles, verify_varibles) = rf_select_best_variables(traing_nodes, verify_nodes, _fromUtf8(openSamplePath))
                else:
                    (node_varibles, verify_varibles, test_predict_class) = rf_select_variables_for_RF(traing_nodes,verify_nodes)
            else:
                if cfg.uidc.radioCycle.isChecked():
                    # split_value = float(cfg.uidc.lineEditOpenSample_2.text())
                    (traing_nodes, verify_nodes) = split_samples(_fromUtf8(openSamplePath), n, A, 0.5)
                    (node_varibles, verify_varibles) = rf_select_best_variables(traing_nodes, verify_nodes,
                                                                                _fromUtf8(openSamplePath))
                else:
                    nodes = pub_split_nodes(_fromUtf8(openSamplePath), n, A)
                    node_varibles = rf_select_best_variables_all_nodes(nodes, _fromUtf8(openSamplePath))
        else:
            node_varibles = rf_select_best_variables_without_verify(_fromUtf8(openSamplePath))
            get_all_selected_field = node_varibles.columns

        QgsApplication.processEvents()
        cfg.uiUtls.updateBar(20)
        np.seterr(divide='ignore', invalid='ignore')
        if cfg.uidc.radioButtonHierarchy.isChecked():
            if cfg.uidc.radioButtonOutMatrix.isChecked():
                #分层输出
                if cfg.uidc.radioSVM.isChecked() or cfg.uidc.radioRF.isChecked():
                    if cfg.uidc.radioSVM.isChecked():
                        classifier_id = 0
                    else:
                        classifier_id = 1

                    verify_shp_copy = verify_nodes[0].copy()
                    verify_shp = verify_nodes[0].copy()
                    # verify_class_name_all_true = verify_nodes[0].iloc[:, 0].values
                    verify_child_indicies = None
                    verify_class_result = None
                    class_name_nodes_predict = []
                    totalShp_copy = totalShp.copy()
                    isChild = True
                    child_node_indicies = None
                    class_name = None
                    QgsApplication.processEvents()
                    cfg.uiUtls.updateBar(30)
                    for i in range(0, n):
                        (class_name, child_node_indicies, totalShp, isChild, verify_class_result, verify_child_indicies,verify_shp) = every_node_randomforest_class_with_verify(classifier_id,i, last_node_digit, totalShp, node_varibles,verify_shp, verify_shp_copy,verify_child_indicies, verify_class_result,child_node_indicies, class_name, totalShp_copy,isChild, traing_nodes[i])
                        class_name_nodes_predict.append(verify_class_result.copy())
                        QgsApplication.processEvents()
                        cfg.uiUtls.updateBar(30 + 70 / float(n) * i)
                    for j in range(0, n):
                        temp = confusion_matrix(verify_tests[j].iloc[:, 1].values, class_name_nodes_predict[j])
                        writer_hierarchy_matrix_csv.writerows(np.c_[np.unique(class_name_nodes_predict[j]), temp])
                        writer_hierarchy_matrix_csv.writerows([""])
                        temp = None
                # confusion_matrix_final = confusion_matrix(final_verify_union_class_true, verify_class_result)
                # writer_hierarchy_matrix_csv.writerows(np.c_[np.unique(class_name_nodes_predict[j]), confusion_matrix_final])
                elif cfg.uidc.radioCycle.isChecked():
                    class_name = np.zeros((totalShp.shape[0], 1), dtype=int)
                    node_all_vlaue = get_all_value(traing_nodes, node_varibles)
                    (training_tests, verify_tests) = creat_tests(traing_nodes, verify_nodes, last_node_digit, A)
                    best_thresholds = cycle_select_best_threshold(last_node_digit, node_varibles, training_tests,
                                                                  node_all_vlaue, verify_nodes, verify_varibles,verify_tests)
                    QgsApplication.processEvents()
                    for i in range(1, n + 1):
                        for j in range(0, totalShp.shape[0]):
                            class_name = every_node_class(i, last_node_digit[i - 1], totalShp, j, node_varibles,
                                                          node_all_vlaue, class_name, best_thresholds)
                        QgsApplication.processEvents()
                        cfg.uiUtls.updateBar(15 + 85 / float(n) * i)
            else:
                # QMessageBox.information(cfg.uidc, '', str(cfg.uidc.radioSVM.isChecked()))
                # QMessageBox.information(cfg.uidc, '', str(cfg.uidc.radioRF.isChecked()))
                if cfg.uidc.radioSVM.isChecked() or cfg.uidc.radioRF.isChecked():
                    if cfg.uidc.radioSVM.isChecked():
                        classifier_id = 0
                    else:
                        classifier_id = 1
                    totalShp_copy = totalShp.copy()
                    isChild = True
                    child_node_indicies = None
                    class_name = None
                    for i in range(0, n):
                        (class_name, child_node_indicies, totalShp, isChild) = every_node_randomforest_class(classifier_id,i,last_node_digit,totalShp,node_varibles,child_node_indicies,class_name,totalShp_copy,isChild,nodes[i])
                        QgsApplication.processEvents()
                        cfg.uiUtls.updateBar(20 + 70 / float(n) * i)
                elif cfg.uidc.radioCycle.isChecked():
                    class_name = np.zeros((totalShp.shape[0], 1), dtype=int)
                    node_all_vlaue = get_all_value(traing_nodes, node_varibles)
                    (training_tests, verify_tests) = creat_tests(traing_nodes, verify_nodes, last_node_digit, A)
                    best_thresholds = cycle_select_best_threshold(last_node_digit, node_varibles, training_tests,
                                                                  node_all_vlaue, verify_nodes, verify_varibles,
                                                                  verify_tests)
                    QgsApplication.processEvents()

                    for i in range(1, n + 1):
                        for j in range(0, totalShp.shape[0]):
                            class_name = every_node_class(i, last_node_digit[i - 1], totalShp, j, node_varibles,
                                                          node_all_vlaue, class_name, best_thresholds)
                        QgsApplication.processEvents()
                        cfg.uiUtls.updateBar(18 + 70 / float(n) * i)
                else:
                    pass
        else:
            if cfg.uidc.radioButtonOutMatrix.isChecked():
                split_value = float(cfg.uidc.lineEditOpenSample_2.text())
                if cfg.uidc.radioSVM.isChecked() or cfg.uidc.radioRF.isChecked():
                    if cfg.uidc.radioSVM.isChecked():
                        classifier_id = 0
                    else:
                        classifier_id = 1
                    QgsApplication.processEvents()
                    cfg.uiUtls.updateBar(30)
                    (class_name, class_verify, y_verify, field_name) = total_random_forest_classify_with_verify(classifier_id,totalShp, _fromUtf8(openSamplePath), get_all_selected_field, split_value)
                    temp = confusion_matrix(class_verify, y_verify, labels=field_name)
                    writer_hierarchy_matrix_csv.writerows(np.c_[field_name, temp])
                    writer_hierarchy_matrix_csv.writerows([""])
                    temp = None
                else:
                    pass
            else:
                if cfg.uidc.radioSVM.isChecked() or cfg.uidc.radioRF.isChecked():
                    if cfg.uidc.radioSVM.isChecked():
                        classifier_id = 0
                    else:
                        classifier_id = 1
                    QgsApplication.processEvents()
                    cfg.uiUtls.updateBar(30)
                    class_name = total_random_forest_classify(classifier_id,totalShp, _fromUtf8(openSamplePath),get_all_selected_field)
                    cfg.uiUtls.updateBar(60)

                else:
                    pass
        if cfg.uidc.radioButtonHierarchy.isChecked():
            class_result_final = []
            u_class_name = np.unique(class_name)
            #QMessageBox.information(cfg.uidc, '', str(dict_class))
            for i in range(0, len(class_name)):
                class_result_final.append(dict_class[str(class_name[i])])
            class_name = class_result_final
            QgsApplication.processEvents()
            cfg.uiUtls.updateBar(98)
        else:
            class_name = class_name.astype(np.int)
            cfg.uiUtls.updateBar(70)

        # test_myText = unicode(totalShpPath, 'gb2312', 'ignore')
        # QgsApplication.processEvents()
        # cfg.uiUtls.updateBar(96)
        # test = totalShpPath.toUtf8()
        # cfg.uiUtls.updateBar(96)
        # u_test = unicode(totalShpPath.toUtf8(), 'utf8', 'ignore')
        # cfg.uiUtls.updateBar(97)
        # u_totalShpPath = unicode(totalShpPath.toUtf8(), 'utf8', 'ignore').encode('gb2312')
        # u_outFilePath = unicode(outFilePath.toUtf8(), 'utf8', 'ignore').encode('gb2312')
        u_totalShpPath = codecs.decode(totalShpPath,'utf-8').encode('gbk')
        u_outFilePath = codecs.decode(outFilePath,'utf-8').encode('gbk')
        cfg.uiUtls.updateBar(98)
        if cfg.uidc.radioCycle.isChecked():
            save_shape(class_name, u_totalShpPath, u_outFilePath)
        else:
            save_shape_rf(class_name, u_totalShpPath, u_outFilePath)

        cfg.uiUtls.updateBar(100)
        cfg.uiUtls.removeProgressBar()
        QgsApplication.processEvents()

        # ogr.RegisterAll()
        # gdal.SetConfigOption("GDAL_FILENAME_IS_UNICODE", "NO")
        # QgsApplication.registerOgrDrivers()
        reply = QMessageBox.question(cfg.uidc, u'提示',u'您是否想将结果加载到当前图层中',buttons=QMessageBox.Ok | QMessageBox.No, defaultButton=QMessageBox.No)
        if reply == QMessageBox.Ok:
            #out_lyr_name = os.path.split(os.path.split(_fromUtf8(outFilePath))[1])[0]
            out_lyr_name =os.path.split(_fromUtf8(outFilePath))[1].split('.')[0]
            current_vector_layer = QgsVectorLayer(cfg.uidc.openOutFilelineEdit.text(), out_lyr_name, "ogr")
            QgsMapLayerRegistry.instance().addMapLayers([current_vector_layer])
    # classify classes
    def classifyClasses(self, algorithmArray, minimumArray, classID, nodataValue=-999):
        if int(classID) == 0:
            classID = cfg.unclassifiedVal
        cB = cfg.np.equal(algorithmArray, minimumArray) * int(classID)
        cA = cfg.np.where(minimumArray != nodataValue, cB, cfg.unclassifiedVal)
        return cA

    # classify classes
    def classifyClassesLCSSimple(self, LCSarray, equalArray, classArrayLCS, dataValue, unclassValue, nodataValue,
                                 classID):
        cA = cfg.np.where((LCSarray == dataValue) & (equalArray == dataValue), int(classID),
                          cfg.np.where((equalArray == unclassValue) & (classArrayLCS <> int(classID)), unclassValue,
                                       classArrayLCS))
        return cA

    # find minimum array
    def findMinimumArray(self, firstArray, secondArray, nodataValue=-999):
        f = cfg.np.where(firstArray == nodataValue, cfg.maxValDt, firstArray)
        s = cfg.np.where(secondArray == nodataValue, cfg.maxValDt, secondArray)
        n = cfg.np.minimum(f, s)
        m = cfg.np.where(n == cfg.maxValDt, nodataValue, n)
        return m

    # find equal array
    def findEqualArray(self, firstArray, secondArray, dataValue=-1, nodataValue=-999, unclassifiedValue=-1000):
        f = cfg.np.where((firstArray == dataValue) & (secondArray == dataValue), unclassifiedValue,
                         cfg.np.where(firstArray == unclassifiedValue, unclassifiedValue,
                                      cfg.np.where(secondArray == unclassifiedValue, unclassifiedValue,
                                                   cfg.np.where(firstArray == nodataValue, secondArray, firstArray))))
        return f

    # find maximum array
    def findMaximumArray(self, firstArray, secondArray, nodataValue=-999):
        f = cfg.np.where(firstArray == nodataValue, cfg.maxLikeNoDataVal, firstArray)
        s = cfg.np.where(secondArray == nodataValue, cfg.maxLikeNoDataVal, secondArray)
        m = cfg.np.maximum(f, s)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
        return m

    # set threshold
    def maximumLikelihoodThreshold(self, array, nodataValue=0):
        outArray = cfg.np.where(array > cfg.maxLikeNoDataVal, array, nodataValue)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
        return outArray

    # set threshold
    def minimumDistanceThreshold(self, array, threshold, nodataValue=0):
        outArray = cfg.np.where(array < threshold, array, nodataValue)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
        return outArray

    # create array from signature list
    def createArrayFromSignature(self, gdalBandList, signatureList):
        arrayList = []
        for s in signatureList:
            val = s[4]
            array = cfg.np.zeros((len(gdalBandList)), dtype=cfg.np.float32)
            max = len(gdalBandList) * 2
            i = 0
            for b in range(0, max, 2):
                array[i] = val[b]
                i = i + 1
            arrayList.append(array)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
        return arrayList

    # minimum Euclidean distance algorithm [ sqrt( sum( (r_i - s_i)^2 ) ) ]
    def algorithmMinimumDistance(self, rasterArray, signatureArray, weightList=None):
        try:
            if weightList is not None:
                c = 0
                for w in weightList:
                    rasterArray[:, :, c] *= w
                    signatureArray[c] *= w
                    c = c + 1
            algArray = cfg.np.sqrt(((rasterArray - signatureArray) ** 2).sum(axis=2))
            return algArray
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            cfg.mx.msgErr28()
            return 0

    # create covariance matrix list from signature list
    def covarianceMatrixList(self, signatureList):
        c = []
        for s in signatureList:
            cov = s[7]
            c.append(cov)
        return c

    # create LCSmin LCSmax list from signature list
    def LCSminMaxList(self, signatureList):
        arrayList = []
        for s in signatureList:
            LCSmin = s[8]
            LCSmax = s[9]
            arrayList.append([LCSmin, LCSmax])
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
        return arrayList

    # create threshold list from signature list
    def thresholdList(self, signatureList):
        c = []
        for s in signatureList:
            t = s[10]
            c.append(t)
        return c

    # calculate critical chi square and threshold
    def chisquare(self, algThrshld):
        p = 1 - (algThrshld / 100)
        chi = cfg.statdistrSCP.chi2.isf(p, 4)
        return chi

    # Maximum Likelihood algorithm
    def algorithmMaximumLikelihood(self, rasterArray, signatureArray, covarianceMatrixZ, weightList=None, algThrshld=0):
        try:
            covarianceMatrix = cfg.np.copy(covarianceMatrixZ)
            if weightList is not None:
                c = 0
                for w in weightList:
                    rasterArray[:, :, c] *= w
                    signatureArray[c] *= w
                    c = c + 1
            (sign, logdet) = cfg.np.linalg.slogdet(covarianceMatrix)
            invC = cfg.np.linalg.inv(covarianceMatrix)
            d = rasterArray - signatureArray
            algArray = - logdet - (cfg.np.dot(d, invC) * d).sum(axis=2)
            if algThrshld > 0:
                chi = self.chisquare(algThrshld)
                threshold = - chi - logdet
                algArray = cfg.np.where(algArray < threshold, cfg.maxLikeNoDataVal, algArray)
            return algArray
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            cfg.mx.msgErr28()
            return 0

    # spectral angle mapping algorithm [ arccos( sum(r_i * s_i) / ( sum(r_i**2) * sum(s_i**2) ) ) ]
    def algorithmSAM(self, rasterArray, signatureArray, weightList=None):
        try:
            if weightList is not None:
                c = 0
                for w in weightList:
                    rasterArray[:, :, c] *= w
                    signatureArray[c] *= w
                    c = c + 1
            algArray = cfg.np.arccos((rasterArray * signatureArray).sum(axis=2) / cfg.np.sqrt(
                (rasterArray ** 2).sum(axis=2) * (signatureArray ** 2).sum())) * 180 / cfg.np.pi
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
            return algArray
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            cfg.mx.msgErr28()
            return 0

    # land cover signature
    def algorithmLCS(self, rasterArray, signatureArray, LCSmin, LCSmax, multFactor, weightList=None, dataValue=0,
                     nodataValue=-999):
        try:
            if weightList is not None:
                c = 0
                for w in weightList:
                    rasterArray[:, :, c] *= w
                    signatureArray[c] *= w
                    LCSmin[c] *= w
                    LCSmax[c] *= w
                    c = c + 1
            condit1 = "cfg.np.where( "
            for i in range(len(signatureArray)):
                condit1 = condit1 + "(cfg.np.around(rasterArray[:,:," + str(i) + "], 11) >= cfg.np.around(" + repr(
                    LCSmin[i] * multFactor) + ", 11)) & (cfg.np.around(rasterArray[:,:," + str(
                    i) + "], 11) <= cfg.np.around(" + repr(LCSmax[i] * multFactor) + ", 11)) & "
            condit1 = condit1[:-4] + "), " + repr(dataValue) + ", " + repr(nodataValue) + ")"
            algArray = eval(condit1)
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
            return algArray
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            cfg.mx.msgErr28()
            return 0

    ##################################
    """ Signature spectral distance functions """

    ##################################

    # calculate Jeffries-Matusita distance Jij = 2[1 − e^(−B)] from Richards, J. A. & Jia, X. 2006. Remote Sensing Digital Image Analysis: An Introduction, Springer.
    def jeffriesMatusitaDistance(self, signatureArrayI, signatureArrayJ, covarianceMatrixI, covarianceMatrixJ,
                                 weightList=None):
        try:
            I = cfg.np.array(signatureArrayI)
            J = cfg.np.array(signatureArrayJ)
            cI = cfg.np.copy(covarianceMatrixI)
            cJ = cfg.np.copy(covarianceMatrixJ)
            if weightList is not None:
                c = 0
                for w in weightList:
                    I[c] *= w
                    J[c] *= w
                    c = c + 1
            d = (I - J)
            C = (cI + cJ) / 2
            invC = cfg.np.linalg.inv(C)
            dInvC = cfg.np.dot(d.T, invC)
            f = cfg.np.dot(dInvC, d) / 8.0
            (signC, logdetC) = cfg.np.linalg.slogdet(C)
            (signcI, logdetcI) = cfg.np.linalg.slogdet(cI)
            (signcJ, logdetcJ) = cfg.np.linalg.slogdet(cJ)
            s = cfg.np.log(signC * cfg.np.exp(logdetC) / (
                        cfg.np.sqrt(signcI * cfg.np.exp(logdetcI)) * cfg.np.sqrt(signcJ * cfg.np.exp(logdetcJ)))) / 2.0
            B = f + s
            JM = 2 * (1 - cfg.np.exp(-B))
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            JM = cfg.notAvailable
        return JM

    # calculate transformed divergence dij = 2[1 − e^(−dij/8)] from Richards, J. A. & Jia, X. 2006. Remote Sensing Digital Image Analysis: An Introduction, Springer.
    def transformedDivergence(self, signatureArrayI, signatureArrayJ, covarianceMatrixI, covarianceMatrixJ):
        try:
            I = cfg.np.array(signatureArrayI)
            J = cfg.np.array(signatureArrayJ)
            d = (I - J)
            cI = covarianceMatrixI
            cJ = covarianceMatrixJ
            invCI = cfg.np.linalg.inv(cI)
            invCJ = cfg.np.linalg.inv(cJ)
            p1 = (cI - cJ) * (invCI - invCJ)
            t1 = 0.5 * cfg.np.trace(p1)
            p2 = (invCI + invCJ) * d
            p3 = p2 * d.T
            t2 = 0.5 * cfg.np.trace(p3)
            div = t1 + t2
            TD = 2 * (1 - cfg.np.exp(-div / 8.0))
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            TD = cfg.notAvailable
        return TD

    # Bray-Curtis similarity (100 - 100 * sum(abs(x[ki]-x[kj]) / (sum(x[ki] + x[kj])))
    def brayCurtisSimilarity(self, signatureArrayI, signatureArrayJ):
        try:
            I = cfg.np.array(signatureArrayI)
            J = cfg.np.array(signatureArrayJ)
            sumIJ = I.sum() + J.sum()
            d = cfg.np.sqrt((I - J) ** 2)
            sim = 100 - d.sum() / sumIJ * 100
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            sim = cfg.notAvailable
        return sim

    # Euclidean distance sqrt(sum((x[ki] - x[kj])^2))
    def euclideanDistance(self, signatureArrayI, signatureArrayJ, weightList=None):
        try:
            I = cfg.np.array(signatureArrayI)
            J = cfg.np.array(signatureArrayJ)
            if weightList is not None:
                c = 0
                for w in weightList:
                    I[c] *= w
                    J[c] *= w
                    c = c + 1
            d = (I - J) ** 2
            dist = cfg.np.sqrt(d.sum())
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            dist = cfg.notAvailable
        return dist

    # Spectral angle algorithm [ arccos( sum(r_i * s_i) / sqrt( sum(r_i**2) * sum(s_i**2) ) ) ]
    def spectralAngle(self, signatureArrayI, signatureArrayJ, weightList=None):
        try:
            I = cfg.np.array(signatureArrayI)
            J = cfg.np.array(signatureArrayJ)
            if weightList is not None:
                c = 0
                for w in weightList:
                    I[c] *= w
                    J[c] *= w
                    c = c + 1
            angle = cfg.np.arccos((I * J).sum() / cfg.np.sqrt((I ** 2).sum() * (J ** 2).sum())) * 180 / cfg.np.pi
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            angle = cfg.notAvailable
        return angle

    ##################################
    """ Signature functions """

    ##################################

    # calculate ROI signature (one signature for ROIs that have the same macroclass ID and class ID)
    def calculateSignature(self, lyr, rasterName, featureIDList, macroclassID, macroclassInfo, classID, classInfo,
                           progress=None, progresStep=None, plot="No", tempROI="No", SCP_UID=None):
        if rasterName is not None and len(rasterName) > 0:
            if progress is not None:
                cfg.uiUtls.updateBar(progress + int((1 / 4) * progresStep))
            else:
                # cfg.uiUtls.updateBar(0)
                pass
            # disable map canvas render for speed
            cfg.cnvs.setRenderFlag(False)
            # date time for temp name
            dT = cfg.utls.getTime()
            # temp subset
            tSN = cfg.subsROINm
            tSD = cfg.tmpDir + "/" + dT + tSN
            # temporary layer
            tLN = cfg.subsTmpROI + dT + ".shp"
            tLP = cfg.tmpDir + "/" + dT + tLN
            # get layer crs
            crs = cfg.utls.getCrs(lyr)
            # create a temp shapefile with a field
            cfg.utls.createEmptyShapefileQGIS(crs, tLP)
            mL = cfg.utls.addVectorLayer(tLP, tLN, "ogr")
            rD = None
            for x in featureIDList:
                # copy ROI to temp shapefile
                cfg.utls.copyFeatureToLayer(lyr, x, mL)
            # calculate ROI center, height and width
            rCX, rCY, rW, rH = cfg.utls.getShapefileRectangleBox(mL)
            if progress is not None:
                cfg.uiUtls.updateBar(progress + int((2 / 4) * progresStep))
            cfg.tblOut = {}
            ROIArray = []
            ROIsize = None
            # band set
            if cfg.bndSetPresent == "Yes" and rasterName == cfg.bndSetNm:
                tLX, tLY, pS = cfg.utls.imageInformation(cfg.bndSet[0])
                cfg.bndSetLst = ""
                # subset
                for b in range(0, len(cfg.bndSet)):
                    tS = str(cfg.tmpDir + "//" + cfg.subsTmpRaster + "_" + str(b) + "_" + dT + ".tif")
                    pr = cfg.utls.subsetImage(cfg.bndSet[b], rCX, rCY, int(round(rW / pS + 3)), int(round(rH / pS + 3)),
                                              tS)
                    if pr == "Yes":
                        # logger
                        cfg.utls.logCondition(
                            str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                            " Error edge")
                        # enable map canvas render
                        cfg.cnvs.setRenderFlag(True)
                        return pr
                    bX = cfg.utls.clipRasterByShapefile(tLP, tS, None)
                    rStat, ar = cfg.utls.getRasterBandStatistics(bX, 1, cfg.bndSetMultAddFactorsList[b])
                    if rStat is None:
                        cfg.mx.msgErr31()
                        # enable map canvas render
                        cfg.cnvs.setRenderFlag(True)
                        return "No"
                    else:
                        if ROIsize is None:
                            ROIsize = cfg.utls.getROISize(bX, 1, rStat[0], rStat[1])
                        rStatStr = str(rStat)
                        rStatStr = rStatStr.replace("nan", "0")
                        rStat = eval(rStatStr)
                        ROIArray.append(ar)
                        cfg.bndSetLst = cfg.bndSetLst + str(tS) + ";"
                        cfg.tblOut["BAND_" + str(b + 1)] = rStat
                        cfg.tblOut["WAVELENGTH_" + str(b + 1)] = cfg.bndSetWvLn["WAVELENGTH_" + str(b + 1)]
                cfg.bndSetLst = cfg.bndSetLst.rstrip(';')
            else:
                # subset
                tLX, tLY, pS = cfg.utls.imageInformation(rasterName)
                tS = str(cfg.tmpDir + "//" + cfg.subsTmpRaster + "_" + dT + ".tif")
                pr = cfg.utls.subsetImage(rasterName, rCX, rCY, int(round(rW / pS + 3)), int(round(rH / pS + 3)),
                                          str(tS))
                if pr == "Yes":
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        " Error edge")
                    # enable map canvas render
                    cfg.cnvs.setRenderFlag(True)
                    return pr
                oList = cfg.utls.rasterToBands(tS, cfg.tmpDir, None, "No", cfg.bndSetMultAddFactorsList)
                rL = cfg.utls.selectLayerbyName(rasterName, "Yes")
                bCount = rL.bandCount()
                for b in range(0, bCount):
                    tS = str(cfg.tmpDir + "//" + cfg.subsTmpRaster + "_" + str(b) + "_" + dT + ".tif")
                    bX = cfg.utls.clipRasterByShapefile(tLP, oList[b], None)
                    rStat, ar = cfg.utls.getRasterBandStatistics(bX, 1)
                    if rStat is None:
                        cfg.mx.msgErr31()
                        # enable map canvas render
                        cfg.cnvs.setRenderFlag(True)
                        return "No"
                    else:
                        if ROIsize is None:
                            ROIsize = cfg.utls.getROISize(bX, 1, rStat[0], rStat[1])
                        rStatStr = str(rStat)
                        rStatStr = rStatStr.replace("nan", "0")
                        rStat = eval(rStatStr)
                        ROIArray.append(ar)
                        cfg.tblOut["BAND_" + str(b + 1)] = rStat
                        cfg.tblOut["WAVELENGTH_" + str(b + 1)] = cfg.bndSetWvLn["WAVELENGTH_" + str(b + 1)]
            if progress is not None:
                cfg.uiUtls.updateBar(progress + int((3 / 4) * progresStep))
            # if not temporary ROI min max
            if tempROI != "MinMax":
                covMat = cfg.utls.calculateCovMatrix(ROIArray)
                if covMat == "No":
                    cfg.mx.msgWar12(macroclassID, classID)
            # remove temp layers
            cfg.utls.removeLayer(tLN)
            cfg.tblOut["ROI_SIZE"] = ROIsize
            # if not temporary ROI min max
            if tempROI != "MinMax":
                cfg.utls.ROIStatisticsToSignature(covMat, macroclassID, macroclassInfo, classID, classInfo,
                                                  cfg.bndSetUnit["UNIT"], plot, tempROI, SCP_UID)
            # enable map canvas render
            cfg.cnvs.setRenderFlag(True)
            if progress is not None:
                cfg.uiUtls.updateBar(progress + int((4 / 4) * progresStep))
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "roi signature calculated")
        else:
            cfg.mx.msg3()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "roi signature not calculated")

    # calculate pixel signature
    def calculatePixelSignature(self, point, rasterName, plot="No", showPlot="Yes"):
        if rasterName is not None and len(rasterName) > 0:
            cfg.tblOut = {}
            cfg.tblOut["ROI_SIZE"] = 1
            rStat = []
            # band set
            if cfg.bndSetPresent == "Yes" and rasterName == cfg.bndSetNm:
                for b in range(0, len(cfg.bndSet)):
                    rast = cfg.utls.selectLayerbyName(cfg.bndSet[b], "Yes")
                    # open input with GDAL
                    try:
                        Or = cfg.gdalSCP.Open(rast.source(), cfg.gdalSCP.GA_ReadOnly)
                    except Exception, err:
                        # logger
                        cfg.utls.logCondition(
                            str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                            " ERROR exception: " + str(err))
                        cfg.mx.msgErr4()
                        return "No"
                    OrB = Or.GetRasterBand(1)
                    geoT = Or.GetGeoTransform()
                    tLX = geoT[0]
                    tLY = geoT[3]
                    pSX = geoT[1]
                    pSY = geoT[5]
                    # start and end pixels
                    pixelStartColumn = (int((point.x() - tLX) / pSX))
                    pixelStartRow = -(int((tLY - point.y()) / pSY))
                    bVal = float(cfg.utls.readArrayBlock(OrB, pixelStartColumn, pixelStartRow, 1, 1)) * \
                           cfg.bndSetMultiFactorsList[b] + cfg.bndSetAddFactorsList[b]
                    rStat = [bVal, bVal, bVal, 0]
                    cfg.tblOut["BAND_" + str(b + 1)] = rStat
                    cfg.tblOut["WAVELENGTH_" + str(b + 1)] = cfg.bndSetWvLn["WAVELENGTH_" + str(b + 1)]
            else:
                rL = cfg.utls.selectLayerbyName(rasterName, "Yes")
                # open input with GDAL
                try:
                    Or = cfg.gdalSCP.Open(rL.source(), cfg.gdalSCP.GA_ReadOnly)
                except Exception, err:
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        " ERROR exception: " + str(err))
                    cfg.mx.msgErr4()
                    return "No"
                bCount = rL.bandCount()
                for b in range(1, bCount + 1):
                    OrB = Or.GetRasterBand(b)
                    geoT = Or.GetGeoTransform()
                    tLX = geoT[0]
                    tLY = geoT[3]
                    pSX = geoT[1]
                    pSY = geoT[5]
                    # start and end pixels
                    pixelStartColumn = (int((point.x() - tLX) / pSX))
                    pixelStartRow = -(int((tLY - point.y()) / pSY))
                    bVal = float(cfg.utls.readArrayBlock(OrB, pixelStartColumn, pixelStartRow, 1, 1)) * \
                           cfg.bndSetMultiFactorsList[b - 1] + cfg.bndSetAddFactorsList[b - 1]
                    rStat = [bVal, bVal, bVal, 0]
                    cfg.tblOut["BAND_" + str(b)] = rStat
                    cfg.tblOut["WAVELENGTH_" + str(b)] = cfg.bndSetWvLn["WAVELENGTH_" + str(b)]
            macroclassID = 0
            classID = 0
            macroclassInfo = cfg.pixelNm
            classInfo = cfg.pixelCoords + " " + str(point)
            covMat = "No"
            val = cfg.utls.ROIStatisticsToSignature(covMat, macroclassID, macroclassInfo, classID, classInfo,
                                                    cfg.bndSetUnit["UNIT"], plot, "No")
            if showPlot == "Yes":
                cfg.spSigPlot.showSignaturePlotT()
            return val

    # Get values for ROI signature
    def ROIStatisticsToSignature(self, covarianceMatrix, macroclassID, macroclassInfo, classID, classInfo, unit=None,
                                 plot="No", tempROI="No", SCP_UID=None):
        if cfg.rstrNm is not None:
            # band set
            if cfg.bndSetPresent == "Yes" and cfg.rstrNm == cfg.bndSetNm:
                iB = len(cfg.bndSet)
            else:
                iR = cfg.utls.selectLayerbyName(cfg.rstrNm, "Yes")
                iB = iR.bandCount()
            wvl = []
            val = []
            valM = []
            min = []
            max = []
            vMin = []
            vMax = []
            ROISize = cfg.tblOut["ROI_SIZE"]
            for b in range(1, iB + 1):
                stats = cfg.tblOut["BAND_" + str(b)]
                w = cfg.tblOut["WAVELENGTH_" + str(b)]
                wvl.append(w)
                vMin.append(stats[0])
                vMax.append(stats[1])
                # values for mean and standard deviation
                vM = stats[2]
                vS = stats[3]
                val.append(vM)
                valM.append(vM)
                val.append(vS)
                # min.append(vM - vS)
                # max.append(vM + vS)
                min = vMin
                max = vMax
                c, cc = cfg.utls.randomColor()
            if plot == "No":
                if SCP_UID is None:
                    i = cfg.utls.signatureID()
                else:
                    i = SCP_UID
                cfg.signList["CHECKBOX_" + str(i)] = cfg.QtSCP.Checked
                cfg.signList["MACROCLASSID_" + str(i)] = macroclassID
                cfg.signList["MACROCLASSINFO_" + str(i)] = macroclassInfo
                cfg.signList["CLASSID_" + str(i)] = classID
                cfg.signList["CLASSINFO_" + str(i)] = classInfo
                cfg.signList["WAVELENGTH_" + str(i)] = wvl
                cfg.signList["VALUES_" + str(i)] = val
                cfg.signList["MIN_VALUE_" + str(i)] = vMin
                cfg.signList["MAX_VALUE_" + str(i)] = vMax
                cfg.signList["ROI_SIZE_" + str(i)] = ROISize
                cfg.signList["LCS_MIN_" + str(i)] = min
                cfg.signList["LCS_MAX_" + str(i)] = max
                cfg.signList["COVMATRIX_" + str(i)] = covarianceMatrix
                cfg.signList["MD_THRESHOLD_" + str(i)] = cfg.algThrshld
                cfg.signList["ML_THRESHOLD_" + str(i)] = cfg.algThrshld
                cfg.signList["SAM_THRESHOLD_" + str(i)] = cfg.algThrshld
                # counter
                n = 0
                m = []
                sdL = []
                for wi in wvl:
                    m.append(val[n * 2])
                    sdL.append(val[n * 2 + 1])
                    n = n + 1
                cfg.signList["MEAN_VALUE_" + str(i)] = m
                cfg.signList["SD_" + str(i)] = sdL
                if unit is None:
                    unit = cfg.bndSetUnit["UNIT"]
                cfg.signList["UNIT_" + str(i)] = unit
                cfg.signList["COLOR_" + str(i)] = c
                # cfg.signList["COMPL_COLOR_" + str(i)] = cc
                cfg.signIDs["ID_" + str(i)] = i
            # calculation for plot
            elif plot == "Yes":
                if SCP_UID is None:
                    i = cfg.utls.signatureID()
                else:
                    i = SCP_UID
                cfg.spectrPlotList["CHECKBOX_" + str(i)] = cfg.QtSCP.Checked
                cfg.spectrPlotList["MACROCLASSID_" + str(i)] = macroclassID
                cfg.spectrPlotList["MACROCLASSINFO_" + str(i)] = macroclassInfo
                cfg.spectrPlotList["CLASSID_" + str(i)] = classID
                cfg.spectrPlotList["CLASSINFO_" + str(i)] = classInfo
                cfg.spectrPlotList["WAVELENGTH_" + str(i)] = wvl
                cfg.spectrPlotList["VALUES_" + str(i)] = val
                cfg.spectrPlotList["LCS_MIN_" + str(i)] = vMin
                cfg.spectrPlotList["LCS_MAX_" + str(i)] = vMax
                cfg.spectrPlotList["MIN_VALUE_" + str(i)] = vMin
                cfg.spectrPlotList["MAX_VALUE_" + str(i)] = vMax
                cfg.spectrPlotList["ROI_SIZE_" + str(i)] = ROISize
                cfg.spectrPlotList["COVMATRIX_" + str(i)] = covarianceMatrix
                cfg.spectrPlotList["MD_THRESHOLD_" + str(i)] = cfg.algThrshld
                cfg.spectrPlotList["ML_THRESHOLD_" + str(i)] = cfg.algThrshld
                cfg.spectrPlotList["SAM_THRESHOLD_" + str(i)] = cfg.algThrshld
                # counter
                n = 0
                m = []
                sdL = []
                for wi in wvl:
                    m.append(val[n * 2])
                    sdL.append(val[n * 2 + 1])
                    n = n + 1
                cfg.spectrPlotList["MEAN_VALUE_" + str(i)] = m
                cfg.spectrPlotList["SD_" + str(i)] = sdL
                if unit is None:
                    unit = cfg.bndSetUnit["UNIT"]
                cfg.spectrPlotList["UNIT_" + str(i)] = unit
                cfg.spectrPlotList["COLOR_" + str(i)] = c
                # cfg.spectrPlotList["COMPL_COLOR_" + str(i)] = cc
                cfg.signPlotIDs["ID_" + str(i)] = i
                if tempROI == "Yes":
                    try:
                        cfg.tmpROIColor = cfg.spectrPlotList["COLOR_" + str(cfg.tmpROIID)]
                        if cfg.spectrPlotList["MACROCLASSINFO_" + str(cfg.tmpROIID)] == cfg.tmpROINm:
                            cfg.spSigPlot.removeSignatureByID(cfg.tmpROIID)
                            cfg.tmpROIID = i
                            cfg.spectrPlotList["COLOR_" + str(i)] = cfg.tmpROIColor
                        else:
                            cfg.tmpROIID = i
                            cfg.spectrPlotList["COLOR_" + str(i)] = cfg.QtGuiSCP.QColor(cfg.ROIClrVal)
                    except:
                        cfg.tmpROIID = i
                        cfg.spectrPlotList["COLOR_" + str(i)] = cfg.QtGuiSCP.QColor(cfg.ROIClrVal)
                # cfg.spSigPlot.signatureListPlotTable(cfg.uisp.signature_list_plot_tableWidget)
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " values to shape concluded, plot: " + str(plot))
            elif plot == "Pixel":
                return valM

    # import a shapefile
    def importShapefile(self):
        shpFile = cfg.ui.select_shapefile_label.text()
        if cfg.shpLay is None:
            cfg.mx.msg3()
            return "No"
        if len(shpFile) > 0:
            cfg.uiUtls.addProgressBar()
            cfg.uiUtls.updateBar(10)
            shpName = cfg.osSCP.path.basename(unicode(shpFile))
            tSS = cfg.utls.addVectorLayer(shpFile, shpName, "ogr")
            # create memory layer
            provider = tSS.dataProvider()
            fields = provider.fields()
            tCrs = cfg.utls.getCrs(cfg.shpLay)
            pCrs = cfg.utls.getCrs(tSS)
            f = QgsFeature()
            mcIdF = self.fieldID(tSS, cfg.ui.MC_ID_combo.currentText())
            mcInfoF = self.fieldID(tSS, cfg.ui.MC_Info_combo.currentText())
            cIdF = self.fieldID(tSS, cfg.ui.C_ID_combo.currentText())
            cInfoF = self.fieldID(tSS, cfg.ui.C_Info_combo.currentText())
            for f in tSS.getFeatures():
                cfg.shpLay.startEditing()
                aF = f.geometry()
                if pCrs != tCrs:
                    # transform coordinates
                    trs = QgsCoordinateTransform(pCrs, tCrs)
                    aF.transform(trs)
                oF = QgsFeature()
                oF.setGeometry(aF)
                mcIdV = f.attributes()[mcIdF]
                try:
                    mcId = int(mcIdV)
                except:
                    mcId = cfg.ROIMacroID
                mcInfo = f.attributes()[mcInfoF]
                cIdV = f.attributes()[cIdF]
                try:
                    cId = int(cIdV)
                except:
                    cId = cfg.ROIID
                cInfo = f.attributes()[cInfoF]
                i = cfg.utls.signatureID()
                attributeList = [mcId, mcInfo, cId, cInfo, i]
                oF.setAttributes(attributeList)
                cfg.shpLay.addFeature(oF)
                cfg.shpLay.commitChanges()
                cfg.shpLay.dataProvider().createSpatialIndex()
                cfg.shpLay.updateExtents()
                cfg.uiUtls.updateBar(40)
                # calculate signature if checkbox is yes
                if cfg.ui.signature_checkBox_2.isChecked() is True:
                    rId = cfg.utls.getIDByAttributes(cfg.shpLay, cfg.fldSCP_UID, str(i))
                    cfg.utls.calculateSignature(cfg.shpLay, cfg.rstrNm, rId, mcId, mcInfo, cId, cInfo, None, None, "No",
                                                "No", i)
                    cfg.uiUtls.updateBar(90)
                # try:
                # 	c = cfg.signList["COLOR_" + str(i)]
                # 	cfg.classD.checkMCIDList(mcId, mcInfo, c)
                # except:
                # 	c, cc = cfg.utls.randomColor()
                # 	cfg.classD.checkMCIDList(mcId, mcInfo, c)`
            # cfg.classD.ROIListTable(cfg.trnLay, cfg.uidc.signature_list_tableWidget)
            cfg.uiUtls.updateBar(100)
            cfg.uiUtls.removeProgressBar()

    ##################################
    """ Process functions """

    ##################################

    # create value list from text
    def textToValueList(self, text):
        vList = []
        if "," in text:
            c = text.split(",")
        elif "-" in text:
            v = text.split("-")
            for z in range(int(v[0]), int(v[-1]) + 1):
                vList.append(int(z))
            c = []
        else:
            vList.append(int(text))
            c = []
        for b in c:
            if "-" in b:
                v = b.split("-")
                for z in range(int(v[0]), int(v[-1]) + 1):
                    vList.append(int(z))
            else:
                vList.append(int(b))
        uList = cfg.np.unique(vList).tolist()
        return uList

    # create 3x3 window
    def create3x3Window(self, connection="8"):
        size = 3
        B = cfg.np.ones((size, size))
        if connection != "8":
            # 4 cells
            B[0, 0] = 0
            B[0, 2] = 0
            B[2, 0] = 0
            B[2, 2] = 0
        return B

    # scatter plot raster
    def createScatterPlotRasterCondition(self, rangeList, weightList=None, nodataValue=-999):
        if weightList is not None:
            c = 0
            for w in weightList:
                # bandX *= w
                # bandY *= w
                c = c + 1
        condit1 = ""
        condit2 = ""
        bandX = cfg.np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
        bandY = cfg.np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
        for list in rangeList:
            for range in list[0]:
                Xmin = range[0][0]
                Xmax = range[0][1]
                Ymin = range[1][0]
                Ymax = range[1][1]
                condit1 = condit1 + "cfg.np.where( (bandX >= " + str(Xmin) + ") & (bandX <= " + str(
                    Xmax) + ") & (bandY >= " + str(Ymin) + ") & (bandY <= " + str(Ymax) + "), " + str(list[1]) + ", "
                condit2 = condit2 + ")"
        condit1 = condit1[:-2] + ", " + str(nodataValue) + condit2
        try:
            algArray = eval(condit1)
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return 0
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
        return condit1

    # scatter plot raster
    def singleScatterPlotRasterCondition(self, rangeList, weightList=None, nodataValue=-999):
        if weightList is not None:
            c = 0
            for w in weightList:
                # bandX *= w
                # bandY *= w
                c = c + 1
        conditions = []
        for list in rangeList:
            for range in list[0]:
                Xmin = range[0][0]
                Xmax = range[0][1]
                Ymin = range[1][0]
                Ymax = range[1][1]
                condit1 = "cfg.np.where( (bandX >= " + str(Xmin) + ") & (bandX <= " + str(
                    Xmax) + ") & (bandY >= " + str(Ymin) + ") & (bandY <= " + str(Ymax) + "), " + str(
                    list[1]) + ", " + str(nodataValue) + ")"
                conditions.append(condit1)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
        return conditions

    # get UID
    def signatureID(self):
        dT = cfg.utls.getTime()
        r = cfg.randomSCP.randint(100, 999)
        i = dT + "_" + str(r)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              " ID" + str(i))
        return i

    # calculate unique CID and MCID list
    def calculateUnique_CID_MCID(self):
        unique = []
        if len(cfg.signIDs.values()) > 0:
            for i in cfg.signIDs.values():
                unique.append(
                    str(cfg.signList["CLASSID_" + str(i)]) + "-" + str(cfg.signList["MACROCLASSID_" + str(i)]))
            l = set(unique)
            list = cfg.utls.uniqueToOrderedList(l)
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " unique" + str(list))
            return list
        else:
            return "No"

    # find DNmin in raster for DOS1
    def findDNmin(self, inputRaster, noDataVal=None):
        DNm = 0
        cfg.rasterBandUniqueVal = cfg.np.zeros((1, 1))
        cfg.rasterBandUniqueVal = cfg.np.delete(cfg.rasterBandUniqueVal, 0, 1)
        # open input with GDAL
        rD = cfg.gdalSCP.Open(inputRaster, cfg.gdalSCP.GA_ReadOnly)
        # band list
        bL = cfg.utls.readAllBandsFromRaster(rD)
        # No data value
        nD = noDataVal
        o = cfg.utls.processRaster(rD, bL, None, "No", cfg.utls.rasterUniqueValues, None, None, None, None, 0, None,
                                   cfg.NoDataVal, "No", nD, None, "UniqueVal")
        cfg.rasterBandUniqueVal = cfg.np.unique(cfg.rasterBandUniqueVal).tolist()
        cfg.rasterBandUniqueVal = sorted(cfg.rasterBandUniqueVal)
        try:
            cfg.rasterBandUniqueVal.remove(nD)
        except:
            pass
        cfg.rasterBandPixelCount = 0
        o = cfg.utls.processRaster(rD, bL, None, "No", cfg.utls.rasterValueCount, None, None, None, None, 0, None,
                                   cfg.NoDataVal, "No", nD, cfg.rasterBandUniqueVal[-1], "Sum")
        sum = cfg.rasterBandPixelCount
        pT1pc = sum * 0.0001
        min = 0
        max = len(cfg.rasterBandUniqueVal)
        for i in range(0, len(cfg.rasterBandUniqueVal)):
            if i == 0:
                pos = int(round((max + min) / 4))
            else:
                pos = int(round((max + min) / 2))
            DNm = cfg.rasterBandUniqueVal[pos]
            cfg.rasterBandPixelCount = 0
            o = cfg.utls.processRaster(rD, bL, None, "No", cfg.utls.rasterValueCount, None, None, None, None, 0, None,
                                       cfg.NoDataVal, "No", nD, DNm, "DNmin " + str(DNm))
            newSum = cfg.rasterBandPixelCount
            if newSum <= pT1pc:
                min = pos
            else:
                max = pos
            if int(round(max - min)) <= 1:
                break
        for b in range(0, len(bL)):
            bL[b] = None
        rD = None
        cfg.rasterBandUniqueVal = None
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              " DNm " + unicode(DNm))
        return DNm

    # unique CID and MCID list to ordered list
    def uniqueToOrderedList(self, uniqueList):
        list = []
        for i in uniqueList:
            v = i.split("-")
            list.append([int(v[0]), int(v[1])])
        sortedList = sorted(list, key=lambda list: (list[0], list[1]))
        return sortedList

    # calculate block size
    def calculateBlockSize(self, bandNumber):
        if cfg.sysSCP64bit == "No" and cfg.sysSCPNm == "Windows":
            mem = 512
        else:
            mem = cfg.RAMValue
        b = int((mem / (cfg.arrayUnitMemory * (bandNumber + 5))) ** .5)
        # set system memory max
        if cfg.sysSCP64bit == "No" and b > 2500:
            b = 2500
        # check memory
        try:
            a = cfg.np.zeros((b, b), dtype=cfg.np.float32)
            cfg.uiUtls.updateBar(20, cfg.QtGuiSCP.QApplication.translate("semiautomaticclassificationplugin",
                                                                         "Please wait ..."))
        except:
            for i in reversed(range(128, mem, int(mem / 10))):
                try:
                    b = int((i / (cfg.arrayUnitMemory * (bandNumber + 5))) ** .5)
                    # set system memory max
                    if cfg.sysSCP64bit == "No" and b > 2500:
                        b = 2500
                    a = cfg.np.zeros((int(b), int(b)), dtype=cfg.np.float32)
                    size = a.nbytes / 1048576
                    cfg.ui.RAM_spinBox.setValue(size * bandNumber)
                    cfg.mx.msgWar11()
                    cfg.uiUtls.updateBar(20, cfg.QtGuiSCP.QApplication.translate("semiautomaticclassificationplugin",
                                                                                 "Please wait ..."))
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        "block = " + str(b))
                    return b
                except Exception, err:
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        " ERROR exception: " + str(err))
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "block = " + str(b))
        return b

    # check band set and create band set list
    def checkBandSet(self):
        ck = "Yes"
        # list of bands for algorithm
        cfg.bndSetLst = []
        for x in range(0, len(cfg.bndSet)):
            b = cfg.utls.selectLayerbyName(cfg.bndSet[x], "Yes")
            if b is not None:
                cfg.bndSetLst.append(b.source())
            else:
                ck = "No"
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " raster is not loaded: " + unicode(cfg.bndSet[x]))
                return ck
        return ck

    # check if the clicked point is inside the image
    def checkPointImage(self, imageName, point, quiet="No"):
        # band set
        if cfg.bndSetPresent == "Yes" and imageName == cfg.bndSetNm:
            imageName = cfg.bndSet[0]
            # image CRS
            bN0 = self.selectLayerbyName(imageName, "Yes")
            iCrs = self.getCrs(bN0)
            if iCrs is None:
                iCrs = cfg.utls.getQGISCrs()
                pCrs = iCrs
            else:
                # projection of input point from project's crs to raster's crs
                pCrs = cfg.utls.getQGISCrs()
                if pCrs != iCrs:
                    try:
                        point = cfg.utls.projectPointCoordinates(point, pCrs, iCrs)
                        if point is False:
                            cfg.pntCheck = "No"
                            cfg.utls.setQGISCrs(iCrs)
                            return "No"
                    # Error latitude or longitude exceeded limits
                    except Exception, err:
                        # logger
                        cfg.utls.logCondition(
                            str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                            " ERROR exception: " + str(err))
                        crs = None
                        # logger
                        cfg.utls.logCondition(
                            str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                            cfg.QtGuiSCP.QApplication.translate("semiautomaticclassificationplugin",
                                                                "Error") + ": latitude or longitude exceeded limits")
                        cfg.pntCheck = "No"
                        return "No"
            # workaround coordinates issue
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "project crs: " + unicode(pCrs.toProj4()) + " - raster " + unicode(
                                      imageName) + " crs: " + unicode(iCrs.toProj4()))
            cfg.lstPnt = QgsPoint(point.x() / float(1), point.y() / float(1))
            pX = point.x()
            pY = point.y()
            i = self.selectLayerbyName(imageName, "Yes")
            if i is not None:
                # Point Check
                cfg.pntCheck = None
                if pX > i.extent().xMaximum() or pX < i.extent().xMinimum() or pY > i.extent().yMaximum() or pY < i.extent().yMinimum():
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        "point outside the image area")
                    if quiet == "No":
                        cfg.mx.msg6()
                    cfg.pntCheck = "No"
                else:
                    cfg.pntCheck = "Yes"
                    return cfg.lstPnt
            else:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " image missing")
                if quiet == "No":
                    cfg.mx.msg4()
                    cfg.pntCheck = "No"
        else:
            if self.selectLayerbyName(imageName, "Yes") is None:
                if quiet == "No":
                    cfg.mx.msg4()
                # cfg.ipt.refreshRasterLayer()
                self.pntROI = None
                cfg.pntCheck = "No"
            else:
                # image CRS
                bN0 = self.selectLayerbyName(imageName, "Yes")
                iCrs = self.getCrs(bN0)
                if iCrs is None:
                    iCrs = None
                else:
                    # projection of input point from project's crs to raster's crs
                    pCrs = cfg.utls.getQGISCrs()
                    if pCrs != iCrs:
                        try:
                            point = cfg.utls.projectPointCoordinates(point, pCrs, iCrs)
                            if point is False:
                                cfg.pntCheck = "No"
                                cfg.utls.setQGISCrs(iCrs)
                                return "No"
                        # Error latitude or longitude exceeded limits
                        except Exception, err:
                            # logger
                            cfg.utls.logCondition(
                                str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                " ERROR exception: " + str(err))
                            crs = None
                            # logger
                            cfg.utls.logCondition(
                                str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                cfg.QtGuiSCP.QApplication.translate("semiautomaticclassificationplugin",
                                                                    "Error") + ": latitude or longitude exceeded limits")
                            cfg.pntCheck = "No"
                            return "No"
                # workaround coordinates issue
                if quiet == "No":
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        "project crs: " + unicode(pCrs.toProj4()) + " - raster " + unicode(
                            imageName) + " crs: " + unicode(iCrs.toProj4()))
                cfg.lstPnt = QgsPoint(point.x() / float(1), point.y() / float(1))
                pX = point.x()
                pY = point.y()
                i = self.selectLayerbyName(imageName, "Yes")
                # Point Check
                cfg.pntCheck = None
                if pX > i.extent().xMaximum() or pX < i.extent().xMinimum() or pY > i.extent().yMaximum() or pY < i.extent().yMinimum():
                    if quiet == "No":
                        cfg.mx.msg6()
                        # logger
                        cfg.utls.logCondition(
                            str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                            "point outside the image area")
                    cfg.pntCheck = "No"
                else:
                    cfg.pntCheck = "Yes"
                    return cfg.lstPnt

    # create virtual raster with Python
    def createVirtualRaster2(self, inputRasterList, output, bandNumberList="No", quiet="No", NoDataVal="No",
                             relativeToVRT=0, pansharp="No", intersection="Yes", boxCoordList=None, xyResList=None):
        # create virtual raster
        drv = cfg.gdalSCP.GetDriverByName("VRT")
        rXList = []
        rYList = []
        topList = []
        leftList = []
        rightList = []
        bottomList = []
        pXSizeList = []
        pYSizeList = []
        epsgList = []
        for b in inputRasterList:
            gdalRaster = cfg.gdalSCP.Open(b, cfg.gdalSCP.GA_ReadOnly)
            gt = gdalRaster.GetGeoTransform()
            rP = gdalRaster.GetProjection()
            if rP == "":
                cfg.mx.msgErr47()
                return "Yes"
            # check projections
            try:
                rPSys = cfg.osrSCP.SpatialReference(wkt=rP)
                rPSys.AutoIdentifyEPSG()
                rPRS = rPSys.GetAuthorityCode(None)
                epsgList.append(int(rPRS))
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
            pXSizeList.append(abs(gt[1]))
            pYSizeList.append(abs(gt[5]))
            leftList.append(gt[0])
            topList.append(gt[3])
            rightList.append(gt[0] + gt[1] * gdalRaster.RasterXSize)
            bottomList.append(gt[3] + gt[5] * gdalRaster.RasterYSize)
            # number of x pixels
            rXList.append(float(gdalRaster.RasterXSize))
            # number of y pixels
            rYList.append(float(gdalRaster.RasterYSize))
            gdalRaster = None
        # check projections
        epsgListI = list(set(epsgList))
        if len(epsgListI) > 1:
            cfg.mx.msgErr60()
        # find raster box
        iLeft = min(leftList)
        iTop = max(topList)
        iRight = max(rightList)
        iBottom = min(bottomList)
        # find intersection box
        xLeft = max(leftList)
        xTop = min(topList)
        xRight = min(rightList)
        xBottom = max(bottomList)
        # highest resolution
        pXSize = min(pXSizeList)
        pYSize = min(pYSizeList)
        if xyResList is not None:
            pXSize = xyResList[0]
            pYSize = xyResList[1]
        if boxCoordList is not None:
            try:
                override = boxCoordList[4]
                if override == "Yes":
                    # find raster box
                    if iLeft < boxCoordList[0]:
                        iLeft = iLeft + abs(int(round((iLeft - boxCoordList[0]) / pXSize))) * pXSize
                    else:
                        iLeft = iLeft - abs(int(round((iLeft - boxCoordList[0]) / pXSize))) * pXSize
                    if iTop > boxCoordList[1]:
                        iTop = iTop - abs(int(round((iTop - boxCoordList[1]) / pYSize))) * pYSize
                    else:
                        iTop = iTop + abs(int(round((iTop - boxCoordList[1]) / pYSize))) * pYSize
                    if iRight > boxCoordList[2]:
                        iRight = iRight - abs(int(round((iRight - boxCoordList[2]) / pXSize))) * pXSize
                    else:
                        iRight = iRight + abs(int(round((iRight - boxCoordList[2]) / pXSize))) * pXSize
                    if iBottom < boxCoordList[3]:
                        iBottom = iBottom + abs(int(round((iBottom - boxCoordList[3]) / pYSize))) * pYSize
                    else:
                        iBottom = iBottom - abs(int(round((iBottom - boxCoordList[3]) / pYSize))) * pYSize
            except:
                # find raster box
                if iLeft < boxCoordList[0]:
                    iLeft = iLeft + abs(int(round((iLeft - boxCoordList[0]) / pXSize))) * pXSize
                if iTop > boxCoordList[1]:
                    iTop = iTop - abs(int(round((iTop - boxCoordList[1]) / pYSize))) * pYSize
                if iRight > boxCoordList[2]:
                    iRight = iRight - abs(int(round((iRight - boxCoordList[2]) / pXSize))) * pXSize
                if iBottom < boxCoordList[3]:
                    iBottom = iBottom + abs(int(round((iBottom - boxCoordList[3]) / pYSize))) * pYSize
                # find intersection box
                if xLeft < boxCoordList[0]:
                    xLeft = xLeft + abs(int(round((xLeft - boxCoordList[0]) / pXSize))) * pXSize
                if xTop > boxCoordList[1]:
                    xTop = xTop - abs(int(round((xTop - boxCoordList[1]) / pYSize))) * pYSize
                if xRight > boxCoordList[2]:
                    xRight = xRight - abs(int(round((xRight - boxCoordList[2]) / pXSize))) * pXSize
                if xBottom < boxCoordList[3]:
                    xBottom = xBottom + abs(int(round((xBottom - boxCoordList[3]) / pYSize))) * pYSize
        if xyResList is not None:
            iLeft = xyResList[2]
            iTop = xyResList[3]
            iRight = xyResList[4]
            iBottom = xyResList[5]
        # number of x pixels
        if intersection == "Yes":
            rX = abs(int(round((xRight - xLeft) / pXSize)))
            rY = abs(int(round((xTop - xBottom) / pYSize)))
        else:
            rX = abs(int(round((iRight - iLeft) / pXSize)))
            rY = abs(int(round((iTop - iBottom) / pYSize)))
        # create virtual raster
        vRast = drv.Create(output, rX, rY, 0)
        # set raster projection from reference intersection
        if intersection == "Yes":
            vRast.SetGeoTransform((xLeft, pXSize, 0, xTop, 0, -pYSize))
        else:
            vRast.SetGeoTransform((iLeft, pXSize, 0, iTop, 0, -pYSize))
        vRast.SetProjection(rP)
        if len(inputRasterList) == 1 and bandNumberList != "No":
            x = 0
            gdalRaster2 = cfg.gdalSCP.Open(b, cfg.gdalSCP.GA_ReadOnly)
            try:
                for b in bandNumberList:
                    gBand2 = gdalRaster2.GetRasterBand(int(b))
                    noData = gBand2.GetNoDataValue()
                    if noData is None or str(noData) == "nan":
                        noData = cfg.NoDataVal
                    gt = gdalRaster2.GetGeoTransform()
                    pX = abs(gt[1])
                    pY = abs(gt[5])
                    left = gt[0]
                    top = gt[3]
                    bsize2 = gBand2.GetBlockSize()
                    x_block = bsize2[0]
                    y_block = bsize2[1]
                    # number of x pixels
                    rX2 = int(round(gdalRaster2.RasterXSize * pX / pXSize))
                    # number of y pixels
                    rY2 = int(round(gdalRaster2.RasterYSize * pY / pYSize))
                    # offset
                    if intersection == "Yes":
                        xoffX = abs(int(round((left - xLeft) / pX)))
                        xoffY = abs(int(round((xTop - top) / pY)))
                        offX = 0
                        offY = 0
                    else:
                        offX = abs(int(round((left - iLeft) / pXSize)))
                        offY = int(round((iTop - top) / pYSize))
                        xoffX = 0
                        xoffY = 0
                    try:
                        override = boxCoordList[4]
                        if override == "Yes":
                            if iLeft < left:
                                xoffX = 0
                                offX = abs(int(round((left - iLeft) / pXSize)))
                            else:
                                xoffX = abs(int(round((left - iLeft) / pX)))
                                offX = 0
                            if iTop > top:
                                xoffY = 0
                                offY = abs(int(round((iTop - top) / pYSize)))
                            else:
                                xoffY = abs(int(round((iTop - top) / pY)))
                                offY = 0
                    except:
                        pass
                    vRast.AddBand(cfg.gdalSCP.GDT_Float32)
                    bandNumber = bandNumberList[x]
                    band = vRast.GetRasterBand(x + 1)
                    bsize = band.GetBlockSize()
                    x_block = bsize[0]
                    y_block = bsize[1]
                    # check path
                    source_path = inputRasterList[0]
                    try:
                        source_path = source_path.encode(cfg.sysSCP.getfilesystemencoding())
                    except:
                        pass
                    # set metadata xml
                    xml = """
					<ComplexSource>
					  <SourceFilename relativeToVRT="%i">%s</SourceFilename>
					  <SourceBand>%i</SourceBand>
					  <SourceProperties RasterXSize="%i" RasterYSize="%i" DataType=%s BlockXSize="%i" BlockYSize="%i" />
					  <SrcRect xOff="%i" yOff="%i" xSize="%i" ySize="%i" />
					  <DstRect xOff="%i" yOff="%i" xSize="%i" ySize="%i" />
					  <NODATA>%i</NODATA>
					</ComplexSource>
					"""
                    source = xml % (
                    relativeToVRT, source_path, bandNumber, gdalRaster2.RasterXSize, gdalRaster2.RasterYSize, "Float32",
                    x_block, y_block, xoffX, xoffY, gdalRaster2.RasterXSize, gdalRaster2.RasterYSize, offX, offY, rX2,
                    rY2, noData)
                    band.SetMetadataItem("ComplexSource", source, "new_vrt_sources")
                    if NoDataVal == "Yes":
                        band.SetNoDataValue(noData)
                    elif NoDataVal != "No":
                        band.SetNoDataValue(NoDataVal)
                    band = None
                    gBand2 = None
                    x = x + 1
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
            gdalRaster2 = None
        else:
            x = 0
            for b in inputRasterList:
                gdalRaster2 = cfg.gdalSCP.Open(b, cfg.gdalSCP.GA_ReadOnly)
                gdalBandNumber = gdalRaster2.RasterCount
                for bb in range(1, gdalBandNumber + 1):
                    gBand2 = gdalRaster2.GetRasterBand(bb)
                    noData = gBand2.GetNoDataValue()
                    if noData is None:
                        noData = cfg.NoDataVal
                    gt = gdalRaster2.GetGeoTransform()
                    pX = abs(gt[1])
                    pY = abs(gt[5])
                    left = gt[0]
                    top = gt[3]
                    bsize2 = gBand2.GetBlockSize()
                    x_block = bsize2[0]
                    y_block = bsize2[1]
                    # number of x pixels
                    rX2 = int(round(gdalRaster2.RasterXSize * pX / pXSize))
                    # number of y pixels
                    rY2 = int(round(gdalRaster2.RasterYSize * pY / pYSize))
                    # offset
                    if intersection == "Yes":
                        xoffX = abs(int(round((left - xLeft) / pX)))
                        xoffY = abs(int(round((xTop - top) / pY)))
                        offX = 0
                        offY = 0
                    else:
                        offX = abs(int(round((left - iLeft) / pXSize)))
                        offY = int(round((iTop - top) / pYSize))
                        xoffX = 0
                        xoffY = 0
                    try:
                        override = boxCoordList[4]
                        if override == "Yes":
                            if iLeft < left:
                                xoffX = 0
                                offX = abs(int(round((left - iLeft) / pXSize)))
                            else:
                                xoffX = abs(int(round((left - iLeft) / pX)))
                                offX = 0
                            if iTop > top:
                                xoffY = 0
                                offY = abs(int(round((iTop - top) / pYSize)))
                            else:
                                xoffY = abs(int(round((iTop - top) / pY)))
                                offY = 0
                    except:
                        pass
                    gBand2 = None
                    vRast.AddBand(cfg.gdalSCP.GDT_Float32)
                    try:
                        errorCheck = "Yes"
                        if bandNumberList == "No":
                            bandNumber = 1
                        else:
                            bandNumber = bandNumberList[x]
                        errorCheck = "No"
                        band = vRast.GetRasterBand(x + 1)
                        bsize = band.GetBlockSize()
                        x_block = bsize[0]
                        y_block = bsize[1]
                        # check path
                        source_path = b.replace("//", "/")
                        try:
                            source_path = source_path.encode(cfg.sysSCP.getfilesystemencoding())
                        except:
                            pass
                        # set metadata xml
                        xml = """
						<ComplexSource>
						  <SourceFilename relativeToVRT="%i">%s</SourceFilename>
						  <SourceBand>%i</SourceBand>
						  <SourceProperties RasterXSize="%i" RasterYSize="%i" DataType=%s BlockXSize="%i" BlockYSize="%i" />
						  <SrcRect xOff="%i" yOff="%i" xSize="%i" ySize="%i" />
						  <DstRect xOff="%i" yOff="%i" xSize="%i" ySize="%i" />
						  <NODATA>%i</NODATA>
						</ComplexSource>
						"""
                        source = xml % (
                        relativeToVRT, source_path, bandNumber, gdalRaster2.RasterXSize, gdalRaster2.RasterYSize,
                        "Float32", x_block, y_block, xoffX, xoffY, gdalRaster2.RasterXSize, gdalRaster2.RasterYSize,
                        offX, offY, rX2, rY2, noData)
                        band.SetMetadataItem("ComplexSource", source, "new_vrt_sources")
                        if NoDataVal == "Yes":
                            band.SetNoDataValue(noData)
                        elif NoDataVal != "No":
                            band.SetNoDataValue(NoDataVal)
                        band = None
                        x = x + 1
                    except Exception, err:
                        if errorCheck == "No":
                            # logger
                            cfg.utls.logCondition(
                                str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                " ERROR exception: " + str(err))
                gdalRaster2 = None
        vRast = None
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "virtual raster: " + unicode(output))
        return unicode(output)

    # calculate raster block ranges
    def rasterBlocks(self, gdalRaster, blockSizeX=1, blockSizeY=1, previewSize=0, previewPoint=None):
        # number of x pixels
        rX = gdalRaster.RasterXSize
        # number of y pixels
        rY = gdalRaster.RasterYSize
        # list of range pixels
        lX = None
        lY = None
        if blockSizeX != 1 or blockSizeY != 1:
            lX = range(0, rX, blockSizeX)
            lY = range(0, rY, blockSizeY)
        # classification preview
        if previewPoint != None:
            geoT = gdalRaster.GetGeoTransform()
            tLX = geoT[0]
            tLY = geoT[3]
            pSX = geoT[1]
            pSY = geoT[5]
            # start and end pixels
            sX = (int((previewPoint.x() - tLX) / pSX)) - int(previewSize / 2)
            eX = (int((previewPoint.x() - tLX) / pSX)) + int(previewSize / 2)
            sY = -(int((tLY - previewPoint.y()) / pSY)) - int(previewSize / 2)
            eY = -(int((tLY - previewPoint.y()) / pSY)) + int(previewSize / 2)
            # if start outside image
            if sX < 0:
                sX = 0
            if sY < 0:
                sY = 0
            if eX > rX:
                eX = rX
            if eY > rY:
                eY = rY
            if blockSizeX > previewSize:
                blockSizeX = previewSize
            if blockSizeY > previewSize:
                blockSizeY = previewSize
            # raster range blocks
            if previewSize > 1:
                lX = range(sX, eX, blockSizeX)
                lY = range(sY, eY, blockSizeY)
            else:
                lX = [sX]
                lY = [sY]
            # preview range blocks
            pX = range(0, previewSize, blockSizeX)
            pY = range(0, previewSize, blockSizeY)
        # if not preview
        else:
            # set pX and pY if not preview
            pX = lX
            pY = lY
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
        return rX, rY, lX, lY, pX, pY

    # read a block of band as array
    def readArrayBlock(self, gdalBand, pixelStartColumn, pixelStartRow, blockColumns, blockRow):
        # gdalBand.SetNoDataValue(-999)
        a = gdalBand.ReadAsArray(pixelStartColumn, pixelStartRow, blockColumns, blockRow)
        return a

    # apply multiplicative and additivie factors to array
    def arrayMultiplicativeAdditiveFactors(self, array, multiplicativeFactor, additiveFactor):
        a = array * float(multiplicativeFactor) + float(additiveFactor)
        return a

    # write an array to band
    def writeArrayBlock(self, gdalRaster, bandNumber, dataArray, pixelStartColumn, pixelStartRow, nodataValue=None):
        b = gdalRaster.GetRasterBand(bandNumber)
        x = gdalRaster.RasterXSize - pixelStartColumn
        y = gdalRaster.RasterYSize - pixelStartRow
        dataArray = dataArray[:y, :x]
        b.WriteArray(dataArray, pixelStartColumn, pixelStartRow)
        if nodataValue is not None:
            b.SetNoDataValue(nodataValue)
        b.FlushCache()
        b = None

    # create raster from another raster
    def createRasterFromReference(self, gdalRasterRef, bandNumber, outputRasterList, nodataValue=None, driver="GTiff",
                                  format="Float32", previewSize=0, previewPoint=None, compress="No",
                                  compressFormat="DEFLATE21", projection=None, geotransform=None):
        oRL = []
        if format == "Float64":
            format = cfg.gdalSCP.GDT_Float64
        elif format == "Float32":
            format = cfg.gdalSCP.GDT_Float32
        for o in outputRasterList:
            # pixel size and origin from reference
            if projection is None:
                rP = gdalRasterRef.GetProjection()
            else:
                rP = projection
            if geotransform is None:
                rGT = gdalRasterRef.GetGeoTransform()
            else:
                rGT = geotransform
            tD = cfg.gdalSCP.GetDriverByName(driver)
            c = gdalRasterRef.RasterXSize
            r = gdalRasterRef.RasterYSize
            if previewSize > 0:
                tLX = rGT[0]
                tLY = rGT[3]
                pSX = rGT[1]
                pSY = rGT[5]
                sX = int((previewPoint.x() - tLX) / pSX) - int(previewSize / 2)
                sY = int((tLY - previewPoint.y()) / cfg.np.sqrt(pSY ** 2)) - int(previewSize / 2)
                lX = tLX + sX * pSX
                tY = tLY + sY * pSY
                if tY > tLY:
                    tY = tLY
                if lX < tLX:
                    lX = tLX
                if previewSize < c:
                    c = previewSize
                if previewSize < r:
                    r = previewSize
                rGT = (lX, rGT[1], rGT[2], tY, rGT[4], rGT[5])
            if compress == "No":
                oR = tD.Create(o, c, r, bandNumber, format)
            elif compress == "DEFLATE21":
                oR = tD.Create(o, c, r, bandNumber, format, options=['COMPRESS=DEFLATE', 'PREDICTOR=2', 'ZLEVEL=1'])
            else:
                oR = tD.Create(o, c, r, bandNumber, format, ['COMPRESS=' + compressFormat])
            # set raster projection from reference
            oR.SetGeoTransform(rGT)
            oR.SetProjection(rP)
            oRL.append(oR)
            if nodataValue is not None:
                for x in range(1, bandNumber + 1):
                    b = oR.GetRasterBand(x)
                    b.SetNoDataValue(nodataValue)
                    b.Fill(nodataValue)
                    b = None
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "" + unicode(outputRasterList))
        return oRL

    # clip a raster using a shapefile
    def clipRasterByShapefile(self, shapefile, raster, outputRaster=None, outFormat="GTiff"):
        # date time for temp name
        dT = cfg.utls.getTime()
        if outputRaster is None:
            # temp files
            tRN = cfg.copyTmpROI + dT + ".tif"
            tR = str(cfg.tmpDir + "//" + tRN)
        else:
            tR = str(outputRaster)
        # convert polygon to raster
        tRNxs = cfg.copyTmpROI + dT + "xs.tif"
        tRxs = str(cfg.tmpDir + "//" + tRNxs)
        burnValues = 1
        conversionType = None
        if cfg.osSCP.path.isfile(shapefile):
            check = cfg.utls.vectorToRaster(cfg.emptyFN, shapefile, cfg.emptyFN, tRxs, raster, conversionType, "GTiff",
                                            burnValues)
        else:
            return "No"
        if check != "No":
            cfg.utls.clipRasterByRaster(raster, tRxs, tR, outFormat, cfg.NoDataVal)
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "shapefile " + unicode(shapefile) + "raster " + unicode(raster) + "tR " + unicode(tR))
            return tR
        else:
            return "No"

    # clip raster with another raster
    def clipRasterByRaster(self, rasterClipped, rasterClipping, outputRaster=None, outFormat="GTiff", nodataValue=None):
        dT = self.getTime()
        tPMN = cfg.tmpVrtNm + ".vrt"
        tPMD = cfg.tmpDir + "/" + dT + tPMN
        bList = [rasterClipped, rasterClipping]
        iBC = cfg.utls.getNumberBandRaster(rasterClipped)
        # create band list of clipped bands and clipping band
        bandNumberList = []
        for cc in range(1, iBC + 1):
            bandNumberList.append(cc)
        bandNumberList.append(1)
        vrtCheck = cfg.utls.createVirtualRaster2(bList, tPMD, bandNumberList, "Yes", cfg.NoDataVal, 0)
        # open input with GDAL
        rD = cfg.gdalSCP.Open(tPMD, cfg.gdalSCP.GA_ReadOnly)
        if rD is None:
            cfg.mx.msg4()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " None raster")
            cfg.uiUtls.removeProgressBar()
            cfg.cnvs.setRenderFlag(True)
            return "No"
        try:
            # band list
            bL = cfg.utls.readAllBandsFromRaster(rD)
            bC = len(bL)
            # output rasters
            oM = []
            oM.append(outputRaster)
            oMR = cfg.utls.createRasterFromReference(rD, bC - 1, oM, cfg.NoDataVal, "GTiff", cfg.rasterDataType, 0,
                                                     None, "No")
            for bb in range(0, bC - 1):
                e = str("a * b")
                variableList = [["im1", "a"], ["im2", "b"]]
                o = cfg.utls.processRaster(rD, [bL[bb], bL[bC - 1]], None, "No", cfg.utls.bandCalculation, None, oMR,
                                           None, None, 0, None, cfg.NoDataVal, "No", e, variableList, "No")
            # close GDAL rasters
            for b in range(0, len(oMR)):
                oMR[b] = None
            for b in range(0, len(bL)):
                bL[b] = None
            rD = None
        # in case of errors
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "raster " + unicode(outputRaster))
        return outputRaster

    # copy a raster
    def copyRaster(self, raster, outputRaster=None, outFormat="GTiff", nodataValue=None):
        # open input with GDAL
        rD = cfg.gdalSCP.Open(raster, cfg.gdalSCP.GA_ReadOnly)
        if rD is None:
            cfg.mx.msg4()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " None raster")
            return "No"
        # band list
        bL = cfg.utls.readAllBandsFromRaster(rD)
        bC = len(bL)
        # output rasters
        oM = []
        oM.append(outputRaster)
        oMR = cfg.utls.createRasterFromReference(rD, bC, oM, nodataValue, outFormat, cfg.rasterDataType, 0, None, "No")
        for bb in range(0, bC):
            e = str("a * 1")
            variableList = [["im1", "a"]]
            o = cfg.utls.processRaster(rD, [bL[bb]], None, "No", cfg.utls.bandCalculation, None, oMR, None, None, 0,
                                       None, cfg.NoDataVal, "No", e, variableList, "No")
        # close GDAL rasters
        for b in range(0, len(oMR)):
            oMR[b] = None
        for b in range(0, len(bL)):
            bL[b] = None
        rD = None
        return outputRaster

    # find nearest value in list
    def findNearestValueinList(self, list, value, threshold):
        if len(list) > 0:
            arr = cfg.np.asarray(list)
            v = (cfg.np.abs(arr - value)).argmin()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "find nearest" + unicode(value))
            if cfg.np.abs(arr[v] - value) < threshold:
                return arr[v]
            else:
                return None
        else:
            return None

    # find band set number used for vegetation index calculation
    def findBandNumber(self):
        cfg.REDBand = None
        cfg.NIRBand = None
        cfg.BLUEBand = None
        cfg.GREENBand = None
        try:
            cfg.bndSetUnit["UNIT"]
        except:
            return "No"
        if cfg.bndSetUnit["UNIT"] != cfg.noUnit:
            if cfg.bndSetUnit["UNIT"] == cfg.unitNano:
                RED = self.findNearestValueinList(cfg.bndSetWvLn.values(), cfg.REDCenterBand * 1000,
                                                  cfg.REDThreshold * 1000)
                NIR = self.findNearestValueinList(cfg.bndSetWvLn.values(), cfg.NIRCenterBand * 1000,
                                                  cfg.NIRThreshold * 1000)
                BLUE = self.findNearestValueinList(cfg.bndSetWvLn.values(), cfg.BLUECenterBand * 1000,
                                                   cfg.BLUEThreshold * 1000)
                GREEN = self.findNearestValueinList(cfg.bndSetWvLn.values(), cfg.GREENCenterBand * 1000,
                                                    cfg.GREENThreshold * 1000)
            elif cfg.bndSetUnit["UNIT"] == cfg.unitMicro:
                RED = self.findNearestValueinList(cfg.bndSetWvLn.values(), cfg.REDCenterBand, cfg.REDThreshold)
                NIR = self.findNearestValueinList(cfg.bndSetWvLn.values(), cfg.NIRCenterBand, cfg.NIRThreshold)
                BLUE = self.findNearestValueinList(cfg.bndSetWvLn.values(), cfg.BLUECenterBand, cfg.BLUEThreshold)
                GREEN = self.findNearestValueinList(cfg.bndSetWvLn.values(), cfg.GREENCenterBand, cfg.GREENThreshold)
            if RED is not None:
                for band, value in cfg.bndSetWvLn.items():
                    if value == RED:
                        bN = band.replace("WAVELENGTH_", "")
                        cfg.REDBand = int(bN)
            if NIR is not None:
                for band, value in cfg.bndSetWvLn.items():
                    if value == NIR:
                        bN = band.replace("WAVELENGTH_", "")
                        cfg.NIRBand = int(bN)
            if BLUE is not None:
                for band, value in cfg.bndSetWvLn.items():
                    if value == BLUE:
                        bN = band.replace("WAVELENGTH_", "")
                        cfg.BLUEBand = int(bN)
            if GREEN is not None:
                for band, value in cfg.bndSetWvLn.items():
                    if value == GREEN:
                        bN = band.replace("WAVELENGTH_", "")
                        cfg.GREENBand = int(bN)
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    "RED =" + str(cfg.REDBand) + ", NIR =" + str(cfg.NIRBand) + ", BLUE =" + str(
                        cfg.BLUEBand) + ", GREEN =" + str(cfg.GREENBand))

    # calculation of earth sun distance
    def calculateEarthSunDistance(self, date, dateFormat):
        dStr = cfg.datetimeSCP.datetime.strptime(date, dateFormat)
        dStrT = dStr.timetuple()
        # calculate julian day
        day = dStrT.tm_yday
        # Earth Sun distance from http://landsathandbook.gsfc.nasa.gov/excel_docs/d.xls
        dL = [0.98331, 0.98330, 0.98330, 0.98330, 0.98330, 0.98332, 0.98333, 0.98335, 0.98338, 0.98341, 0.98345,
              0.98349, 0.98354, 0.98359, 0.98365, 0.98371, 0.98378, 0.98385,
              0.98393, 0.98401, 0.98410, 0.98419, 0.98428, 0.98439, 0.98449, 0.98460, 0.98472, 0.98484, 0.98496,
              0.98509, 0.98523, 0.98536, 0.98551, 0.98565, 0.98580, 0.98596, 0.98612,
              0.98628, 0.98645, 0.98662, 0.98680, 0.98698, 0.98717, 0.98735, 0.98755, 0.98774, 0.98794, 0.98814,
              0.98835, 0.98856, 0.98877, 0.98899, 0.98921, 0.98944, 0.98966, 0.98989,
              0.99012, 0.99036, 0.99060, 0.99084, 0.99108, 0.99133, 0.99158, 0.99183, 0.99208, 0.99234, 0.99260,
              0.99286, 0.99312, 0.99339, 0.99365, 0.99392, 0.99419, 0.99446, 0.99474,
              0.99501, 0.99529, 0.99556, 0.99584, 0.99612, 0.99640, 0.99669, 0.99697, 0.99725, 0.99754, 0.99782,
              0.99811, 0.99840, 0.99868, 0.99897, 0.99926, 0.99954, 0.99983, 1.00012,
              1.00041, 1.00069, 1.00098, 1.00127, 1.00155, 1.00184, 1.00212, 1.00240, 1.00269, 1.00297, 1.00325,
              1.00353, 1.00381, 1.00409, 1.00437, 1.00464, 1.00492, 1.00519, 1.00546,
              1.00573, 1.00600, 1.00626, 1.00653, 1.00679, 1.00705, 1.00731, 1.00756, 1.00781, 1.00806, 1.00831,
              1.00856, 1.00880, 1.00904, 1.00928, 1.00952, 1.00975, 1.00998, 1.01020,
              1.01043, 1.01065, 1.01087, 1.01108, 1.01129, 1.01150, 1.01170, 1.01191, 1.01210, 1.01230, 1.01249,
              1.01267, 1.01286, 1.01304, 1.01321, 1.01338, 1.01355, 1.01371, 1.01387,
              1.01403, 1.01418, 1.01433, 1.01447, 1.01461, 1.01475, 1.01488, 1.01500, 1.01513, 1.01524, 1.01536,
              1.01547, 1.01557, 1.01567, 1.01577, 1.01586, 1.01595, 1.01603, 1.01610,
              1.01618, 1.01625, 1.01631, 1.01637, 1.01642, 1.01647, 1.01652, 1.01656, 1.01659, 1.01662, 1.01665,
              1.01667, 1.01668, 1.01670, 1.01670, 1.01670, 1.01670, 1.01669, 1.01668,
              1.01666, 1.01664, 1.01661, 1.01658, 1.01655, 1.01650, 1.01646, 1.01641, 1.01635, 1.01629, 1.01623,
              1.01616, 1.01609, 1.01601, 1.01592, 1.01584, 1.01575, 1.01565, 1.01555,
              1.01544, 1.01533, 1.01522, 1.01510, 1.01497, 1.01485, 1.01471, 1.01458, 1.01444, 1.01429, 1.01414,
              1.01399, 1.01383, 1.01367, 1.01351, 1.01334, 1.01317, 1.01299, 1.01281,
              1.01263, 1.01244, 1.01225, 1.01205, 1.01186, 1.01165, 1.01145, 1.01124, 1.01103, 1.01081, 1.01060,
              1.01037, 1.01015, 1.00992, 1.00969, 1.00946, 1.00922, 1.00898, 1.00874,
              1.00850, 1.00825, 1.00800, 1.00775, 1.00750, 1.00724, 1.00698, 1.00672, 1.00646, 1.00620, 1.00593,
              1.00566, 1.00539, 1.00512, 1.00485, 1.00457, 1.00430, 1.00402, 1.00374,
              1.00346, 1.00318, 1.00290, 1.00262, 1.00234, 1.00205, 1.00177, 1.00148, 1.00119, 1.00091, 1.00062,
              1.00033, 1.00005, 0.99976, 0.99947, 0.99918, 0.99890, 0.99861, 0.99832,
              0.99804, 0.99775, 0.99747, 0.99718, 0.99690, 0.99662, 0.99634, 0.99605, 0.99577, 0.99550, 0.99522,
              0.99494, 0.99467, 0.99440, 0.99412, 0.99385, 0.99359, 0.99332, 0.99306,
              0.99279, 0.99253, 0.99228, 0.99202, 0.99177, 0.99152, 0.99127, 0.99102, 0.99078, 0.99054, 0.99030,
              0.99007, 0.98983, 0.98961, 0.98938, 0.98916, 0.98894, 0.98872, 0.98851,
              0.98830, 0.98809, 0.98789, 0.98769, 0.98750, 0.98731, 0.98712, 0.98694, 0.98676, 0.98658, 0.98641,
              0.98624, 0.98608, 0.98592, 0.98577, 0.98562, 0.98547, 0.98533, 0.98519,
              0.98506, 0.98493, 0.98481, 0.98469, 0.98457, 0.98446, 0.98436, 0.98426, 0.98416, 0.98407, 0.98399,
              0.98391, 0.98383, 0.98376, 0.98370, 0.98363, 0.98358, 0.98353, 0.98348,
              0.98344, 0.98340, 0.98337, 0.98335, 0.98333, 0.98331]
        eSD = dL[day - 1]
        return eSD

    # calculate NDVI
    def calculateNDVI(self, NIR, RED):
        NDVI = (NIR - RED) / (NIR + RED)
        if NDVI > 1:
            NDVI = 1
        elif NDVI < -1:
            NDVI = -1
        return NDVI

    # calculate EVI
    def calculateEVI(self, NIR, RED, BLUE):
        EVI = 2.5 * (NIR - RED) / (NIR + 6 * RED - 7.5 * BLUE + 1)
        if EVI > 1:
            EVI = 1
        elif EVI < -1:
            EVI = -1
        return EVI

    # NDVI calculator from image
    def NDVIcalculator(self, imageName, point):
        NDVI = None
        # band set
        if cfg.bndSetPresent == "Yes" and imageName == cfg.bndSetNm:
            if cfg.NIRBand is None or cfg.REDBand is None:
                return "No"
            else:
                NIRRaster = cfg.utls.selectLayerbyName(cfg.bndSet[int(cfg.NIRBand) - 1], "Yes")
                REDRaster = cfg.utls.selectLayerbyName(cfg.bndSet[int(cfg.REDBand) - 1], "Yes")
                # open input with GDAL
                try:
                    NIRr = cfg.gdalSCP.Open(NIRRaster.source(), cfg.gdalSCP.GA_ReadOnly)
                    REDr = cfg.gdalSCP.Open(REDRaster.source(), cfg.gdalSCP.GA_ReadOnly)
                except Exception, err:
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        " ERROR exception: " + str(err))
                    return "No"
                NIRB = NIRr.GetRasterBand(1)
                REDB = REDr.GetRasterBand(1)
                geoT = NIRr.GetGeoTransform()
        else:
            inputRaster = cfg.utls.selectLayerbyName(imageName, "Yes")
            # open input with GDAL
            try:
                rD = cfg.gdalSCP.Open(inputRaster.source(), cfg.gdalSCP.GA_ReadOnly)
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                return "No"
            if rD is None or cfg.NIRBand is None or cfg.REDBand is None:
                return "No"
            else:
                NIRB = rD.GetRasterBand(int(cfg.NIRBand))
                REDB = rD.GetRasterBand(int(cfg.REDBand))
            geoT = rD.GetGeoTransform()
        tLX = geoT[0]
        tLY = geoT[3]
        pSX = geoT[1]
        pSY = geoT[5]
        # start and end pixels
        pixelStartColumn = (int((point.x() - tLX) / pSX))
        pixelStartRow = -(int((tLY - point.y()) / pSY))
        try:
            NIR = self.readArrayBlock(NIRB, pixelStartColumn, pixelStartRow, 1, 1) * cfg.bndSetMultiFactorsList[
                int(cfg.NIRBand) - 1] + cfg.bndSetAddFactorsList[int(cfg.NIRBand) - 1]
            RED = self.readArrayBlock(REDB, pixelStartColumn, pixelStartRow, 1, 1) * cfg.bndSetMultiFactorsList[
                int(cfg.REDBand) - 1] + cfg.bndSetAddFactorsList[int(cfg.REDBand) - 1]
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            # close bands
            NIRB = None
            REDB = None
            # close raster
            rD = None
            return "No"
        if NIR is not None and RED is not None:
            try:
                NDVI = self.calculateNDVI(float(NIR), float(RED))
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                # close bands
                NIRB = None
                REDB = None
                # close raster
                rD = None
                return "No"
        # close bands
        NIRB = None
        REDB = None
        # close raster
        rD = None
        NIRr = None
        REDr = None
        try:
            return round(NDVI, 3)
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return "No"

        # EVI calculator from image

    def EVIcalculator(self, imageName, point):
        EVI = None
        # band set
        if cfg.bndSetPresent == "Yes" and imageName == cfg.bndSetNm:
            if cfg.NIRBand is None or cfg.REDBand is None or cfg.BLUEBand is None:
                return "No"
            else:
                NIRRaster = cfg.utls.selectLayerbyName(cfg.bndSet[int(cfg.NIRBand) - 1], "Yes")
                REDRaster = cfg.utls.selectLayerbyName(cfg.bndSet[int(cfg.REDBand) - 1], "Yes")
                BLUERaster = cfg.utls.selectLayerbyName(cfg.bndSet[int(cfg.BLUEBand) - 1], "Yes")
                # open input with GDAL
                try:
                    NIRr = cfg.gdalSCP.Open(NIRRaster.source(), cfg.gdalSCP.GA_ReadOnly)
                    REDr = cfg.gdalSCP.Open(REDRaster.source(), cfg.gdalSCP.GA_ReadOnly)
                    BLUEr = cfg.gdalSCP.Open(BLUERaster.source(), cfg.gdalSCP.GA_ReadOnly)
                except Exception, err:
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        " ERROR exception: " + str(err))
                    return "No"
                NIRB = NIRr.GetRasterBand(1)
                REDB = REDr.GetRasterBand(1)
                BLUEB = REDr.GetRasterBand(1)
                geoT = NIRr.GetGeoTransform()
        else:
            inputRaster = cfg.utls.selectLayerbyName(imageName, "Yes")
            # open input with GDAL
            try:
                rD = cfg.gdalSCP.Open(inputRaster.source(), cfg.gdalSCP.GA_ReadOnly)
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                return "No"
            if rD is None or cfg.NIRBand is None or cfg.REDBand is None or cfg.BLUEBand is None:
                return "No"
            else:
                NIRB = rD.GetRasterBand(int(cfg.NIRBand))
                REDB = rD.GetRasterBand(int(cfg.REDBand))
                BLUEB = rD.GetRasterBand(int(cfg.BLUEBand))
            geoT = rD.GetGeoTransform()
        tLX = geoT[0]
        tLY = geoT[3]
        pSX = geoT[1]
        pSY = geoT[5]
        # start and end pixels
        pixelStartColumn = (int((point.x() - tLX) / pSX))
        pixelStartRow = -(int((tLY - point.y()) / pSY))
        NIR = self.readArrayBlock(NIRB, pixelStartColumn, pixelStartRow, 1, 1) * cfg.bndSetMultiFactorsList[
            int(cfg.NIRBand) - 1] + cfg.bndSetAddFactorsList[int(cfg.NIRBand) - 1]
        RED = self.readArrayBlock(REDB, pixelStartColumn, pixelStartRow, 1, 1) * cfg.bndSetMultiFactorsList[
            int(cfg.REDBand) - 1] + cfg.bndSetAddFactorsList[int(cfg.REDBand) - 1]
        BLUE = self.readArrayBlock(BLUEB, pixelStartColumn, pixelStartRow, 1, 1) * cfg.bndSetMultiFactorsList[
            int(cfg.BLUEBand) - 1] + cfg.bndSetAddFactorsList[int(cfg.BLUEBand) - 1]
        if NIR is not None and RED is not None and BLUE is not None:
            if NIR <= 1 and RED <= 1 and BLUE <= 1:
                try:
                    EVI = self.calculateEVI(float(NIR), float(RED), float(BLUE))
                except Exception, err:
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        " ERROR exception: " + str(err))
                    # close bands
                    NIRB = None
                    REDB = None
                    BLUEB = None
                    # close raster
                    rD = None
                    return "No"
        # close bands
        NIRB = None
        REDB = None
        BLUEB = None
        # close raster
        rD = None
        NIRr = None
        REDr = None
        BLUEr = None
        try:
            return round(EVI, 3)
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return "No"

        # copy a raster band from a multi band raster

    def getRasterBandByBandNumber(self, inputRaster, band, outputRaster, virtualRaster="No", GDALFormat=None,
                                  multiAddList=None):
        if virtualRaster == "No":
            # open input with GDAL
            rD = cfg.gdalSCP.Open(inputRaster, cfg.gdalSCP.GA_ReadOnly)
            # number of x pixels
            rC = rD.RasterXSize
            # number of y pixels
            rR = rD.RasterYSize
            # check projections
            rP = rD.GetProjection()
            # pixel size and origin
            rGT = rD.GetGeoTransform()
            tD = cfg.gdalSCP.GetDriverByName("GTiff")
            iRB = rD.GetRasterBand(int(band))
            if GDALFormat is None:
                bDT = iRB.DataType
            else:
                if GDALFormat == "Float64":
                    bDT = cfg.gdalSCP.GDT_Float64
                elif GDALFormat == "Float32":
                    bDT = cfg.gdalSCP.GDT_Float32
            a = iRB.ReadAsArray()
            if multiAddList is not None:
                a = cfg.utls.arrayMultiplicativeAdditiveFactors(a, multiAddList[0], multiAddList[1])
            oR = tD.Create(outputRaster, rC, rR, 1, bDT)
            oR.SetGeoTransform([rGT[0], rGT[1], 0, rGT[3], 0, rGT[5]])
            oR.SetProjection(rP)
            oRB = oR.GetRasterBand(1)
            oRB.WriteArray(a)
            # close bands
            oRB = None
            iRB = None
            # close rasters
            oR = None
            rD = None
        else:
            vrtCheck = cfg.utls.createVirtualRaster([inputRaster], outputRaster, band)
            cfg.timeSCP.sleep(1)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "get band: " + unicode(band))

    # Split raster into single bands, and return a list of images
    def rasterToBands(self, rasterPath, outputFolder, outputName=None, progressBar="No", multiAddList=None):
        dT = self.getTime()
        iBC = cfg.utls.getNumberBandRaster(rasterPath)
        iL = []
        if outputName is None:
            name = cfg.splitBndNm + dT
        else:
            name = outputName
        progresStep = int(100 / iBC)
        i = 1
        for x in range(1, iBC + 1):
            if cfg.actionCheck == "Yes":
                xB = outputFolder + "/" + name + "_B" + str(x) + ".tif"
                if multiAddList is not None:
                    self.getRasterBandByBandNumber(rasterPath, x, xB, "No", None, multiAddList[x - 1])
                else:
                    self.getRasterBandByBandNumber(rasterPath, x, xB, "No", None)
                iL.append(xB)
                if progressBar == "Yes":
                    cfg.uiUtls.updateBar(progresStep * i)
                    i = i + 1
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "raster: " + unicode(rasterPath) + " split to bands")
        return iL

    # band calculation
    def bandCalculation(self, gdalBandList, rasterSCPArrayfunctionBand, columnNumber, rowNumber, pixelStartColumn,
                        pixelStartRow, outputGdalRasterList, functionBandArgument, functionVariableList):
        if cfg.actionCheck == "Yes":
            f = functionBandArgument
            # create function
            b = 0
            for i in functionVariableList:
                f = f.replace(i[0], " rasterSCPArrayfunctionBand[::, ::," + str(b) + "] ")
                f = f.replace(i[1], " rasterSCPArrayfunctionBand[::, ::," + str(b) + "] ")
                b = b + 1
            # replace numpy operators
            f = cfg.utls.replaceNumpyOperators(f)
            # perform operation
            try:
                o = eval(f)
            except Exception, err:
                cfg.mx.msgErr36()
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                return "No"
            # create array if not
            if not isinstance(o, cfg.np.ndarray):
                a = cfg.np.zeros((rasterSCPArrayfunctionBand.shape[0], rasterSCPArrayfunctionBand.shape[1]),
                                 dtype=cfg.np.float32)
                try:
                    a.fill(o)
                except Exception, err:
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        " ERROR exception: " + str(err))
                    return "No"
                o = a
            a = cfg.np.nan_to_num(o) * 1.0
            a[cfg.np.isnan(o)] = cfg.np.nan
            o = a
            oR = outputGdalRasterList[0]
            # output raster
            band = gdalBandList[0].GetBand()
            try:
                self.writeArrayBlock(oR, band, o, pixelStartColumn, pixelStartRow)
            except Exception, err:
                cfg.mx.msgErr36()
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                return "No"
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # multiple where band calculation
    def bandCalculationMultipleWhere(self, gdalBandList, rasterSCPArrayfunctionBand, columnNumber, rowNumber,
                                     pixelStartColumn, pixelStartRow, outputGdalRasterList, functionBandArgument,
                                     functionVariableList):
        if cfg.actionCheck == "Yes":
            for f in functionBandArgument:
                # create function
                b = 0
                for i in functionVariableList:
                    f = f.replace(i[0], " rasterSCPArrayfunctionBand[::, ::," + str(b) + "] ")
                    f = f.replace(i[1], " rasterSCPArrayfunctionBand[::, ::," + str(b) + "] ")
                    b = b + 1
                # replace numpy operators
                f = cfg.utls.replaceNumpyOperators(f)
                # perform operation
                try:
                    o = o + eval(f)
                # first iteration
                except:
                    try:
                        o = eval(f)
                    except Exception, err:
                        cfg.mx.msgErr36()
                        # logger
                        cfg.utls.logCondition(
                            str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                            " ERROR exception: " + str(err))
                        return "No"
            # create array if not
            try:
                if not isinstance(o, cfg.np.ndarray):
                    o = cfg.np.where(o == 0, cfg.NoDataVal, o)
                    a = cfg.np.zeros((rasterSCPArrayfunctionBand.shape[0], rasterSCPArrayfunctionBand.shape[1]),
                                     dtype=cfg.np.float32)
                    a.fill(o)
                    o = a
            except Exception, err:
                cfg.mx.msgErr36()
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                return "No"
            oR = outputGdalRasterList[0]
            # output raster
            band = gdalBandList[0].GetBand()
            try:
                self.writeArrayBlock(oR, band, o, pixelStartColumn, pixelStartRow)
            except Exception, err:
                cfg.mx.msgErr36()
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                return "No"
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # multiple where scatter raster calculation
    def scatterRasterMultipleWhere(self, gdalBandList, rasterSCPArrayfunctionBand, columnNumber, rowNumber,
                                   pixelStartColumn, pixelStartRow, outputGdalRasterList, functionBandArgument,
                                   functionVariableList):
        if cfg.actionCheck == "Yes":
            for f in functionBandArgument:
                # create function
                f = f.replace("bandX", " rasterSCPArrayfunctionBand[::, ::, 0] ")
                f = f.replace("bandY", " rasterSCPArrayfunctionBand[::, ::, 1] ")
                # perform operation
                try:
                    u = eval(f)
                    o = cfg.np.where(u == cfg.NoDataVal, o, u)
                # first iteration
                except:
                    try:
                        o = eval(f)
                    except Exception, err:
                        # logger
                        cfg.utls.logCondition(
                            str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                            " ERROR exception: " + str(err))
                        return "No"
            oR = outputGdalRasterList[0]
            # output raster
            try:
                self.writeArrayBlock(oR, 1, o, pixelStartColumn, pixelStartRow)
                oR = None
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                return "No"
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    #  band calculation scatter raster
    def scatterRasterBandCalculation(self, gdalBandList, rasterSCPArrayfunctionBand, columnNumber, rowNumber,
                                     pixelStartColumn, pixelStartRow, outputGdalRasterList, functionBandArgument,
                                     functionVariableList):
        if cfg.actionCheck == "Yes":
            f = functionBandArgument
            # create function
            f = f.replace("bandX", " rasterSCPArrayfunctionBand[::, ::, 0] ")
            f = f.replace("bandY", " rasterSCPArrayfunctionBand[::, ::, 1] ")
            # perform operation
            out = eval(f)
            oR = outputGdalRasterList[0]
            # output raster
            try:
                self.writeArrayBlock(oR, 1, out, pixelStartColumn, pixelStartRow)
                oR = None
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                return "No"
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # raster erosion boundaries
    def rasterErosionBoundaries(self, gdalBandList, rasterArray, columnNumber, rowNumber, pixelStartColumn,
                                pixelStartRow, outputGdalRasterList, functionBandArgument, functionVariableList):
        cfg.utls.rasterErosion(gdalBandList, rasterArray, columnNumber, rowNumber, pixelStartColumn, pixelStartRow,
                               outputGdalRasterList, functionBandArgument, functionVariableList, "Yes")

    # raster erosion
    def rasterErosion(self, gdalBandList, rasterArray, columnNumber, rowNumber, pixelStartColumn, pixelStartRow,
                      outputGdalRasterList, functionBandArgument, functionVariableList, boundaries=None):
        A = rasterArray[::, ::, 0]
        B = functionBandArgument
        # value sum dictionary
        C = {}
        # unique value list
        uniqueVal = cfg.np.unique(A)
        aUniqueVal = list(uniqueVal.astype(int))
        # calculate sum
        for i in aUniqueVal:
            C['arr_' + str(i)] = cfg.signalSCP.convolve2d(cfg.np.where(A == i, 1, 0), B, 'same')
        # erosion
        D = cfg.np.ones(A.shape)
        R = cfg.np.zeros(A.shape)
        for v in functionVariableList:
            if v in aUniqueVal:
                # core
                D[C['arr_' + str(v)] == B.sum()] = 0
                # erosion values
                R[A == v] = 1
                aUniqueVal.remove(v)
        # empty array
        Z = cfg.np.zeros((C['arr_' + str(i)].shape[0], C['arr_' + str(i)].shape[1], len(aUniqueVal)))
        # copy sum
        for s in range(0, (len(aUniqueVal))):
            Z[::, ::, s] = C['arr_' + str(aUniqueVal[s])]
        try:
            # maximum sum
            maxA = cfg.np.argmax(Z, axis=2)
            maxACopy = cfg.np.copy(maxA)
            # replace maximum with class value
            for s in range(0, (len(aUniqueVal))):
                maxA[maxACopy == s] = aUniqueVal[s]
            # output erosion
            out = cfg.np.where((R * D * cfg.np.where(cfg.np.max(Z, axis=2) > 0, 1, 0) == 1), maxA, A)
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            out = A
        oR = outputGdalRasterList[0]
        if boundaries is None:
            # output raster
            try:
                self.writeArrayBlock(oR, 1, out, pixelStartColumn, pixelStartRow)
                oR = None
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                return "No"
        else:
            # output raster
            try:
                self.writeArrayBlock(oR, 1, out[1:-1, 1:-1], pixelStartColumn + 1, pixelStartRow + 1)
                oR = None
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                return "No"
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # raster dilation boundaries
    def rasterDilationBoundaries(self, gdalBandList, rasterArray, columnNumber, rowNumber, pixelStartColumn,
                                 pixelStartRow, outputGdalRasterList, functionBandArgument, functionVariableList):
        cfg.utls.rasterDilation(gdalBandList, rasterArray, columnNumber, rowNumber, pixelStartColumn, pixelStartRow,
                                outputGdalRasterList, functionBandArgument, functionVariableList, "Yes")

    # raster dilation
    def rasterDilation(self, gdalBandList, rasterArray, columnNumber, rowNumber, pixelStartColumn, pixelStartRow,
                       outputGdalRasterList, functionBandArgument, functionVariableList, boundaries=None):
        A = rasterArray[::, ::, 0]
        B = functionBandArgument
        # value sum dictionary
        C = {}
        # unique value list
        uniqueVal = cfg.np.unique(A)
        aUniqueVal = list(uniqueVal.astype(int))
        # calculate sum
        for i in aUniqueVal:
            C['arr_' + str(i)] = cfg.signalSCP.convolve2d(cfg.np.where(A == i, 1, 0), B, 'same')
        # core
        D = cfg.np.ones(A.shape)
        for v in functionVariableList:
            D[cfg.np.where(A == v)] = 0

        # dilation
        out = cfg.np.copy(A)
        try:
            for v in functionVariableList:
                out[(D * C['arr_' + str(v)]) > 0] = v
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
        oR = outputGdalRasterList[0]
        if boundaries is None:
            # output raster
            try:
                self.writeArrayBlock(oR, 1, out, pixelStartColumn, pixelStartRow)
                oR = None
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                return "No"
        else:
            # output raster
            try:
                self.writeArrayBlock(oR, 1, out[1:-1, 1:-1], pixelStartColumn + 1, pixelStartRow + 1)
                oR = None
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                return "No"
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # replace numpy operators for expressions in Band calc
    def replaceNoDataValues(self, expression, nameList):
        if "nodata" in expression:
            # find all non-greedy expression
            g = cfg.reSCP.findall('nodata\(\"#?(.*?)#?\"\)', expression)
        else:
            return expression
        for l in g:
            name = l
            for i in nameList:
                if l == i[0].replace('"', ''):
                    l = i[1].replace('"', '')
            if l in cfg.variableBlueName or l in cfg.variableRedName or l in cfg.variableNIRName:
                if cfg.bndSetPresent == "Yes" and cfg.imgNm == cfg.bndSetNm:
                    name = "#" + name
                    if "#" + l == cfg.variableRedName:
                        bandNumber = ["", cfg.REDBand]
                    elif "#" + l == cfg.variableGreenName:
                        bandNumber = ["", cfg.GREENBand]
                    elif "#" + l == cfg.variableNIRName:
                        bandNumber = ["", cfg.NIRBand]
                    elif "#" + l == cfg.variableBlueName:
                        bandNumber = ["", cfg.BLUEBand]
                    l = cfg.bndSet[int(bandNumber[1]) - 1]
                elif cfg.imgNm is not None:
                    l = cfg.imgNm
            name = '"' + name + '"'
            r = cfg.utls.selectLayerbyName(l, "Yes")
            if r is not None:
                nd = cfg.utls.imageNoDataValue(r.source())
                expression = expression.replace('nodata(' + name + ')', str(nd))
        # find Nodata values
        return expression

    # replace numpy operators for expressions in Band calc
    def replaceNumpyOperators(self, expression):
        f = expression
        f = f.replace(" np.", " " + cfg.numpyn)
        f = f.replace(" ln(", " " + cfg.logn + "(")
        f = f.replace(" ln (", " " + cfg.logn + "(")
        f = f.replace(" sqrt(", " " + cfg.numpySqrt + "(")
        f = f.replace(" sqrt (", " " + cfg.numpySqrt + "(")
        f = f.replace(" cos(", " " + cfg.numpyCos + "(")
        f = f.replace(" cos (", " " + cfg.numpyCos + "(")
        f = f.replace(" acos(", " " + cfg.numpyArcCos + "(")
        f = f.replace(" acos (", " " + cfg.numpyArcCos + "(")
        f = f.replace(" sin(", " " + cfg.numpySin + "(")
        f = f.replace(" sin (", " " + cfg.numpySin + "(")
        f = f.replace(" asin(", " " + cfg.numpyArcSin + "(")
        f = f.replace(" asin (", " " + cfg.numpyArcSin + "(")
        f = f.replace(" tan(", " " + cfg.numpyTan + "(")
        f = f.replace(" tan (", " " + cfg.numpyTan + "(")
        f = f.replace(" atan(", " " + cfg.numpyArcTan + "(")
        f = f.replace(" atan (", " " + cfg.numpyArcTan + "(")
        f = f.replace(" exp(", " " + cfg.numpyExp + "(")
        f = f.replace(" exp (", " " + cfg.numpyExp + "(")
        f = f.replace("^", "**")
        f = f.replace(" pi ", " " + cfg.numpyPi + " ")
        f = f.replace(" where(", " " + cfg.numpyWhere + "(")
        f = f.replace(" where (", " " + cfg.numpyWhere + "(")
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
        return f

    # process a raster with block size
    def processRasterBoundaries(self, gdalRaster, gdalBandList, signatureList=None, functionBand=None,
                                functionRaster=None, algorithmName=None, outputRasterList=None,
                                outputAlgorithmRaster=None, outputClassificationRaster=None, previewSize=0,
                                previewPoint=None, nodataValue=None, macroclassCheck="No", functionBandArgument=None,
                                functionVariable=None, progressMessage="", boundarySize=None):
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "start processRaster boundaries")
        blockSizeX = self.calculateBlockSize(len(gdalBandList))
        blockSizeY = blockSizeX
        # raster blocks
        rX, rY, lX, lY, pX, pY = self.rasterBlocks(gdalRaster, blockSizeX, blockSizeY, previewSize, previewPoint)
        # set initial value for progress bar
        progresStep = 60 / (len(lX) + len(lY))
        progressStart = 20 - progresStep
        if blockSizeX > rX:
            blockSizeX = rX
        if blockSizeY > rY:
            blockSizeY = rY
        cfg.remainingTime = 0
        remainingBlocks = (len(lX) + len(lY) - 2)
        totBlocks = remainingBlocks
        if len(lX) > 1 or len(lY) > 1:
            for y in lY:
                if y != 0 and (y - boundarySize) <= rY:
                    if cfg.actionCheck == "Yes":
                        # set initial value for progress bar
                        progressStart = progressStart + progresStep
                        bSX = rX
                        bSY = boundarySize * 2
                        array = cfg.np.zeros((bSX, bSY, len(gdalBandList)), dtype=cfg.np.float32)
                        for b in range(0, len(gdalBandList)):
                            ndv = cfg.NoDataVal
                            a = self.readArrayBlock(gdalBandList[b], 0, y - boundarySize, bSX, bSY)
                            try:
                                b0 = gdalBandList[b].GetRasterBand(1)
                                ndv2 = b0.GetNoDataValue()
                            except:
                                try:
                                    ndv2 = gdalBandList[b].GetNoDataValue()
                                except:
                                    ndv2 = None
                            if a is not None:
                                array[::, ::, b] = a.reshape(bSX, bSY)
                            else:
                                # logger
                                cfg.utls.logCondition(str(__name__) + "-" + str(
                                    cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(), "error reading array")
                                cfg.mx.msgErr46()
                                return "No"
                            a = None
                            array[::, ::, b][array[::, ::, b] == ndv] = cfg.np.nan
                            if ndv2 is not None:
                                array[::, ::, b][array[::, ::, b] == ndv2] = cfg.np.nan
                        c = array.reshape(bSY, bSX, len(gdalBandList))
                        array = None
                        if functionRaster is not None:
                            if functionBand == "No":
                                cfg.QtGuiSCP.qApp.processEvents()
                                o = functionRaster(gdalBandList, c, bSX, bSY, 0, y - boundarySize, outputRasterList,
                                                   functionBandArgument, functionVariable)
                                if progressMessage != "No":
                                    cfg.uiUtls.updateBar(progressStart,
                                                         " (" + str(totBlocks - remainingBlocks) + "/" + str(
                                                             totBlocks) + ") " + progressMessage)
                                    remainingBlocks = (remainingBlocks - 1)
                                if o == "No":
                                    return "No"
                    else:
                        return "No"
            for x in lX:
                if x != 0 and (x - boundarySize) <= rX:
                    if cfg.actionCheck == "Yes":
                        # set initial value for progress bar
                        progressStart = progressStart + progresStep
                        bSX = boundarySize * 2
                        bSY = rY
                        array = cfg.np.zeros((bSX, bSY, len(gdalBandList)), dtype=cfg.np.float32)
                        for b in range(0, len(gdalBandList)):
                            ndv = cfg.NoDataVal
                            a = self.readArrayBlock(gdalBandList[b], x - boundarySize, 0, bSX, bSY)
                            try:
                                b0 = gdalBandList[b].GetRasterBand(1)
                                ndv2 = b0.GetNoDataValue()
                            except:
                                try:
                                    ndv2 = gdalBandList[b].GetNoDataValue()
                                except:
                                    ndv2 = None
                            if a is not None:
                                array[::, ::, b] = a.reshape(bSX, bSY)
                            else:
                                # logger
                                cfg.utls.logCondition(str(__name__) + "-" + str(
                                    cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(), "error reading array")
                                cfg.mx.msgErr46()
                                return "No"
                            a = None
                            array[::, ::, b][array[::, ::, b] == ndv] = cfg.np.nan
                            if ndv2 is not None:
                                array[::, ::, b][array[::, ::, b] == ndv2] = cfg.np.nan
                        c = array.reshape(bSY, bSX, len(gdalBandList))
                        array = None
                        if functionRaster is not None:
                            if functionBand == "No":
                                cfg.QtGuiSCP.qApp.processEvents()
                                o = functionRaster(gdalBandList, c, bSX, bSY, x - boundarySize, 0, outputRasterList,
                                                   functionBandArgument, functionVariable)
                                if progressMessage != "No":
                                    cfg.uiUtls.updateBar(progressStart,
                                                         " (" + str(totBlocks - remainingBlocks) + "/" + str(
                                                             totBlocks) + ") " + progressMessage)
                                    remainingBlocks = (remainingBlocks - 1)
                                if o == "No":
                                    return "No"
                    else:
                        return "No"
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "end processRaster boundaries")
        return "Yes"

    # process a raster with block size
    def processRaster(self, gdalRaster, gdalBandList, signatureList=None, functionBand=None, functionRaster=None,
                      algorithmName=None, outputRasterList=None, outputAlgorithmRaster=None,
                      outputClassificationRaster=None, previewSize=0, previewPoint=None, nodataValue=None,
                      macroclassCheck="No", functionBandArgument=None, functionVariable=None, progressMessage="",
                      skipReplaceNoData=None):
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "start processRaster")
        blockSizeX = self.calculateBlockSize(len(gdalBandList))
        blockSizeY = blockSizeX
        # raster blocks
        rX, rY, lX, lY, pX, pY = self.rasterBlocks(gdalRaster, blockSizeX, blockSizeY, previewSize, previewPoint)
        # set initial value for progress bar
        try:
            progresStep = 60 / (len(lX) * len(lY))
        except:
            progresStep = 60
        progressStart = 20 - progresStep
        if blockSizeX > rX:
            blockSizeX = rX
        if blockSizeY > rY:
            blockSizeY = rY
        cfg.remainingTime = 0
        remainingBlocks = len(lX) * len(lY)
        totBlocks = remainingBlocks
        for y in lY:
            bSY = blockSizeY
            if previewSize > 0 and bSY > previewSize:
                bSY = previewSize
            if y + bSY > rY:
                bSY = rY - y
            for x in lX:
                if cfg.actionCheck == "Yes":
                    # set initial value for progress bar
                    progressStart = progressStart + progresStep
                    bSX = blockSizeX
                    if previewSize > 0 and bSX > previewSize:
                        bSX = previewSize
                    if x + bSX > rX:
                        bSX = rX - x
                    array = cfg.np.zeros((bSX, bSY, len(gdalBandList)), dtype=cfg.np.float32)
                    for b in range(0, len(gdalBandList)):
                        ndv = cfg.NoDataVal
                        a = self.readArrayBlock(gdalBandList[b], x, y, bSX, bSY)
                        try:
                            b0 = gdalBandList[b].GetRasterBand(1)
                            ndv2 = b0.GetNoDataValue()
                        except:
                            try:
                                ndv2 = gdalBandList[b].GetNoDataValue()
                            except:
                                ndv2 = None
                        if a is not None:
                            if functionBandArgument == cfg.multiAddFactorsVar:
                                multiAdd = functionVariable[b]
                                a = cfg.utls.arrayMultiplicativeAdditiveFactors(a, multiAdd[0], multiAdd[1])
                            array[::, ::, b] = a.reshape(bSX, bSY)
                        else:
                            # logger
                            cfg.utls.logCondition(
                                str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                "error reading array")
                            cfg.mx.msgErr46()
                            return "No"
                        a = None
                        # set nodata value
                        # noData = gBand2.GetNoDataValue()
                        if skipReplaceNoData is None:
                            array[::, ::, b][array[::, ::, b] == ndv] = cfg.np.nan
                            if ndv2 is not None:
                                array[::, ::, b][array[::, ::, b] == ndv2] = cfg.np.nan
                        else:
                            if ndv2 is None:
                                array[::, ::, b][cfg.np.isnan(array[::, ::, b])] = ndv
                            else:
                                array[::, ::, b][cfg.np.isnan(array[::, ::, b])] = ndv2
                        if functionBand is not None and functionBand != "No":
                            cfg.QtGuiSCP.qApp.processEvents()
                            functionBand(b + 1, array[::, ::, b].reshape(bSY, bSX), bSX, bSY, x, y, outputRasterList,
                                         functionBandArgument, functionVariable)
                            if progressMessage != "No":
                                cfg.uiUtls.updateBar(progressStart, " (" + str(totBlocks - remainingBlocks) + "/" + str(
                                    totBlocks) + ") " + progressMessage)
                    c = array.reshape(bSY, bSX, len(gdalBandList))
                    array = None
                    if functionRaster is not None:
                        if functionBand == "No":
                            cfg.QtGuiSCP.qApp.processEvents()
                            o = functionRaster(gdalBandList, c, bSX, bSY, x, y, outputRasterList, functionBandArgument,
                                               functionVariable)
                            if progressMessage != "No":
                                cfg.uiUtls.updateBar(progressStart, " (" + str(totBlocks - remainingBlocks) + "/" + str(
                                    totBlocks) + ") " + progressMessage)
                            if o == "No":
                                return "No"
                        else:
                            cfg.QtGuiSCP.qApp.processEvents()
                            progressMessage = " (" + str(totBlocks - remainingBlocks) + "/" + str(totBlocks) + ") "
                            o = functionRaster(gdalBandList, signatureList, algorithmName, c, bSX, bSY, x, y,
                                               outputRasterList, outputAlgorithmRaster, outputClassificationRaster,
                                               nodataValue, macroclassCheck, previewSize, pX[lX.index(x)],
                                               pY[lY.index(y)], progressStart, progresStep, remainingBlocks,
                                               progressMessage)
                            if o == "No":
                                return "No"
                    remainingBlocks = (remainingBlocks - 1)
                else:
                    return "No"
        outputClassificationRaster = None
        c = None
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "end processRaster")
        return "Yes"

    # calculate raster
    def calculateRaster(self, gdalBand, rasterArray, columnNumber, rowNumber, pixelStartColumn, pixelStartRow,
                        outputGdalRasterList, functionBandArgument, functionVariable):
        if cfg.actionCheck == "Yes":
            # create function
            f = functionBandArgument.replace(functionVariable, "rasterArray")
            f = f.replace("ln", cfg.logn)
            # perform operation
            o = eval(f)
            oR = outputGdalRasterList[0]
            # output raster
            self.writeArrayBlock(oR, 1, o, pixelStartColumn, pixelStartRow)
            o = None
            oR = None
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # reclassify raster
    def reclassifyRaster(self, gdalBand, rasterSCPArrayfunctionBand, columnNumber, rowNumber, pixelStartColumn,
                         pixelStartRow, outputGdalRasterList, functionBandArgument, functionVariable):
        if cfg.actionCheck == "Yes":
            # raster array
            o = rasterSCPArrayfunctionBand
            for i in functionBandArgument:
                # create condition
                c = i[0].replace(functionVariable, "rasterSCPArrayfunctionBand")
                f = "cfg.np.where(" + c + ", " + str(i[1]) + ", o)"
                # perform operation
                try:
                    o = eval(f)
                except Exception, err:
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        " ERROR exception: " + str(err))
            oR = outputGdalRasterList[0]
            # output raster
            self.writeArrayBlock(oR, 1, o, pixelStartColumn, pixelStartRow)
            o = None
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # pan-sharpening
    def pansharpening(self, gdalBandList, rasterSCPArrayfunctionBand, columnNumber, rowNumber, pixelStartColumn,
                      pixelStartRow, outputGdalRasterList, functionBandArgument, functionVariableList):
        if cfg.actionCheck == "Yes":
            # functionBandArgument = [satellite, panType]
            if functionBandArgument[0] in ['landsat8', 'landsat_8']:
                try:
                    # functionVariableList = [bandNumber]
                    B = functionVariableList.index(2)
                    G = functionVariableList.index(3)
                    R = functionVariableList.index(4)
                except Exception, err:
                    cfg.mx.msgErr44()
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        " ERROR exception: " + str(err))
                    return "No"
                # Intensity (SCP weights)
                I = (0.42 * rasterSCPArrayfunctionBand[:, :, B] + 0.98 * rasterSCPArrayfunctionBand[:, :,
                                                                         G] + 0.6 * rasterSCPArrayfunctionBand[:, :,
                                                                                    R]) / 2
            elif functionBandArgument[0] in ['landsat7', 'landsat_7']:
                try:
                    # functionVariableList = [bandNumber]
                    B = functionVariableList.index(1)
                    G = functionVariableList.index(2)
                    R = functionVariableList.index(3)
                    NIR = functionVariableList.index(4)
                except Exception, err:
                    cfg.mx.msgErr44()
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        " ERROR exception: " + str(err))
                    return "No"
                # Intensity (SCP weights)
                I = (0.42 * rasterSCPArrayfunctionBand[:, :, B] + 0.98 * rasterSCPArrayfunctionBand[:, :,
                                                                         G] + 0.6 * rasterSCPArrayfunctionBand[:, :,
                                                                                    R] + 1 * rasterSCPArrayfunctionBand[
                                                                                             :, :, NIR]) / 3
            if functionBandArgument[1] == cfg.IHS_panType:
                # delta
                d = rasterSCPArrayfunctionBand[:, :, 0] - I
            i = 0
            for oR in outputGdalRasterList:
                # process multiband rasters
                i = i + 1
                if functionBandArgument[1] == cfg.IHS_panType:
                    o = rasterSCPArrayfunctionBand[:, :, i] + d
                elif functionBandArgument[1] == cfg.BT_panType:
                    o = rasterSCPArrayfunctionBand[:, :, i] * rasterSCPArrayfunctionBand[:, :, 0] / I
                # output raster
                try:
                    self.writeArrayBlock(oR, 1, o, pixelStartColumn, pixelStartRow)
                except Exception, err:
                    cfg.mx.msgErr45()
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        " ERROR exception: " + str(err))
            I = None
            o = None
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "Pansharpening")

    # calculate random points
    def randomPoints(self, pointNumber, Xmin, Xmax, Ymin, Ymax, minDistance=None):
        XCoords = cfg.np.random.uniform(Xmin, Xmax, pointNumber).reshape(pointNumber, 1)
        YCoords = cfg.np.random.uniform(Ymin, Ymax, pointNumber).reshape(pointNumber, 1)
        points = cfg.np.hstack((XCoords, YCoords))
        if minDistance is not None:
            for i in range(0, pointNumber):
                distance = cfg.cdistSCP(points, points)
                if i < distance.shape[0]:
                    index = cfg.np.where((distance[i, :] <= minDistance) & (distance[i, :] > 0))
                    points = cfg.np.delete(points, index, 0)
        return points

    # calculate raster unique values
    def rasterUniqueValues(self, gdalBand, rasterArray, columnNumber, rowNumber, pixelStartColumn, pixelStartRow,
                           outputGdalRasterList, functionBandArgumentNoData, functionVariable):
        if cfg.actionCheck == "Yes":
            val = cfg.np.unique(rasterArray)
            # remove multiple nan
            val = cfg.np.unique(val[~cfg.np.isnan(val)])
            cfg.rasterBandUniqueVal = cfg.np.append(cfg.rasterBandUniqueVal, [val], axis=1)
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
            return cfg.rasterBandUniqueVal

    # count pixels in a raster lower than value
    def rasterValueCount(self, gdalBand, rasterArray, columnNumber, rowNumber, pixelStartColumn, pixelStartRow,
                         outputGdalRasterList, functionBandArgumentNoData, functionVariable):
        if cfg.actionCheck == "Yes":
            sum = ((rasterArray <= functionVariable) & (rasterArray != functionBandArgumentNoData)).sum()
            cfg.rasterBandPixelCount = cfg.rasterBandPixelCount + sum
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
            return cfg.rasterBandPixelCount

    # count pixels in a raster equal to value
    def rasterEqualValueCount(self, gdalBand, rasterArray, columnNumber, rowNumber, pixelStartColumn, pixelStartRow,
                              outputGdalRasterList, functionBandArgumentNoData, functionVariable):
        if cfg.actionCheck == "Yes":
            sum = (rasterArray == functionVariable).sum()
            cfg.rasterBandPixelCount = cfg.rasterBandPixelCount + sum
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
            return cfg.rasterBandPixelCount

    # calculate raster unique values (slow)
    def rasterUniqueValuesWithSum(self, gdalBand, rasterArray, columnNumber, rowNumber, pixelStartColumn, pixelStartRow,
                                  outputGdalRasterList, functionBandArgumentNoData, functionVariable):
        if cfg.actionCheck == "Yes":
            val = cfg.np.unique(rasterArray).tolist()
            for i in val:
                if i != functionBandArgumentNoData:
                    sum = (rasterArray == i).sum()
                    index = cfg.np.where(cfg.rasterBandUniqueVal[1, :] == i)
                    if index[0].size > 0:
                        oldVal = cfg.rasterBandUniqueVal[0, index[0]]
                        newValue = oldVal + sum
                        cfg.rasterBandUniqueVal[0, index[0]] = newValue
                    else:
                        cfg.rasterBandUniqueVal = cfg.np.append(cfg.rasterBandUniqueVal, [[sum], [i]], axis=1)
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
            return cfg.rasterBandUniqueVal

    # calculate sum raster unique values
    def rasterSumUniqueValues(self, gdalBand, rasterArray, columnNumber, rowNumber, pixelStartColumn, pixelStartRow,
                              outputGdalRasterList, functionBandArgumentNoData, functionVariable):
        if cfg.actionCheck == "Yes":
            val = cfg.np.unique(rasterArray).tolist()
            for i in val:
                try:
                    oldV = cfg.uVal[str(i)]
                except:
                    oldV = 0
                sum = oldV + (rasterArray == i).sum()
                cfg.uVal[str(i)] = sum
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
            return cfg.uVal

    # count pixels in a raster
    def rasterPixelCount(self, gdalBand, rasterArray, columnNumber, rowNumber, pixelStartColumn, pixelStartRow,
                         outputGdalRasterList, functionBandArgumentNoData, functionVariable):
        if cfg.actionCheck == "Yes":
            for i in range(0, rasterArray.shape[2]):
                a = rasterArray[::, ::, i].flatten() * cfg.bndSetMultiFactorsList[i] + cfg.bndSetAddFactorsList[i]
                if functionBandArgumentNoData is not None:
                    a = a[a != functionBandArgumentNoData]
                count = a.shape[0]
                try:
                    cfg.rasterPixelCountPCA["COUNT_BAND_" + str(i)] = cfg.rasterPixelCountPCA[
                                                                          "COUNT_BAND_" + str(i)] + count
                except:
                    cfg.rasterPixelCountPCA["COUNT_BAND_" + str(i)] = count
                sum = a.sum()
                try:
                    cfg.rasterPixelCountPCA["SUM_BAND_" + str(i)] = cfg.rasterPixelCountPCA["SUM_BAND_" + str(i)] + sum
                except:
                    cfg.rasterPixelCountPCA["SUM_BAND_" + str(i)] = sum
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
            return cfg.rasterPixelCountPCA

    # covariance in a raster
    def rasterCovariance(self, gdalBand, rasterArray, columnNumber, rowNumber, pixelStartColumn, pixelStartRow,
                         outputGdalRasterList, functionBandArgumentNoData, functionVariable):
        if cfg.actionCheck == "Yes":
            comb = cfg.itertoolsSCP.combinations(range(0, rasterArray.shape[2]), 2)
            # covariance
            for i in comb:
                x = rasterArray[::, ::, int(i[0])] * cfg.bndSetMultiFactorsList[i[0]] + cfg.bndSetAddFactorsList[i[0]]
                y = rasterArray[::, ::, int(i[1])] * cfg.bndSetMultiFactorsList[i[1]] + cfg.bndSetAddFactorsList[i[1]]
                a = x - cfg.rasterPixelCountPCA["MEAN_BAND_" + str(i[0])]
                b = y - cfg.rasterPixelCountPCA["MEAN_BAND_" + str(i[1])]
                c = a * b
                cov = c.sum() / (cfg.rasterPixelCountPCA["COUNT_BAND_" + str(i[0])] - 1)
                try:
                    cfg.rasterPixelCountPCA["COV_BAND_" + str(i[0]) + "-" + str(i[1])] = cfg.rasterPixelCountPCA[
                                                                                             "COV_BAND_" + str(
                                                                                                 i[0]) + "-" + str(
                                                                                                 i[1])] + cov
                except:
                    cfg.rasterPixelCountPCA["COV_BAND_" + str(i[0]) + "-" + str(i[1])] = cov
            # variance
            for i in range(0, rasterArray.shape[2]):
                x = rasterArray[::, ::, int(i)] * cfg.bndSetMultiFactorsList[i] + cfg.bndSetAddFactorsList[i]
                a = x - cfg.rasterPixelCountPCA["MEAN_BAND_" + str(i)]
                c = a * a
                cov = c.sum() / (cfg.rasterPixelCountPCA["COUNT_BAND_" + str(i)] - 1)
                try:
                    cfg.rasterPixelCountPCA["COV_BAND_" + str(i) + "-" + str(i)] = cfg.rasterPixelCountPCA[
                                                                                       "COV_BAND_" + str(i) + "-" + str(
                                                                                           i)] + cov
                except:
                    cfg.rasterPixelCountPCA["COV_BAND_" + str(i) + "-" + str(i)] = cov
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
            return cfg.rasterPixelCountPCA

    # calculate PCA bands
    def calculatePCABands(self, gdalBandList, rasterArray, columnNumber, rowNumber, pixelStartColumn, pixelStartRow,
                          outputGdalRasterList, functionBandArgument, functionVariableList):
        n = 0
        for b in range(0, rasterArray.shape[2]):
            rArray = rasterArray * cfg.bndSetMultiFactorsList[b] + cfg.bndSetAddFactorsList[b] - \
                     cfg.rasterPixelCountPCA["MEAN_BAND_" + str(b)]
        for i in functionBandArgument:
            a = cfg.np.array(i) * rArray
            o = a.sum(axis=2)
            # output raster
            try:
                self.writeArrayBlock(outputGdalRasterList[n], 1, o, pixelStartColumn, pixelStartRow)
            except Exception, err:
                cfg.mx.msgErr45()
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
            n = n + 1

    # raster values to list
    def rasterValuesToList(self, gdalBand, rasterArray, columnNumber, rowNumber, pixelStartColumn, pixelStartRow,
                           outputGdalRasterList, functionBandArgumentNoData, functionVariable):
        if cfg.actionCheck == "Yes":
            cfg.uVal = cfg.np.append(cfg.uVal, rasterArray)
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
            return cfg.uVal

    def calculateHistogram2d(self, xVal, yVal, binVal, normedVal=False):
        try:
            h, xE, yE = cfg.np.histogram2d(xVal, yVal, bins=binVal, normed=normedVal)
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
            return [h, xE, yE]
        except Exception, err:
            cfg.mx.msgErr53()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return "No"

    # calculate scatter plot
    def calculateScatterPlot(self, vector, field, id, tempROI="No"):
        # band set
        if cfg.bndSetPresent == "Yes" and cfg.rstrNm == cfg.bndSetNm:
            # crs of loaded raster
            b = cfg.utls.selectLayerbyName(cfg.bndSet[0], "Yes")
            crs = cfg.utls.getCrs(b)
        else:
            # crs of loaded raster
            crs = cfg.utls.getCrs(cfg.rLay)
        # date time for temp name
        dT = cfg.utls.getTime()
        # temporary layer
        tLN = cfg.subsTmpROI + dT + ".shp"
        tLP = cfg.tmpDir + "/" + dT + tLN
        # create a temp shapefile with a field
        cfg.utls.createEmptyShapefileQGIS(crs, tLP)
        mL = cfg.utls.addVectorLayer(tLP, tLN, "ogr")
        try:
            if tempROI == "No":
                rId = cfg.utls.getIDByAttributes(vector, field, str(id))
            else:
                rId = []
                f = QgsFeature()
                for f in vector.getFeatures():
                    rId.append(f.id())
        except Exception, err:
            cfg.mx.msgErr54()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return "No"
        # copy ROI to temp shapefile
        for pI in rId:
            cfg.utls.copyFeatureToLayer(vector, pI, mL)
        bandList = [cfg.scatterBandX - 1, cfg.scatterBandY - 1]
        # clip by ROI
        bX = cfg.utls.subsetImageByShapefile(mL, cfg.rstrNm, bandList)
        # get raster values
        rDC = cfg.gdalSCP.Open(bX[0], cfg.gdalSCP.GA_ReadOnly)
        bLC = cfg.utls.readAllBandsFromRaster(rDC)
        cfg.uVal = cfg.np.array([])
        o = cfg.utls.processRaster(rDC, bLC, None, "No", cfg.utls.rasterValuesToList, None, None, None, None, 0, None,
                                   cfg.NoDataVal, "No", None, None, "value " + str(id))
        xVal = cfg.uVal
        for bR in range(0, len(bLC)):
            bLC[bR] = None
        # close raster
        rDC = None
        rDC = cfg.gdalSCP.Open(bX[1], cfg.gdalSCP.GA_ReadOnly)
        bLC = cfg.utls.readAllBandsFromRaster(rDC)
        cfg.uVal = cfg.np.array([])
        o = cfg.utls.processRaster(rDC, bLC, None, "No", cfg.utls.rasterValuesToList, None, None, None, None, 0, None,
                                   cfg.NoDataVal, "No", None, None, "value " + str(id))
        yVal = cfg.uVal
        for bR in range(0, len(bLC)):
            bLC[bR] = None
        # close raster
        rDC = None
        # calculate histogram
        try:
            xVal2 = xVal[~cfg.np.isnan(xVal)]
            yVal2 = yVal[~cfg.np.isnan(xVal)]
            xVal = xVal2[~cfg.np.isnan(yVal2)]
            yVal = yVal2[~cfg.np.isnan(yVal2)]
            xMax = cfg.np.amax(xVal)
            yMax = cfg.np.amax(yVal)
        except Exception, err:
            cfg.mx.msgErr54()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return "No"
        if cfg.uiscp.precision_checkBox.isChecked():
            rou = int(cfg.uiscp.precision_comboBox.currentText())
            prc = cfg.np.power(10, -float(rou))
            xMin = cfg.np.amin(xVal)
            xMin = cfg.np.around(xMin, rou) - prc
            xMax = cfg.np.around(xMax, rou) + prc
            xSteps = self.calculateSteps(xMin, xMax, prc)
            yMin = cfg.np.amin(yVal)
            yMin = cfg.np.around(yMin, rou) - prc
            yMax = cfg.np.around(yMax, rou) + prc
            ySteps = self.calculateSteps(yMin, yMax, prc)
        elif xMax <= 1.1:
            xMin = cfg.np.amin(xVal)
            xMin = cfg.np.around(xMin, 3) - 0.001
            xMax = cfg.np.around(xMax, 3) + 0.001
            xSteps = self.calculateSteps(xMin, xMax, 0.001)
            yMin = cfg.np.amin(yVal)
            yMin = cfg.np.around(yMin, 3) - 0.001
            yMax = cfg.np.around(yMax, 3) + 0.001
            ySteps = self.calculateSteps(yMin, yMax, 0.001)
        else:
            xMin = cfg.np.amin(xVal)
            xMin = cfg.np.around(xMin, 3) - 10
            xMax = cfg.np.around(xMax, 3) + 10
            xSteps = self.calculateSteps(xMin, xMax, 10)
            yMin = cfg.np.amin(yVal)
            yMin = cfg.np.around(yMin, 3) - 10
            yMax = cfg.np.around(yMax, 3) + 10
            ySteps = self.calculateSteps(yMin, yMax, 10)
        binVal = (xSteps, ySteps)
        h = cfg.utls.calculateHistogram2d(xVal, yVal, binVal)
        return h

    # calculate step list
    def calculateSteps(self, minValue, maxValue, step):
        steps = []
        val = minValue
        steps.append(val)
        while val < maxValue:
            val = val + step
            steps.append(val)
        return steps

    # subset image by vector
    def subsetImageByShapefile(self, vector, rasterName, bandList):
        tLP = vector.source()
        # date time for temp name
        dT = cfg.utls.getTime()
        # calculate ROI center, height and width
        rCX, rCY, rW, rH = cfg.utls.getShapefileRectangleBox(vector)
        bands = []
        # band set
        if cfg.bndSetPresent == "Yes" and rasterName == cfg.bndSetNm:
            tLX, tLY, pS = cfg.utls.imageInformation(cfg.bndSet[0])
            # subset
            for b in bandList:
                tS = str(cfg.tmpDir + "//" + cfg.subsTmpRaster + "_" + str(b) + "_" + dT + ".tif")
                pr = cfg.utls.subsetImage(cfg.bndSet[b], rCX, rCY, int(round(rW / pS + 3)), int(round(rH / pS + 3)), tS)
                if pr == "Yes":
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        " Error edge")
                    # enable map canvas render
                    cfg.cnvs.setRenderFlag(True)
                    return pr
                bX = cfg.utls.clipRasterByShapefile(tLP, tS, None)
                bands.append(bX)
        else:
            # subset
            tLX, tLY, pS = cfg.utls.imageInformation(rasterName)
            tS = str(cfg.tmpDir + "//" + cfg.subsTmpRaster + "_" + dT + ".tif")
            pr = cfg.utls.subsetImage(rasterName, rCX, rCY, int(round(rW / pS + 3)), int(round(rH / pS + 3)), str(tS))
            if pr == "Yes":
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " Error edge")
                # enable map canvas render
                cfg.cnvs.setRenderFlag(True)
                return pr
            oList = cfg.utls.rasterToBands(tS, cfg.tmpDir, None, "No", cfg.bndSetMultAddFactorsList)
            rL = cfg.utls.selectLayerbyName(rasterName, "Yes")
            bCount = rL.bandCount()
            for b in bandList:
                tS = str(cfg.tmpDir + "//" + cfg.subsTmpRaster + "_" + str(b) + "_" + dT + ".tif")
                bX = cfg.utls.clipRasterByShapefile(tLP, oList[b], None)
                bands.append(bX)
        return bands

    # subset image by rectangle
    def subsetImageByRectangle(self, rectangle, rasterName, bandList):
        # date time for temp name
        dT = cfg.utls.getTime()
        # calculate ROI center, height and width
        xMin = rectangle[0]
        xMax = rectangle[1]
        yMin = rectangle[2]
        yMax = rectangle[3]
        rCX = (xMax + xMin) / 2
        rW = (xMax - xMin)
        rCY = (yMax + yMin) / 2
        rH = (yMax - yMin)
        bands = []
        # band set
        if cfg.bndSetPresent == "Yes" and rasterName == cfg.bndSetNm:
            tLX, tLY, pS = cfg.utls.imageInformation(cfg.bndSet[0])
            # subset
            for b in bandList:
                tS = str(cfg.tmpDir + "//" + cfg.subsTmpRaster + "_" + str(b) + "_" + dT + ".tif")
                pr = cfg.utls.subsetImage(cfg.bndSet[b], rCX, rCY, int(round(rW / pS + 3)), int(round(rH / pS + 3)), tS)
                if pr == "Yes":
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        " Error edge")
                    # enable map canvas render
                    cfg.cnvs.setRenderFlag(True)
                    return pr
                bands.append(tS)
        else:
            # subset
            tLX, tLY, pS = cfg.utls.imageInformation(rasterName)
            tS = str(cfg.tmpDir + "//" + cfg.subsTmpRaster + "_" + dT + ".tif")
            pr = cfg.utls.subsetImage(rasterName, rCX, rCY, int(round(rW / pS + 3)), int(round(rH / pS + 3)), str(tS))
            if pr == "Yes":
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " Error edge")
                # enable map canvas render
                cfg.cnvs.setRenderFlag(True)
                return pr
            oList = cfg.utls.rasterToBands(tS, cfg.tmpDir, None, "No", cfg.bndSetMultAddFactorsList)
            n = 0
            for b in oList:
                if n in bandList:
                    bands.append(b)
                n = n + 1
        return bands

    ##################################
    """ Interface functions """

    ##################################

    # Question box
    def questionBox(self, caption, message):
        i = cfg.QtGuiSCP.QWidget()
        q = cfg.QtGuiSCP.QMessageBox.question(i, caption, message, cfg.QtGuiSCP.QMessageBox.Yes,
                                              cfg.QtGuiSCP.QMessageBox.No)
        if q == cfg.QtGuiSCP.QMessageBox.Yes:
            return "Yes"
        if q == cfg.QtGuiSCP.QMessageBox.No:
            return "No"

    # show hide input image
    def showHideInputImage(self):
        if cfg.bndSetPresent == "Yes" and cfg.rstrNm == cfg.bndSetNm:
            i = cfg.tmpVrt
        else:
            i = cfg.utls.selectLayerbyName(cfg.rstrNm, "Yes")
        try:
            if i is not None:
                if cfg.inputImageRadio.isChecked():
                    cfg.lgnd.setLayerVisible(i, True)
                    cfg.utls.moveLayerTop(i)
                else:
                    cfg.lgnd.setLayerVisible(i, False)
        except:
            pass

    # refresh classification combo
    def refreshRasterExtent(self):
        ls = cfg.lgnd.layers()
        cfg.ui.raster_extent_combo.clear()
        cfg.dlg.raster_extent_combo(cfg.mapExtent)
        for l in ls:
            if (l.type() == QgsMapLayer.RasterLayer):
                cfg.dlg.raster_extent_combo(l.name())

    # refresh classification combo
    def refreshClassificationLayer(self):
        ls = cfg.lgnd.layers()
        cfg.ui.classification_name_combo.clear()
        # cfg.ui.classification_name_combo_2.clear()
        cfg.ui.classification_report_name_combo.clear()
        cfg.ui.classification_vector_name_combo.clear()
        cfg.ui.reclassification_name_combo.clear()
        # cfg.ui.edit_raster_name_combo.clear()
        cfg.ui.sieve_raster_name_combo.clear()
        cfg.ui.erosion_raster_name_combo.clear()
        cfg.ui.dilation_raster_name_combo.clear()
        cfg.ui.reference_raster_name_combo.clear()
        # classification name
        self.clssfctnNm = None
        for l in ls:
            if (l.type() == QgsMapLayer.RasterLayer):
                if l.bandCount() == 1:
                    cfg.dlg.classification_layer_combo(l.name())
                    #cfg.dlg.classification_layer_combo_2(l.name())
                    cfg.dlg.classification_report_combo(l.name())
                    cfg.dlg.classification_to_vector_combo(l.name())
                    cfg.dlg.reclassification_combo(l.name())
                    #cfg.dlg.edit_raster_combo(l.name())
                    cfg.dlg.sieve_raster_combo(l.name())
                    cfg.dlg.erosion_raster_combo(l.name())
                    cfg.dlg.dilation_raster_combo(l.name())
                    cfg.dlg.reference_raster_combo(l.name())
        # logger
        cfg.utls.logCondition(str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "classification layers refreshed")

    # refresh vector combo
    def refreshVectorLayer(self):
        cfg.ui.vector_name_combo.blockSignals(True)
        # cfg.ui.vector_name_combo_2.blockSignals(True)
        ls = cfg.lgnd.layers()
        cfg.ui.shapefile_comboBox.clear()
        cfg.ui.vector_name_combo.clear()
        # cfg.ui.vector_name_combo_2.clear()
        for l in ls:
            if (l.type() == QgsMapLayer.VectorLayer):
                if (l.geometryType() == QGis.Polygon):
                    cfg.dlg.shape_clip_combo(l.name())
                    cfg.dlg.vector_to_raster_combo(l.name())
                    # cfg.dlg.vector_edit_raster_combo(l.name())
        cfg.ui.vector_name_combo.blockSignals(False)
        # cfg.ui.vector_name_combo_2.blockSignals(False)
        cfg.utls.refreshVectorFields()
        cfg.utls.refreshVectorFields2()
        # logger
        cfg.utls.logCondition(str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "vector layers refreshed")

    # reference layer name
    def refreshVectorFields(self):
        referenceLayer = cfg.ui.vector_name_combo.currentText()
        cfg.ui.field_comboBox.clear()
        l = cfg.utls.selectLayerbyName(referenceLayer)
        try:
            if l.type() == 0:
                f = l.dataProvider().fields()
                for i in f:
                    if i.typeName() != "String":
                        cfg.dlg.reference_field_combo(unicode(i.name()))
        except:
            pass
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # reference layer name
    def refreshVectorFields2(self):
        referenceLayer = cfg.ui.vector_name_combo_2.currentText()
        cfg.ui.field_comboBox_2.clear()
        l = cfg.utls.selectLayerbyName(referenceLayer)
        try:
            if l.type() == 0:
                f = l.dataProvider().fields()
                for i in f:
                    if i.typeName() != "String":
                        cfg.dlg.reference_field_combo2(unicode(i.name()))
        except:
            pass
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # get random color and complementary color
    def randomColor(self):
        r = cfg.randomSCP.randint(0, 255)
        g = cfg.randomSCP.randint(0, 255)
        b = cfg.randomSCP.randint(0, 255)
        c = cfg.QtGuiSCP.QColor(r, g, b)
        cc = cfg.QtGuiSCP.QColor(255 - r, 255 - r, 225 - r)
        return c, cc

    # select color
    def selectColor(self):
        c = cfg.QtGuiSCP.QColorDialog.getColor()
        if c.isValid():
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "color")
            return c

    # get save file name
    def getSaveFileName(self, parent, text, directory, filterText):
        directory = cfg.lastSaveDir
        out = cfg.QtGuiSCP.QFileDialog.getSaveFileName(None, text, directory, filterText)
        cfg.lastSaveDir = cfg.osSCP.path.dirname(out)
        return out

    # get open file name
    def getOpenFileName(self, parent, text, directory, filterText):
        directory = cfg.lastSaveDir
        out = cfg.QtGuiSCP.QFileDialog.getOpenFileName(None, text, directory, filterText)
        cfg.lastSaveDir = cfg.osSCP.path.dirname(out)
        return out

    # get open file names
    def getOpenFileNames(self, parent, text, directory, filterText):
        directory = cfg.lastSaveDir
        out = cfg.QtGuiSCP.QFileDialog.getOpenFileNames(None, text, directory, filterText)
        if len(out) > 0:
            cfg.lastSaveDir = cfg.osSCP.path.dirname(out[0])
        return out

    # get existing directory
    def getExistingDirectory(self, parent, text):
        directory = cfg.lastSaveDir
        out = cfg.QtGuiSCP.QFileDialog.getExistingDirectory(None, text, directory)
        cfg.lastSaveDir = out
        return out

    ##################################
    """ QGIS functions """

    ##################################

    # get QGIS Proxy settings
    def getQGISProxySettings(self):
        cfg.proxyEnabled = cfg.utls.readRegistryKeys("proxy/proxyEnabled", "")
        cfg.proxyType = cfg.utls.readRegistryKeys("proxy/proxyType", "")
        cfg.proxyHost = cfg.utls.readRegistryKeys("proxy/proxyHost", "")
        cfg.proxyPort = cfg.utls.readRegistryKeys("proxy/proxyPort", "")
        cfg.proxyUser = cfg.utls.readRegistryKeys("proxy/proxyUser", "")
        cfg.proxyPassword = cfg.utls.readRegistryKeys("proxy/proxyPassword", "")

    # save memory layer to shapefile
    def saveMemoryLayerToShapefile(self, memoryLayer, output, name=None):
        shpF = output
        # create shapefile
        f = QgsFields()
        # add Class ID, macroclass ID and Info fields
        f.append(QgsField(cfg.fldMacroID_class, cfg.QVariantSCP.Int))
        f.append(QgsField(cfg.fldROIMC_info, cfg.QVariantSCP.String))
        f.append(QgsField(cfg.fldID_class, cfg.QVariantSCP.Int))
        f.append(QgsField(cfg.fldROI_info, cfg.QVariantSCP.String))
        f.append(QgsField(cfg.fldSCP_UID, cfg.QVariantSCP.String))
        try:
            pCrs = cfg.utls.getCrs(memoryLayer)
        except Exception, err:
            cfg.mx.msgErr59()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return "No"
        QgsVectorFileWriter(unicode(shpF), "CP1250", f, QGis.WKBMultiPolygon, pCrs, "ESRI Shapefile")
        if name is None:
            name = cfg.osSCP.path.basename(shpF)
        tSS = cfg.utls.addVectorLayer(shpF, name, "ogr")
        tSS.updateFields()
        f = QgsFeature()
        tSS.startEditing()
        for f in memoryLayer.getFeatures():
            tSS.addFeature(f)
        tSS.commitChanges()
        tSS.dataProvider().createSpatialIndex()
        tSS.updateExtents()
        return tSS

    # read registry keys
    def readRegistryKeys(self, key, value):
        rK = cfg.QSettingsSCP()
        val = rK.value(key, value)
        return val

    # create a polygon shapefile with QGIS
    def createEmptyShapefileQGIS(self, crs, outputVector):
        fields = QgsFields()
        # add field
        fN = cfg.emptyFN
        fields.append(QgsField(fN, cfg.QVariantSCP.Int))
        QgsVectorFileWriter(unicode(outputVector), "CP1250", fields, QGis.WKBMultiPolygon, crs, "ESRI Shapefile")

    # Raster no data value
    def imageNoDataValue(self, rasterPath):
        rD = cfg.gdalSCP.Open(rasterPath, cfg.gdalSCP.GA_ReadOnly)
        gBand = rD.GetRasterBand(1)
        nd = gBand.GetNoDataValue()
        gBand = None
        rD = None
        return nd

    # Raster no data value
    def imageNoDataValueQGIS(self, qgisRaster):
        nd = qgisRaster.dataProvider().srcNoDataValue(1)
        return nd

    # Raster top left origin and pixel size
    def imageInformation(self, imageName):
        try:
            i = self.selectLayerbyName(imageName, "Yes")
            # TopLeft X coord
            tLX = i.extent().xMinimum()
            # TopLeft Y coord
            tLY = i.extent().yMaximum()
            # pixel size
            pS = i.rasterUnitsPerPixelX()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "image: " + unicode(imageName) + " topleft: (" + str(tLX) + "," + str(tLY) + ")")
            # return a tuple TopLeft X, TopLeft Y, and Pixel size
            return tLX, tLY, pS
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return None, None, None

    # Raster size
    def imageInformationSize(self, imageName):
        try:
            i = self.selectLayerbyName(imageName, "Yes")
            # TopLeft X coord
            tLX = i.extent().xMinimum()
            # TopLeft Y coord
            tLY = i.extent().yMaximum()
            # LowRight X coord
            lRY = i.extent().yMinimum()
            # LowRight Y coord
            lRX = i.extent().xMaximum()
            # pixel size
            pSX = i.rasterUnitsPerPixelX()
            pSY = i.rasterUnitsPerPixelX()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "image: " + unicode(imageName) + " topleft: (" + str(tLX) + "," + str(tLY) + ")")
            # return a tuple TopLeft X, TopLeft Y, and Pixel size
            return tLX, tLY, lRX, lRY, pSX, pSY
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return None, None, None, None, None

    # Get CRS of a layer by name thereof
    def getCrs(self, layer):
        if layer is None:
            crs = None
        else:
            rP = layer.dataProvider()
            crs = rP.crs()
        return crs

    # Pan action
    def pan(self):
        cfg.toolPan = QgsMapToolPan(cfg.cnvs)
        cfg.cnvs.setMapTool(cfg.toolPan)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "pan action")

    # Project point coordinates
    def projectPointCoordinates(self, point, inputCoordinates, outputCoordinates):
        try:
            t = QgsCoordinateTransform(inputCoordinates, outputCoordinates)
            point = t.transform(point)
            return point
        # if empty shapefile
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return False

    # Group index by its name
    def groupIndex(self, groupName):
        g = cfg.lgnd.groups()
        if len(g) > 0:
            # all positions
            aP = len(g)
            for p in range(0, aP):
                if g[p] == groupName:
                    # group position
                    return p
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        "group " + unicode(groupName) + " Position: " + unicode(p))

    # Layer ID by its name
    def layerID(self, layerName):
        ls = cfg.lgnd.layers()
        for l in ls:
            lN = l.name()
            if lN == layerName:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    "layer: " + unicode(layerName) + " ID: " + unicode(l.id()))
                return l.id()

    # read project variable
    def readProjectVariable(self, variableName, value):
        p = cfg.qgisCoreSCP.QgsProject.instance()
        v = p.readEntry("SemiAutomaticClassificationPlugin", variableName, value)[0]
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "variable: " + unicode(variableName) + " - value: " + unicode(value))
        return v

    # read QGIS path project variable
    def readQGISVariablePath(self):
        cfg.projPath = cfg.qgisCoreSCP.QgsProject.instance().fileName()
        p = cfg.qgisCoreSCP.QgsProject.instance()
        v = p.readEntry("Paths", "Absolute", "")[0]
        cfg.absolutePath = v

    # write project variable
    def writeProjectVariable(self, variableName, value):
        p = cfg.qgisCoreSCP.QgsProject.instance()
        p.writeEntry("SemiAutomaticClassificationPlugin", variableName, value)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "variable: " + unicode(variableName) + " - value: " + unicode(value))

    # absolute to relative path
    def qgisAbsolutePathToRelativePath(self, absolutePath, relativePath):
        p = cfg.qgisCoreSCP.QgsApplication.absolutePathToRelativePath(absolutePath, relativePath)
        return p

    # relative to absolute path
    def qgisRelativePathToAbsolutePath(self, relativePath, absolutePath):
        p = cfg.qgisCoreSCP.QgsApplication.relativePathToAbsolutePath(relativePath, absolutePath)
        return p

    # Remove layer from map
    def removeLayer(self, layerName):
        try:
            QgsMapLayerRegistry.instance().removeMapLayer(self.layerID(layerName))
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "layer: " + unicode(layerName))
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))

    # Remove layer from map
    def removeLayerByLayer(self, layer):
        try:
            QgsMapLayerRegistry.instance().removeMapLayer(layer.id())
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))

    # Remove layer from map
    def removeGroup(self, groupName):
        g = cfg.utls.groupIndex(cfg.grpNm)
        try:
            if g is not None:
                cfg.lgnd.removeGroup(g)
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "group: " + unicode(groupName))
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))

    # remove temporary files from project
    def removeTempFiles(self):
        # disable map canvas render
        cfg.cnvs.setRenderFlag(False)
        try:
            for p in cfg.prevList:
                pp = cfg.utls.selectLayerbyName(p.name())
                if pp is not None:
                    cfg.utls.removeLayerByLayer(p)
            vrt = cfg.utls.selectLayerbyName(cfg.tmpVrtNm + ".vrt")
            if vrt is not None:
                cfg.utls.removeLayerByLayer(cfg.tmpVrt)
            cfg.utls.removeGroup(cfg.grpNm)
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
        cfg.prevList = []
        cfg.tmpVrt = None
        # enable map canvas render
        cfg.cnvs.setRenderFlag(True)

    # Create group
    def createGroup(self, groupName):
        g = cfg.lgnd.addGroup(groupName, False)
        cfg.utls.moveGroup(groupName)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "group: " + unicode(groupName))
        return g

    # Move group to top layers
    def moveGroup(self, groupName):
        # QGIS >= 2.4
        try:
            p = cfg.qgisCoreSCP.QgsProject.instance()
            root = p.layerTreeRoot()
            g = root.findGroup(groupName)
            cG = g.clone()
            root.insertChildNode(0, cG)
            root.removeChildNode(g)
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "group: " + unicode(groupName))
        # QGIS < 2.4
        except Exception, err:
            if "layerTreeRoot" not in str(err):
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))

    # Move layer to top layers
    def moveLayerTop(self, layer):
        # QGIS >= 2.4
        try:
            p = cfg.qgisCoreSCP.QgsProject.instance()
            root = p.layerTreeRoot()
            g = root.findLayer(layer.id())
            cG = g.clone()
            root.insertChildNode(0, cG)
            root.removeChildNode(g)
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "layer: " + unicode(layer.name()))
        # QGIS < 2.4
        except Exception, err:
            if "layerTreeRoot" not in str(err):
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))

    # Select layer by name thereof
    def selectLayerbyName(self, layerName, filterRaster=None):
        ls = cfg.lgnd.layers()
        for l in ls:
            lN = l.name()
            if lN == layerName:
                if filterRaster is None:
                    return l
                else:
                    if l.type() == 1:
                        return l
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "layer selected: " + unicode(layerName))

    # file path
    def getFilePath(self, layerName):
        try:
            l = cfg.utls.selectLayerbyName(layerName)
            filePath = l.source()
            return filePath
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))

    # set map extent from layer
    def setMapExtentFromLayer(self, layer):
        ext = layer.extent()
        tLPoint = QgsPoint(ext.xMinimum(), ext.yMaximum())
        lRPoint = QgsPoint(ext.xMaximum(), ext.yMinimum())
        point1 = tLPoint
        point2 = lRPoint
        # project extent
        iCrs = cfg.utls.getCrs(layer)
        pCrs = cfg.utls.getQGISCrs()
        if iCrs is None:
            iCrs = pCrs
        # projection of input point from raster's crs to project's crs
        if pCrs != iCrs:
            try:
                point1 = cfg.utls.projectPointCoordinates(tLPoint, iCrs, pCrs)
                point2 = cfg.utls.projectPointCoordinates(lRPoint, iCrs, pCrs)
                if point1 is False:
                    point1 = tLPoint
                    point2 = lRPoint
            # Error latitude or longitude exceeded limits
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                point1 = tLPoint
                point2 = lRPoint
        cfg.cnvs.setExtent(QgsRectangle(point1, point2))

    # save a qml style
    def saveQmlStyle(self, layer, stylePath):
        layer.saveNamedStyle(stylePath)

    # Zoom to selected feature of layer
    def zoomToSelected(self, layer, featureID):
        layer.removeSelection()
        layer.select(featureID)
        cfg.cnvs.zoomToSelected(layer)
        layer.deselect(featureID)

    # Zoom to band set
    def zoomToBandset(self):
        if cfg.bndSetPresent == "Yes" and cfg.rstrNm == cfg.bndSetNm:
            b = cfg.utls.selectLayerbyName(cfg.bndSet[0], "Yes")
        else:
            b = cfg.utls.selectLayerbyName(cfg.rstrNm, "Yes")
        if b is not None:
            cfg.utls.setMapExtentFromLayer(b)
            cfg.cnvs.refresh()

    # Add layer to map
    def addLayerToMap(self, layer):
        QgsMapLayerRegistry.instance().addMapLayers([layer])

    # Add layer
    def addVectorLayer(self, path, name, format):
        l = QgsVectorLayer(path, name, format)
        return l

    # Add raster layer
    def addRasterLayer(self, path, name):
        if cfg.osSCP.path.isfile(path):
            r = cfg.iface.addRasterLayer(path, name)
            return r
        else:
            return "No"

    # Get QGIS project CRS
    def getQGISCrs(self):
        # QGIS < 2.4
        try:
            pCrs = cfg.cnvs.mapRenderer().destinationCrs()
        # QGIS >= 2.4
        except:
            pCrs = cfg.cnvs.mapSettings().destinationCrs()
        return pCrs

    # Set QGIS project CRS
    def setQGISCrs(self, crs):
        # QGIS < 2.4
        try:
            cfg.cnvs.mapRenderer().setDestinationCrs(crs)
        # QGIS >= 2.4
        except:
            cfg.cnvs.setDestinationCrs(crs)

    ##################################
    """ raster GDAL functions """

    ##################################

    # Get the number of bands of a raster
    def getNumberBandRaster(self, raster):
        rD = cfg.gdalSCP.Open(raster, cfg.gdalSCP.GA_ReadOnly)
        number = rD.RasterCount
        rD = None
        return number

    # # set GDAL cache max (deprecated)
    # def setGDALCacheMax(self, value):
    # c = cfg.gdalSCP.GetCacheMax()
    # cfg.gdalSCP.SetCacheMax(value)

    # raster sieve with GDAL
    def rasterSieve(self, inputRaster, outputRaster, pixelThreshold, connect=4, outFormat="GTiff", quiet="No"):
        if cfg.sysSCPNm == "Windows":
            gD = "gdal_sieve.bat"
        else:
            gD = "gdal_sieve.py"
        st = "No"
        try:
            cfg.utls.getGDALForMac()
            a = cfg.gdalPath + gD + " -st " + str(pixelThreshold) + " -" + str(
                connect) + " " + inputRaster + " -of " + outFormat + " " + outputRaster
            sP = cfg.subprocessSCP.Popen(a, shell=True, stdout=cfg.subprocessSCP.PIPE, stderr=cfg.subprocessSCP.PIPE)
            sP.wait()
            # get error
            out, err = sP.communicate()
            sP.stdout.close()
            if len(err) > 0:
                st = "Yes"
                if quiet == "No":
                    cfg.mx.msgErr45()
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " GDAL error: " + str(err))
        # in case of errors
        except Exception, err:
            cfg.utls.getGDALForMac()
            a = cfg.gdalPath + gD + " -st " + str(pixelThreshold) + " -" + str(
                connect) + " " + inputRaster + " -of " + outFormat + " " + outputRaster
            sP = cfg.subprocessSCP.Popen(a, shell=True)
            sP.wait()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),"sieve: " + unicode(outputRaster))
        return st

    # create virtual raster with GDAL
    def createVirtualRaster(self, inputRasterList, output, bandNumber="No", quiet="No"):
        r = ""
        st = "No"
        for i in inputRasterList:
            r = r + ' "' + i + '"'
        if bandNumber == "No":
            bndOption = " -separate"
        else:
            bndOption = "-b " + str(bandNumber)
        try:
            cfg.utls.getGDALForMac()
            sP = cfg.subprocessSCP.Popen(
                cfg.gdalPath + 'gdalbuildvrt -resolution highest ' + bndOption + ' "' + output.encode(
                    cfg.sysSCP.getfilesystemencoding()) + '" ' + r.encode(cfg.sysSCP.getfilesystemencoding()),
                shell=True, stdout=cfg.subprocessSCP.PIPE, stderr=cfg.subprocessSCP.PIPE)
            sP.wait()
            # get error
            out, err = sP.communicate()
            sP.stdout.close()
            if len(err) > 0:
                st = "Yes"
                if quiet == "No":
                    cfg.mx.msgWar13()
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " GDAL error: " + str(err))
        # in case of errors
        except Exception, err:
            cfg.utls.getGDALForMac()
            sP = cfg.subprocessSCP.Popen(
                cfg.gdalPath + 'gdalbuildvrt -resolution highest ' + bndOption + ' "' + output.encode(
                    cfg.sysSCP.getfilesystemencoding()) + '" ' + r.encode(cfg.sysSCP.getfilesystemencoding()),
                shell=True)
            sP.wait()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "virtual raster: " + unicode(output))
        return st

    # build GDAL overviews
    def buildOverviewsGDAL(self, inputRaster):
        try:
            cfg.utls.getGDALForMac()
            sP = cfg.subprocessSCP.Popen(cfg.gdalPath + 'gdaladdo -r NEAREST -ro "' + inputRaster + '" 8 16 32 64 ',
                                         shell=True, stdout=cfg.subprocessSCP.PIPE, stderr=cfg.subprocessSCP.PIPE)
            sP.wait()
            # get error
            out, err = sP.communicate()
            sP.stdout.close()
        # if len(err) > 0:
        # 	# logger
        # 	cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3])+ " " + cfg.utls.lineOfCode(), " GDAL error: " + str(err) )
        # else:
        # 	# logger
        # 	cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3])+ " " + cfg.utls.lineOfCode(), "build overviews" + unicode(i))
        # in case of errors
        except Exception, err:
            cfg.utls.getGDALForMac()
            sP = cfg.subprocessSCP.Popen(cfg.gdalPath + 'gdaladdo -r NEAREST -ro "' + inputRaster + '" 8 16 32 64 ',
                                         shell=True)
            sP.wait()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "build overviews" + unicode(inputRaster))

    # Try to get GDAL for Mac
    def getGDALForMac(self):
        if cfg.sysSCPNm == "Darwin":
            v = cfg.utls.getGDALVersion()
            cfg.gdalPath = '/Library/Frameworks/GDAL.framework/Versions/' + v[0] + '.' + v[1] + '/Programs/'
            if cfg.osSCP.path.isfile(cfg.gdalPath + "gdal_translate"):
                pass
            else:
                cfg.gdalPath = ''
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " getGDALForMac: " + unicode(cfg.gdalPath))

    # Get GDAL version
    def getGDALVersion(self):
        v = cfg.gdalSCP.VersionInfo("RELEASE_NAME").split('.')
        return v

    # get a raster band statistic
    def getRasterBandStatistics(self, inputRaster, band, multiAddList=None):
        # open input with GDAL
        rD = cfg.gdalSCP.Open(inputRaster, cfg.gdalSCP.GA_ReadOnly)
        if rD is None:
            bSt = None
            a = None
        else:
            iRB = rD.GetRasterBand(band)
            bSt = iRB.GetStatistics(True, True)
            a = iRB.ReadAsArray()
            if multiAddList is not None:
                a = cfg.utls.arrayMultiplicativeAdditiveFactors(a, multiAddList[0], multiAddList[1])
                bSt = [bSt[0] * multiAddList[0] + multiAddList[1], bSt[1] * multiAddList[0] + multiAddList[1],
                       bSt[2] * multiAddList[0] + multiAddList[1], bSt[3] * multiAddList[0]]
            # close band
            iRB = None
            # close raster
            rD = None
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "get band: " + unicode(band))
        return bSt, a

    # get ROI size
    def getROISize(self, inputRaster, band, min, max):
        # open input with GDAL
        rD = cfg.gdalSCP.Open(inputRaster, cfg.gdalSCP.GA_ReadOnly)
        if rD is None:
            s = None
        else:
            iRB = rD.GetRasterBand(band)
            a = iRB.ReadAsArray()
            s = ((a >= min) & (a <= max)).sum()
            # close band
            iRB = None
            # close raster
            rD = None
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "get band: " + unicode(band))
        return s

    # Get raster data type name
    def getRasterDataTypeName(self, inputRaster):
        rD = cfg.gdalSCP.Open(inputRaster, cfg.gdalSCP.GA_ReadOnly)
        b = rD.GetRasterBand(1)
        dType = cfg.gdalSCP.GetDataTypeName(b.DataType)
        rD = None
        return dType

    # create GDAL raster table
    def createRasterTable(self, rasterPath, bandNumber, signatureList):
        r = cfg.gdalSCP.Open(rasterPath, cfg.gdalSCP.GA_Update)
        b = r.GetRasterBand(bandNumber)
        at = cfg.gdalSCP.RasterAttributeTable()
        at.CreateColumn(str(cfg.fldID_class), cfg.gdalSCP.GFT_Integer, cfg.gdalSCP.GFU_Generic)
        at.CreateColumn(str(cfg.fldROI_info), cfg.gdalSCP.GFT_String, cfg.gdalSCP.GFU_Generic)
        v = signatureList
        if cfg.macroclassCheck == "Yes":
            mc = []
            for c in range(len(v)):
                mc.append(int(v[c][0]))
            mcList = list(set(mc))
            for i in range(len(mcList)):
                at.SetValueAsInt(i, 0, mcList[i])
                ind = mc.index(mcList[i])
                at.SetValueAsString(i, 1, v[ind][1])
        else:
            for i in range(len(v)):
                at.SetValueAsInt(i, 0, int(v[i][2]))
                at.SetValueAsString(i, 1, v[i][3])
        b.SetDefaultRAT(at)
        b = None
        r = None
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "" + unicode(rasterPath))

    # read all raster from band
    def readAllBandsFromRaster(self, gdalRaster):
        bandNumber = gdalRaster.RasterCount
        bandList = []
        for b in range(1, bandNumber + 1):
            rB = gdalRaster.GetRasterBand(b)
            bandList.append(rB)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())
        return bandList

    # copy raster with GDAL
    def GDALCopyRaster(self, input, output, outFormat="GTiff", compress="No", compressFormat="DEFLATE",
                       additionalParams=""):
        outDir = cfg.osSCP.path.dirname(output)
        cfg.utls.makeDirectory(outDir)
        if compress == "No":
            op = " -of " + outFormat
        else:
            op = " -co COMPRESS=" + compressFormat + " -of " + outFormat
        try:
            cfg.utls.getGDALForMac()
            gD = "gdal_translate"
            a = cfg.gdalPath + gD + " " + additionalParams + " " + op
            b = '"' + input + '" '
            c = '"' + output + '" '
            d = a + " " + b + " " + c
            sP = cfg.subprocessSCP.Popen(d, shell=True, stdout=cfg.subprocessSCP.PIPE, stderr=cfg.subprocessSCP.PIPE)
            sP.wait()
            # get error
            out, err = sP.communicate()
            sP.stdout.close()
            if len(err) > 0:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " GDAL error:: " + str(err))
        # in case of errors
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            cfg.utls.getGDALForMac()
            gD = "gdal_translate"
            a = cfg.gdalPath + gD + " " + additionalParams + " " + op
            b = '"' + input + '" '
            c = '"' + output + '" '
            d = a + " " + b + " " + c
            sP = cfg.subprocessSCP.Popen(d, shell=True)
            sP.wait()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              " image: " + unicode(output))

    # reproject raster with GDAL
    def GDALReprojectRaster(self, input, output, outFormat="GTiff", s_srs=None, t_srs=None, additionalParams=None):
        outDir = cfg.osSCP.path.dirname(output)
        cfg.utls.makeDirectory(outDir)
        if s_srs is None:
            op = " -t_srs " + t_srs + " -of " + outFormat
        else:
            op = " -s_srs " + s_srs + " -t_srs " + t_srs + " -of " + outFormat
        if additionalParams is None:
            pass
        else:
            op = " " + additionalParams + " " + op
        try:
            cfg.utls.getGDALForMac()
            gD = "gdalwarp"
            a = cfg.gdalPath + gD + op
            if '"' in input:
                b = input
            else:
                b = '"' + input + '" '
            c = '"' + output + '" '
            d = a + " " + b + " " + c
            sP = cfg.subprocessSCP.Popen(d, shell=True, stdout=cfg.subprocessSCP.PIPE, stderr=cfg.subprocessSCP.PIPE)
            sP.wait()
            # get error
            out, err = sP.communicate()
            sP.stdout.close()
            if len(err) > 0:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " GDAL error:: " + str(err))
        # in case of errors
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            cfg.utls.getGDALForMac()
            gD = "gdalwarp"
            a = cfg.gdalPath + gD + op
            if '"' in input:
                b = input
            else:
                b = '"' + input + '" '
            c = '"' + output + '" '
            d = a + " " + b + " " + c
            sP = cfg.subprocessSCP.Popen(d, shell=True)
            sP.wait()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              " image: " + unicode(output))

    # Merge raster bands
    def mergeRasterBands(self, bandList, output, outFormat="GTiff", compress="No"):
        if compress == "No":
            op = "-of " + outFormat
        else:
            op = "-co COMPRESS=LZW -of " + outFormat
        input = ""
        for b in bandList:
            input = input + '"' + b.encode(cfg.sysSCP.getfilesystemencoding()) + '" '
        input = input
        try:
            cfg.utls.getGDALForMac()
            if cfg.sysSCPNm == "Windows":
                gD = "gdal_merge.bat"
            else:
                gD = "gdal_merge.py"
            a = cfg.gdalPath + gD + ' -separate ' + op + ' -o '
            b = '"' + output.encode(cfg.sysSCP.getfilesystemencoding()) + '" '
            c = input
            d = a + b + c
            sP = cfg.subprocessSCP.Popen(d, shell=True, stdout=cfg.subprocessSCP.PIPE, stderr=cfg.subprocessSCP.PIPE)
            sP.wait()
            # get error
            out, err = sP.communicate()
            sP.stdout.close()
            if len(err) > 0:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " GDAL error:: " + str(err))
        # in case of errors
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            cfg.utls.getGDALForMac()
            if cfg.sysSCPNm == "Windows":
                gD = "gdal_merge.bat"
            else:
                gD = "gdal_merge.py"
            a = cfg.gdalPath + gD + ' -separate ' + op + ' -o '
            b = '"' + output.encode(cfg.sysSCP.getfilesystemencoding()) + '" '
            c = input
            d = a + b + c
            sP = cfg.subprocessSCP.Popen(d, shell=True)
            sP.wait()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              " image: " + unicode(output))

    # Subset an image, given an origin point and a subset width
    def subsetImage(self, imageName, XCoord, YCoord, Width, Height, output, outFormat="GTiff", virtual="No"):
        i = self.selectLayerbyName(imageName, "Yes")
        # output variable
        st = "Yes"
        if i is not None:
            bandNumberList = []
            for bb in range(1, i.bandCount() + 1):
                bandNumberList.append(bb)
            i = i.source().encode(cfg.sysSCP.getfilesystemencoding())
            st = "No"
            # raster top left origin and pixel size
            tLX, tLY, lRX, lRY, pSX, pSY = self.imageInformationSize(imageName)
            if pSX is None:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " image none or missing")
            else:
                try:
                    dType = self.getRasterDataTypeName(i)
                    # subset origin
                    UX = tLX + abs(int((tLX - XCoord) / pSX)) * pSX - (Width - 1) / 2 * pSX
                    UY = tLY - abs(int((tLY - YCoord) / pSY)) * pSY + (Height - 1) / 2 * pSY
                    LX = UX + Width * pSX
                    LY = UY - Height * pSY
                    dT = cfg.utls.getTime()
                    tPMN = cfg.tmpVrtNm + ".vrt"
                    tPMD = cfg.tmpDir + "/" + dT + tPMN
                    bList = [i]
                    if virtual == "No":
                        st = cfg.utls.createVirtualRaster2(bList, tPMD, bandNumberList, "Yes", cfg.NoDataVal, 0, "No",
                                                           "Yes", [float(UX), float(UY), float(LX), float(LY)])
                        clipOutput = cfg.utls.copyRaster(tPMD, output, str(outFormat), cfg.NoDataVal)
                        st = clipOutput
                    else:
                        st = cfg.utls.createVirtualRaster2(bList, output, bandNumberList, "Yes", cfg.NoDataVal, 0, "No",
                                                           "Yes", [float(UX), float(UY), float(LX), float(LY)])
                # in case of errors
                except Exception, err:
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        " ERROR exception: " + str(err))
                    st = "Yes"
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    "image: " + unicode(imageName) + " subset origin: (" + str(XCoord) + "," + str(
                        YCoord) + ") width: " + str(Width))
        return st

    # get EPSG for vector
    def getEPSGVector(self, layerPath):
        l = cfg.ogrSCP.Open(layerPath)
        if l is None:
            return "No"
        gL = l.GetLayer()
        # check projection
        lP = cfg.osrSCP.SpatialReference()
        lP = gL.GetSpatialRef()
        lP.AutoIdentifyEPSG()
        lPRS = lP.GetAuthorityCode(None)
        # try with QGIS
        if lPRS is None:
            mL = cfg.utls.addVectorLayer(layerPath, "tempA", "ogr")
            lPRStr = mL.crs().authid()
            lPRStr = lPRStr.split(":")
            if lPRStr[0] == "EPSG":
                lPRS = lPRStr[1]
            cfg.utls.removeLayerByLayer(mL)
        try:
            epsg = int(lPRS)
        except Exception, err:
            epsg = None
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
        l.Destroy()
        return epsg

    # get EPSG for vector QGIS
    def getEPSGVectorQGIS(self, layer):
        pCrs = cfg.utls.getCrs(layer)
        id = pCrs.authid()
        try:
            id = int(id.replace("EPSG:", ""))
        except:
            pass
        return id

    # get EPSG for raster
    def getEPSGRaster(self, layerPath):
        rD = cfg.gdalSCP.Open(layerPath, cfg.gdalSCP.GA_ReadOnly)
        # check projections
        rP = rD.GetProjection()
        rPSys = cfg.osrSCP.SpatialReference(wkt=rP)
        rPSys.AutoIdentifyEPSG()
        rPRS = rPSys.GetAuthorityCode(None)
        try:
            epsg = int(rPRS)
        except Exception, err:
            cfg.mx.msgErr61(str(layerPath))
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
        return epsg

    # convert reference layer to raster based on the resolution of a raster
    def vectorToRaster(self, fieldName, layerPath, referenceRasterName, outputRaster, referenceRasterPath=None,
                       ALL_TOUCHED=None, outFormat="GTiff", burnValues=None):
        if referenceRasterPath is None:
            # band set
            if cfg.bndSetPresent == "Yes" and referenceRasterName == cfg.bndSetNm:
                referenceRasterName = cfg.bndSet[0]
                # input
                r = self.selectLayerbyName(referenceRasterName, "Yes")
            else:
                if self.selectLayerbyName(referenceRasterName, "Yes") is None:
                    cfg.mx.msg4()
                    cfg.ipt.refreshRasterLayer()
                else:
                    # input
                    r = self.selectLayerbyName(referenceRasterName, "Yes")
            try:
                rS = r.source()
                ck = "Yes"
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                ck = "No"
                cfg.mx.msg4()
                return ck
        else:
            rS = referenceRasterPath
        try:
            # open input with GDAL
            rD = cfg.gdalSCP.Open(rS, cfg.gdalSCP.GA_ReadOnly)
            # number of x pixels
            rC = rD.RasterXSize
            # number of y pixels
            rR = rD.RasterYSize
            # check projections
            rP = rD.GetProjection()
            # pixel size and origin
            rGT = rD.GetGeoTransform()
        # in case of errors
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            cfg.mx.msg4()
            return "No"
        l = cfg.ogrSCP.Open(layerPath)
        try:
            gL = l.GetLayer()
        # in case of errors
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            cfg.mx.msgErr34()
            return "No"
        # check projection
        lPRS = cfg.utls.getEPSGVector(layerPath)
        rPSys = cfg.osrSCP.SpatialReference(wkt=rP)
        rPSys.AutoIdentifyEPSG()
        rPRS = rPSys.GetAuthorityCode(None)
        if lPRS is not None:
            if lPRS != rPRS:
                # date time for temp name
                dT = cfg.utls.getTime()
                reprjShapefile = cfg.tmpDir + "/" + dT + cfg.osSCP.path.basename(layerPath)
                try:
                    cfg.utls.repojectShapefile(layerPath, int(lPRS), reprjShapefile, int(rPRS))
                except Exception, err:
                    # logger
                    cfg.utls.logCondition(
                        str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                        " ERROR exception: " + str(err))
                    cfg.mx.msg9()
                    return "No"
                l.Destroy()
                l = cfg.ogrSCP.Open(reprjShapefile)
                gL = l.GetLayer()
            minX, maxX, minY, maxY = gL.GetExtent()
            origX = rGT[0] + rGT[1] * int(round((minX - rGT[0]) / rGT[1]))
            origY = rGT[3] + rGT[5] * int(round((maxY - rGT[3]) / rGT[5]))
            rC = abs(int(round((maxX - minX) / rGT[1])))
            rR = abs(int(round((maxY - minY) / rGT[5])))
            tD = cfg.gdalSCP.GetDriverByName(outFormat)
            tPMN2 = dT + cfg.calcRasterNm + ".tif"
            tPMD2 = cfg.tmpDir + "/" + tPMN2
            oR = tD.Create(tPMD2, rC, rR, 1, cfg.gdalSCP.GDT_Float32)
            try:
                oRB = oR.GetRasterBand(1)
            # in case of errors
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                cfg.mx.msgErr34()
                return "No"
            # set raster projection from reference
            oR.SetGeoTransform([origX, rGT[1], 0, origY, 0, rGT[5]])
            oR.SetProjection(rP)
            # output rasters
            oM = []
            oM.append(outputRaster)
            oMR = cfg.utls.createRasterFromReference(oR, 1, oM, 0, "GTiff", cfg.rasterDataType, 0, None, "No")
            e = str("a * 0")
            variableList = [["im1", "a"]]
            o = cfg.utls.processRaster(oR, [oRB], None, "No", cfg.utls.bandCalculation, None, oMR, None, None, 0, None,
                                       0, "No", e, variableList, "No")
            # close bands
            oRB = None
            # close rasters
            oR = None
            oMR = None
            oR2 = cfg.gdalSCP.Open(outputRaster, cfg.gdalSCP.GA_Update)
            # convert reference layer to raster
            if ALL_TOUCHED is None:
                if burnValues is None:
                    oC = cfg.gdalSCP.RasterizeLayer(oR2, [1], gL, options=["ATTRIBUTE=" + str(fieldName)])
                else:
                    oC = cfg.gdalSCP.RasterizeLayer(oR2, [1], gL, burn_values=[burnValues])
            else:
                if burnValues is None:
                    oC = cfg.gdalSCP.RasterizeLayer(oR2, [1], gL,
                                                    options=["ATTRIBUTE=" + str(fieldName), "ALL_TOUCHED=TRUE"])
                else:
                    oC = cfg.gdalSCP.RasterizeLayer(oR2, [1], gL, burn_values=[burnValues],
                                                    options=["ALL_TOUCHED=TRUE"])

            # close rasters
            oR2 = None
            rD = None
            l.Destroy()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "vector to raster check: " + unicode(oC))
        else:
            cfg.mx.msg9()
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "Error None lPRS: " + unicode(lPRS) + "rPRS: " + unicode(rPRS))
            return "No"

    # convert raster to shapefile
    def rasterToVector(self, rasterPath, outputShapefilePath, fieldName="No"):
        tD = cfg.gdalSCP.GetDriverByName("GTiff")
        # open input with GDAL
        try:
            rD = cfg.gdalSCP.Open(rasterPath, cfg.gdalSCP.GA_ReadOnly)
            # number of x pixels
            rC = rD.RasterXSize
        # in case of errors
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return "No"
        # create a shapefile
        d = cfg.ogrSCP.GetDriverByName('ESRI Shapefile')
        dS = d.CreateDataSource(outputShapefilePath)
        if dS is None:
            # close rasters
            rD = None
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " error: " + unicode(outputShapefilePath))
        else:
            # shapefile
            sR = cfg.osrSCP.SpatialReference()
            sR.ImportFromWkt(rD.GetProjectionRef())
            rL = dS.CreateLayer(cfg.osSCP.path.basename(rasterPath).encode(cfg.sysSCP.getfilesystemencoding()), sR,
                                cfg.ogrSCP.wkbMultiPolygon)
            if fieldName == "No":
                fN = str(cfg.fldID_class)
            else:
                fN = fieldName
            fd = cfg.ogrSCP.FieldDefn(fN, cfg.ogrSCP.OFTInteger)
            try:
                rL.CreateField(fd)
            # in case of errors
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                # close rasters
                rD = None
                return "No"
            fld = rL.GetLayerDefn().GetFieldIndex(fN)
            rRB = rD.GetRasterBand(1)
            # raster to polygon
            cfg.gdalSCP.Polygonize(rRB, rRB.GetMaskBand(), rL, fld)
            # close rasters and shapefile
            rRB = None
            rD = None
            dS = None
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " vector output performed")

    ##################################
    """ vector functions """

    ##################################

    # zip a directory
    def zipDirectoryInFile(self, zipPath, fileDirectory):
        try:
            zip = cfg.zipfileSCP.ZipFile(zipPath, 'w')
            for f in cfg.osSCP.listdir(fileDirectory):
                zip.write(fileDirectory + "/" + f)
            zip.close()
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))

    # create backup file
    def createBackupFile(self, filePath):
        try:
            cfg.shutilSCP.copy(filePath, filePath + "." + cfg.backupNm)
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))

    # create a polygon shapefile with OGR
    def createEmptyShapefile(self, crsWkt, outputVector):
        d = cfg.ogrSCP.GetDriverByName('ESRI Shapefile')
        dS = d.CreateDataSource(outputVector)
        # shapefile
        sR = cfg.osrSCP.SpatialReference()
        sR.ImportFromWkt(crsWkt)
        rL = dS.CreateLayer('NewLayer', sR, cfg.ogrSCP.wkbMultiPolygon)
        fN = cfg.emptyFN
        fd = cfg.ogrSCP.FieldDefn(fN, cfg.ogrSCP.OFTInteger)
        rL.CreateField(fd)
        rL = None
        dS = None

    # Get extent of a shapefile
    def getShapefileRectangleBox(self, layer):
        try:
            d = cfg.ogrSCP.GetDriverByName("ESRI Shapefile")
            dr = d.Open(layer.source(), 1)
            l = dr.GetLayer()
            e = l.GetExtent()
            minX = e[0]
            minY = e[2]
            maxX = e[1]
            maxY = e[3]
            centerX = (maxX + minX) / 2
            centerY = (maxY + minY) / 2
            width = maxX - minX
            heigth = maxY - minY
            l = None
            dr = None
            return centerX, centerY, width, heigth
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "roi bounding box: center " + str(r.center()) + " width: " + str(
                                      r.width()) + " height: " + str(r.height()))
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))

    # get ID by attributes
    def getIDByAttributes(self, layer, field, attribute):
        IDs = []
        fR = layer.getFeatures(
            QgsFeatureRequest().setFilterExpression('"' + str(field) + '" = \'' + str(attribute) + '\''))
        for f in fR:
            IDs.append(f.id())
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              " ID: " + str(IDs))
        return IDs

    # Get last feauture id
    def getLastFeatureID(self, layer):
        f = QgsFeature()
        for f in layer.getFeatures():
            ID = f.id()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              " ID: " + str(ID))
        return ID

    # Get a feature from a shapefile by feature ID
    def getFeaturebyID(self, layer, ID):
        f = QgsFeature()
        # feature request
        fR = QgsFeatureRequest().setFilterFid(ID)
        try:
            f = layer.getFeatures(fR)
            f = f.next()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "get feature " + str(ID) + " from shapefile: " + unicode(layer.name()))
            return f
        # if empty shapefile
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            return False

    # Get a feature box by feature ID
    def getFeatureRectangleBoxbyID(self, layer, ID):
        d = cfg.ogrSCP.GetDriverByName("ESRI Shapefile")
        dr = d.Open(layer.source(), 1)
        l = dr.GetLayer()
        f = l.GetFeature(ID)
        # bounding box rectangle
        e = f.GetGeometryRef().GetEnvelope()
        minX = e[0]
        minY = e[2]
        maxX = e[1]
        maxY = e[3]
        centerX = (maxX + minX) / 2
        centerY = (maxY + minY) / 2
        width = maxX - minX
        heigth = maxY - minY
        l = None
        dr = None
        return centerX, centerY, width, heigth
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "roi bounding box: center " + str(r.center()) + " width: " + str(
                                  r.width()) + " height: " + str(r.height()))
        try:
            pass
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            pass

    # Delete a feauture from a shapefile by its Id
    def deleteFeatureShapefile(self, layer, feautureIds):
        layer.startEditing()
        res = layer.dataProvider().deleteFeatures(feautureIds)
        layer.commitChanges()
        res2 = layer.dataProvider().createSpatialIndex()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "feauture deleted: " + unicode(layer) + " " + str(feautureIds))

    # Edit a feauture in a shapefile by its Id
    def editFeatureShapefile(self, layer, feautureId, fieldName, value):
        id = self.fieldID(layer, fieldName)
        layer.startEditing()
        res = layer.changeAttributeValue(feautureId, id, value)
        layer.commitChanges()
        res2 = layer.dataProvider().createSpatialIndex()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "feauture edited: " + unicode(layer) + " " + str(feautureId))

    ### Copy feature by ID to layer
    def copyFeatureToLayer(self, sourceLayer, ID, targetLayer):
        f = self.getFeaturebyID(sourceLayer, ID)
        # get geometry
        fG = f.geometry()
        f.setGeometry(fG)
        sF = targetLayer.pendingFields()
        f.initAttributes(sF.count())
        if f.geometry() is None:
            cfg.mx.msg6()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "feature geometry is none")
        else:
            # copy polygon to shapefile
            targetLayer.startEditing()
            targetLayer.addFeature(f)
            targetLayer.commitChanges()
            targetLayer.dataProvider().createSpatialIndex()
            targetLayer.updateExtents()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "feature copied")

    # merge polygons
    def mergePolygons(self, targetLayer, idList, attributeList):
        f = cfg.utls.getFeaturebyID(targetLayer, idList[0])
        sg = QgsGeometry(f.geometry())
        for i in idList:
            if i != idList[0]:
                f = cfg.utls.getFeaturebyID(targetLayer, i)
                g = QgsGeometry(f.geometry())
                g.convertToMultiType()
                sg.addPartGeometry(g)
        pr = targetLayer.dataProvider()
        targetLayer.startEditing()
        f.setGeometry(sg)
        f.setAttributes(attributeList)
        pr.addFeatures([f])
        targetLayer.commitChanges()
        targetLayer.updateExtents()
        return targetLayer

    # merge polygons to new layer
    def mergePolygonsToNewLayer(self, targetLayer, idList, attributeList):
        # create memory layer
        provider = targetLayer.dataProvider()
        fields = provider.fields()
        pCrs = cfg.utls.getCrs(targetLayer)
        mL = QgsVectorLayer("MultiPolygon?crs=" + str(pCrs.toWkt()), "memoryLayer", "memory")
        mL.setCrs(pCrs)
        pr = mL.dataProvider()
        for fld in fields:
            pr.addAttributes([fld])
        mL.updateFields()
        f = cfg.utls.getFeaturebyID(targetLayer, idList[0])
        sg = QgsGeometry(f.geometry())
        for i in idList:
            if i != idList[0]:
                f = cfg.utls.getFeaturebyID(targetLayer, i)
                g = QgsGeometry(f.geometry())
                g.convertToMultiType()
                sg.addPartGeometry(g)
        mL.startEditing()
        f.setGeometry(sg)
        f.setAttributes(attributeList)
        pr.addFeatures([f])
        mL.commitChanges()
        mL.updateExtents()
        return mL

    ### Delete a field from a shapefile by its name
    def deleteFieldShapefile(self, layerPath, fieldName):
        fds = self.fieldsShapefile(layerPath)
        s = cfg.ogrSCP.Open(layerPath, 1)
        l = s.GetLayer()
        i = fds.index(fieldName)
        l.DeleteField(i)
        s = None
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "deleted field: " + unicode(fieldName) + " for layer: " + unicode(l.name()))

    ### Find field ID by name
    def fieldID(self, layer, fieldName):
        try:
            fID = layer.fieldNameIndex(fieldName)
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  "ID: " + str(fID) + " for layer: " + unicode(layer.name()))
            return fID
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))

    ### Get field names of a shapefile
    def fieldsShapefile(self, layerPath):
        s = cfg.ogrSCP.Open(layerPath)
        l = s.GetLayer()
        lD = l.GetLayerDefn()
        fN = [lD.GetFieldDefn(i).GetName() for i in range(lD.GetFieldCount())]
        s = None
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "shapefile field " + unicode(layerPath))
        return fN

    # get field attribute list
    def getFieldAttributeList(self, layer, field):
        fID = self.fieldID(layer, field)
        f = QgsFeature()
        l = []
        for f in layer.getFeatures():
            a = f.attributes()[fID]
            l.append(a)
        x = list(set(l))
        return x

    # reproject shapefile
    def repojectShapefile(self, inputShapefilePath, inputEPSG, outputShapefilePath, outputEPSG):
        iD = cfg.ogrSCP.GetDriverByName('ESRI Shapefile')
        # spatial reference
        iSR = cfg.osrSCP.SpatialReference()
        iSR.ImportFromEPSG(inputEPSG)
        oSR = cfg.osrSCP.SpatialReference()
        oSR.ImportFromEPSG(outputEPSG)
        # Coordinate Transformation
        cT = cfg.osrSCP.CoordinateTransformation(iSR, oSR)
        # input shapefile
        iS = iD.Open(inputShapefilePath)
        iL = iS.GetLayer()
        # output shapefile
        oS = iD.CreateDataSource(outputShapefilePath)
        nm = cfg.osSCP.path.basename(outputShapefilePath)
        oL = oS.CreateLayer(str(nm), oSR, cfg.ogrSCP.wkbMultiPolygon)
        iLDefn = iL.GetLayerDefn()
        # fields
        for i in range(0, iLDefn.GetFieldCount()):
            fDefn = iLDefn.GetFieldDefn(i)
            oL.CreateField(fDefn)
        oLDefn = oL.GetLayerDefn()
        oLFcount = oLDefn.GetFieldCount()
        iF = iL.GetNextFeature()
        while iF:
            g = iF.GetGeometryRef()
            g.Transform(cT)
            oF = cfg.ogrSCP.Feature(oLDefn)
            oF.SetGeometry(g)
            for i in range(0, oLFcount):
                nmRef = oLDefn.GetFieldDefn(i).GetNameRef()
                field = iF.GetField(i)
                oF.SetField(nmRef, field)
            oL.CreateFeature(oF)
            oF.Destroy()
            iF.Destroy()
            iF = iL.GetNextFeature()
        iS.Destroy()
        oS.Destroy()

    ##################################
    """ raster color composite functions """

    ##################################

    # get items in combobox
    def getAllItemsInCombobox(self, combobox):
        it = [combobox.itemText(i) for i in range(combobox.count())]
        return it

    # set RGB Combobox
    def setComboboxItems(self, combobox, itemList):
        combobox.clear()
        for i in itemList:
            if len(i) > 0:
                combobox.addItem(i)

    # set RGB color composite
    def setRGBColorComposite(self):
        if cfg.rgb_combo.currentText() != "-":
            try:
                rgb = cfg.rgb_combo.currentText()
                check = self.createRGBColorComposite(rgb)
                if check == "Yes":
                    listA = cfg.utls.getAllItemsInCombobox(cfg.rgb_combo)
                    cfg.RGBList = listA
                    cfg.utls.writeProjectVariable("SCP_RGBList", str(cfg.RGBList))
                    cfg.RGBLT.RGBListTable(cfg.RGBList)
                    return "Yes"
                else:
                    int(check)
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))

    # create RGB color composite
    def createRGBColorComposite(self, colorComposite):
        if cfg.bndSetPresent == "Yes" and cfg.rstrNm == cfg.bndSetNm:
            # if bandset create temporary virtual raster
            tPMN = cfg.tmpVrtNm + ".vrt"
            if cfg.tmpVrt is None:
                try:
                    self.removeLayer(tPMN)
                except:
                    pass
                # date time for temp name
                dT = cfg.utls.getTime()
                tPMD = cfg.tmpDir + "/" + dT + tPMN
                vrtCheck = cfg.utls.createVirtualRaster(cfg.bndSetLst, tPMD)
                cfg.timeSCP.sleep(1)
                i = self.addRasterLayer(tPMD, tPMN)
                cfg.utls.setRasterColorComposite(i, 3, 2, 1)
                cfg.tmpVrt = i
            else:
                i = cfg.utls.selectLayerbyName(tPMN, "Yes")
            c = str(colorComposite).split(",")
            if len(c) == 1:
                c = str(colorComposite).split("-")
            if len(c) == 1:
                c = str(colorComposite).split(";")
            if len(c) == 1:
                c = str(colorComposite)
            if i is not None:
                b = len(cfg.bndSet)
                if int(c[0]) <= b and int(c[1]) <= b and int(c[2]) <= b:
                    cfg.utls.setRasterColorComposite(i, int(c[0]), int(c[1]), int(c[2]))
                    return "Yes"
                else:
                    return "No"
            else:
                cfg.tmpVrt = None
        else:
            c = str(colorComposite).split(",")
            if len(c) == 1:
                c = str(colorComposite).split("-")
            if len(c) == 1:
                c = str(colorComposite).split(";")
            if len(c) == 1:
                c = str(colorComposite)
            i = cfg.utls.selectLayerbyName(cfg.rstrNm, "Yes")
            if i is not None:
                b = len(cfg.bndSet)
                if int(c[0]) <= b and int(c[1]) <= b and int(c[2]) <= b:
                    self.setRasterColorComposite(i, int(c[0]), int(c[1]), int(c[2]))
                    return "Yes"
                else:
                    return "No"

    # set raster color composite
    def setRasterColorComposite(self, raster, RedBandNumber, GreenBandNumber, BlueBandNumber):
        raster.setDrawingStyle('MultiBandColor')
        raster.renderer().setRedBand(RedBandNumber)
        raster.renderer().setGreenBand(GreenBandNumber)
        raster.renderer().setBlueBand(BlueBandNumber)
        cfg.utls.setRasterContrastEnhancement(raster, cfg.defaultContrast)

    # set local cumulative cut stretch
    def setRasterCumulativeStretch(self):
        if cfg.bndSetPresent == "Yes" and cfg.rstrNm == cfg.bndSetNm:
            i = cfg.tmpVrt
        else:
            i = cfg.utls.selectLayerbyName(cfg.rstrNm, "Yes")
        cfg.utls.setRasterContrastEnhancement(i, cfg.cumulativeCutContrast)
        cfg.defaultContrast = cfg.cumulativeCutContrast

    # set local standard deviation stretch
    def setRasterStdDevStretch(self):
        if cfg.bndSetPresent == "Yes" and cfg.rstrNm == cfg.bndSetNm:
            i = cfg.tmpVrt
        else:
            i = cfg.utls.selectLayerbyName(cfg.rstrNm, "Yes")
        cfg.utls.setRasterContrastEnhancement(i, cfg.stdDevContrast)
        cfg.defaultContrast = cfg.stdDevContrast

    # set raster enhancement
    def setRasterContrastEnhancement(self, QGISraster, contrastType=cfg.cumulativeCutContrast):
        ext = cfg.cnvs.extent()
        tLPoint = QgsPoint(ext.xMinimum(), ext.yMaximum())
        lRPoint = QgsPoint(ext.xMaximum(), ext.yMinimum())
        point1 = tLPoint
        point2 = lRPoint
        # project extent
        iCrs = cfg.utls.getCrs(QGISraster)
        pCrs = cfg.utls.getQGISCrs()
        if iCrs is None:
            iCrs = pCrs
        # projection of input point from project's crs to raster's crs
        if pCrs != iCrs:
            try:
                point1 = cfg.utls.projectPointCoordinates(tLPoint, pCrs, iCrs)
                point2 = cfg.utls.projectPointCoordinates(lRPoint, pCrs, iCrs)
                if point1 is False:
                    point1 = tLPoint
                    point2 = lRPoint
            # Error latitude or longitude exceeded limits
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                point1 = tLPoint
                point2 = lRPoint
        if contrastType == cfg.stdDevContrast:
            contrast = QgsRaster.ContrastEnhancementStdDev
        elif contrastType == cfg.cumulativeCutContrast:
            contrast = QgsRaster.ContrastEnhancementCumulativeCut
        try:
            QGISraster.setContrastEnhancement(QgsContrastEnhancement.StretchToMinimumMaximum, contrast,
                                              QgsRectangle(point1, point2))
            QGISraster.triggerRepaint()
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))

    ##################################
    """ table functions """

    ##################################

    # delete all items in a table
    def clearTable(self, table):
        table.clearContents()
        for i in range(0, table.rowCount()):
            table.removeRow(0)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode())

    # set all items to state 0 or 2
    def allItemsSetState(self, tableWidget, value):
        tW = tableWidget
        tW.blockSignals(True)
        r = tW.rowCount()
        for b in range(0, r):
            if cfg.actionCheck == "Yes":
                tW.item(b, 0).setCheckState(value)
            # cfg.uiUtls.updateBar((b+1) * 100 / r)
            else:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(), " cancelled")
                tW.blockSignals(False)
        tW.blockSignals(False)

    # highlight row in table
    def highlightRowInTable(self, table, value, columnIndex):
        tW = table
        v = tW.rowCount()
        for x in range(0, v):
            id = tW.item(x, columnIndex).text()
            if str(id) == str(value):
                return x

    # remove rows from table
    def removeRowsFromTable(self, table):
        # ask for confirm
        a = cfg.utls.questionBox("Remove rows", "Are you sure you want to remove highlighted rows from the table?")
        if a == "Yes":
            tW = table
            c = tW.rowCount()
            # list of item to remove
            iR = []
            for i in tW.selectedIndexes():
                iR.append(i.row())
            v = list(set(iR))
            # remove items
            for i in reversed(range(0, len(v))):
                tW.removeRow(v[i])
            c = tW.rowCount()
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " row removed")

    # select rows in table
    def selectRowsInTable(self, table, rowList):
        c = table.columnCount()
        for row in rowList:
            table.setRangeSelected(cfg.QtGuiSCP.QTableWidgetSelectionRange(row, 0, row, c - 1), True)

    # add item to table
    def addTableItem(self, table, item, row, column, enabled="Yes", color=None, checkboxState=None, tooltip=None):
        itMID = cfg.QtGuiSCP.QTableWidgetItem()
        if checkboxState != None:
            itMID.setCheckState(checkboxState)
        if enabled == "No":
            itMID.setFlags(cfg.QtSCP.ItemIsEnabled)
        itMID.setData(cfg.QtSCP.DisplayRole, item)
        table.setItem(row, column, itMID)
        if color is not None:
            table.item(row, column).setBackground(color)
        if tooltip is not None:
            itMID.setToolTip(tooltip)

    # set table item
    def setTableItem(self, table, row, column, value):
        table.item(row, column).setText(value)

    # insert table row
    def insertTableRow(self, table, row, height=None):
        table.insertRow(row)
        if height is not None:
            table.setRowHeight(row, height)

    # insert table column
    def insertTableColumn(self, table, column, name, width=None, hide="No"):
        table.insertColumn(column)
        table.setHorizontalHeaderItem(column, cfg.QtGuiSCP.QTableWidgetItem(name))
        if width is not None:
            table.setColumnWidth(column, width)
        if hide == "Yes":
            table.hideColumn(column)

    # sort table column
    def sortTableColumn(self, table, column, ascending=False):
        table.sortItems(column, ascending)

    # set table column width
    def setColumnWidthList(self, table, list):
        for c in list:
            table.setColumnWidth(c[0], c[1])

    ##################################
    """ tab selection functions """

    ##################################

    ### tab 0
    # select band set tab
    def selectTabDownloadImages(self, secondTab=None):
        cfg.dlg.close()
        cfg.ui.toolButton_plugin.setCurrentIndex(0)
        if secondTab is not None:
            cfg.ui.tab_download.setCurrentIndex(secondTab)
        # show the dialog
        cfg.dlg.show()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "tab selected")

    # select pre processing tab
    def downloadImagesTab(self):
        cfg.utls.selectTabDownloadImages()

    # download Landsat tab
    def downloadLandast8Tab(self):
        cfg.utls.selectTabDownloadImages(0)

    # download Sentinel tab
    def downloadSentinelTab(self):
        cfg.utls.selectTabDownloadImages(1)

    # download ASTER tab
    def downloadASTERTab(self):
        cfg.utls.selectTabDownloadImages(2)

    # download MODIS tab
    def downloadMODISTab(self):
        cfg.utls.selectTabDownloadImages(3)

    ### tab 1
    # select tab 0 from Main Interface
    def selectTab0MainInterface(self, secondTab=None):
        cfg.dlg.close()
        cfg.ui.toolButton_plugin.setCurrentIndex(1)
        if secondTab is not None:
            cfg.ui.tabWidget.setCurrentIndex(secondTab)
        # show the dialog
        cfg.dlg.show()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "tab selected")

    # select roi tools tab
    def roiToolsTab(self):
        cfg.utls.selectTab0MainInterface()

    # select multiple roi tab
    def mutlipleROITab(self):
        cfg.utls.selectTab0MainInterface(0)

    # import library signatures tab
    def importLibraryTab(self):
        cfg.utls.selectTab0MainInterface(1)

    # export library signatures tab
    def exportLibraryTab(self):
        cfg.utls.selectTab0MainInterface(2)

    # algorithm weight tab
    def algorithmWeighTab(self):
        cfg.utls.selectTab0MainInterface(3)

    # signature threshold tab
    def algorithmThresholdTab(self):
        cfg.utls.selectTab0MainInterface(4)

    # LCS threshold tab
    def LCSThresholdTab(self):
        cfg.utls.selectTab0MainInterface(5)

    # RGB List tab
    def RGBListTab(self):
        cfg.utls.selectTab0MainInterface(6)

    ### tab 2
    # select tab 2 from Main Interface
    def selectTab1MainInterface(self, secondTab=None):
        cfg.dlg.close()
        cfg.ui.toolButton_plugin.setCurrentIndex(2)
        if secondTab is not None:
            cfg.ui.tabWidget_preprocessing.setCurrentIndex(secondTab)
        # show the dialog
        cfg.dlg.show()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "tab selected")

    # select pre processing tab
    def preProcessingTab(self):
        cfg.utls.selectTab1MainInterface()

    # select Landsat tab
    def landsatTab(self):
        cfg.utls.selectTab1MainInterface(0)

    # select Sentinel-2 tab
    def sentinel2Tab(self):
        cfg.utls.selectTab1MainInterface(1)

    # select ASTER tab
    def asterTab(self):
        cfg.utls.selectTab1MainInterface(2)

    # select MODIS tab
    def modisTab(self):
        cfg.utls.selectTab1MainInterface(3)

    # select Clip multiple rasters tab
    def clipMultipleRastersTab(self):
        cfg.utls.selectTab1MainInterface(4)

    # select Split raster bands tab
    def splitrasterbandsTab(self):
        cfg.utls.selectTab1MainInterface(5)

    # select Stack raster bands tab
    def stackrasterbandsTab(self):
        cfg.utls.selectTab1MainInterface(6)

    # PCA tab
    def PCATab(self):
        cfg.utls.selectTab1MainInterface(7)

    # Vector to raster tab
    def vectorToRasterTab(self):
        cfg.utls.selectTab1MainInterface(8)

    ### tab 3
    # select tab 3 from Main Interface
    def selectTab2MainInterface(self, secondTab=None):
        cfg.dlg.close()
        cfg.ui.toolButton_plugin.setCurrentIndex(3)
        if secondTab is not None:
            cfg.ui.tabWidget_2.setCurrentIndex(secondTab)
        # show the dialog
        cfg.dlg.show()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "tab selected")

    # select post processing tab
    def postProcessingTab(self):
        cfg.utls.selectTab2MainInterface()

    # select Accuracy tab
    def accuracyTab(self):
        cfg.utls.selectTab2MainInterface(0)

    # select Land cover change tab
    def landCoverChangeTab(self):
        cfg.utls.selectTab2MainInterface(1)

    # select Classification report tab
    def classificationReportTab(self):
        cfg.utls.selectTab2MainInterface(2)

    # select Cross classification report tab
    def crossClassificationTab(self):
        cfg.utls.selectTab2MainInterface(3)

    # select Classification report tab
    def classToVectorTab(self):
        cfg.utls.selectTab2MainInterface(4)

    # select Reclassification tab
    def reclassificationTab(self):
        cfg.utls.selectTab2MainInterface(5)

    # select Edit raster tab
    def editRasterTab(self):
        cfg.utls.selectTab2MainInterface(6)

    # select Classification sieve tab
    def classificationSieveTab(self):
        cfg.utls.selectTab2MainInterface(7)

    # select Classification erosion tab
    def classificationErosionTab(self):
        cfg.utls.selectTab2MainInterface(8)

    # select Classification dilation tab
    def classificationDilationTab(self):
        cfg.utls.selectTab2MainInterface(9)

    ### tab 4
    # select Band calc tab
    def bandCalcTab(self):
        cfg.dlg.close()
        cfg.ui.toolButton_plugin.setCurrentIndex(4)
        # show the dialog
        cfg.dlg.show()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "tab selected")

    ### tab 5
    # select band set tab
    def bandSetTab(self):
        cfg.dlg.close()
        cfg.ui.toolButton_plugin.setCurrentIndex(5)
        # reload raster bands in checklist
        cfg.bst.rasterBandName()
        # show the dialog
        cfg.dlg.show()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "tab selected")

    ### tab 6
    # select tab 6 from Main Interface
    def selectTabBatch(self, secondTab=None):
        cfg.dlg.close()
        cfg.ui.toolButton_plugin.setCurrentIndex(6)
        if secondTab is not None:
            cfg.ui.toolBox.setCurrentIndex(secondTab)
        # show the dialog
        cfg.dlg.show()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "tab selected")

    # select batch tab
    def batchTab(self):
        cfg.utls.selectTabBatch()

    ### tab 7
    # select tab 7 from Main Interface
    def selectTabSettings(self, secondTab=None):
        cfg.dlg.close()
        cfg.ui.toolButton_plugin.setCurrentIndex(7)
        if secondTab is not None:
            cfg.ui.toolBox.setCurrentIndex(secondTab)
        # show the dialog
        cfg.dlg.show()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "tab selected")

    # select settings tab
    def settingsTab(self):
        cfg.utls.selectTabSettings()

    # select settings interface tab
    def settingsInterfaceTab(self):
        cfg.utls.selectTabSettings(0)

    # select settings Processing tab
    def settingsProcessingTab(self):
        cfg.utls.selectTabSettings(1)

    # select settings debug tab
    def settingsDebugTab(self):
        cfg.utls.selectTabSettings(2)

    ### tab 8
    # select bout tab
    def aboutTab(self):
        cfg.dlg.close()
        cfg.ui.toolButton_plugin.setCurrentIndex(8)
        # show the dialog
        cfg.dlg.show()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "tab selected")

    # spectral singature plot tab
    def spectralPlotTab(self):
        cfg.spectralplotdlg.close()
        cfg.spectralplotdlg.show()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "tab selected")

    # select tab in singature plot tab
    def selectSpectralPlotTabSettings(self, secondTab=None):
        if secondTab is not None:
            cfg.uisp.toolBox.setCurrentIndex(secondTab)
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "tab selected")

    # scatter plot tab
    def scatterPlotTab(self):
        cfg.scatterplotdlg.close()
        cfg.scatterplotdlg.show()
        # logger
        cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                              "tab selected")

    ##################################
    """ sound functions """

    ##################################

    # beep sound
    def beepSound(self, frequency, duration):
        if cfg.sysSCP.platform.startswith('win'):
            winsound.Beep(frequency, int(duration * 1000))
        elif cfg.sysSCP.platform.startswith('linux'):
            cfg.osSCP.system(
                "play --no-show-progress --null --channels 1 synth " + str(duration) + " sine " + str(frequency))
        else:
            cfg.sysSCP.stdout.write('\a')
            cfg.sysSCP.stdout.flush()

    # finish sound
    def finishSound(self):
        try:
            self.beepSound(800, 0.2)
            self.beepSound(600, 0.3)
            self.beepSound(700, 0.5)
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))

    ##################################
    """ clean functions """

    ##################################

    # clean old temporary directory
    def cleanOldTempDirectory(self):
        t = cfg.datetimeSCP.datetime.now()
        inputDir = unicode(cfg.QDirSCP.tempPath() + "/" + cfg.tempDirName)
        try:
            for name in cfg.osSCP.listdir(inputDir):
                dStr = cfg.datetimeSCP.datetime.strptime(name, "%Y%m%d_%H%M%S%f")
                diff = (t - dStr)
                if diff.days > 3:
                    cfg.shutilSCP.rmtree(inputDir + "/" + name, True)
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + (cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))

    ##################################
    """ general functions """

    ##################################

    # 32bit or 64bit
    def findSystemSpecs(self):
        if cfg.sysSCP.maxsize > 2 ** 32:
            cfg.sysSCP64bit = "Yes"
        else:
            cfg.sysSCP64bit = "No"
        # file system encoding
        cfg.fSEnc = cfg.sysSCP.getfilesystemencoding()
        # system information
        cfg.sysSCPNm = cfg.platformSCP.system()
        # QGIS version
        cfg.QGISVer = cfg.qgisCoreSCP.QGis.QGIS_VERSION_INT

    # read variables from project instance
    def readVariables(self):
        # read qml path from project instance
        cfg.qmlFl = cfg.utls.readProjectVariable("qmlfile", "")
        # read signature checkbox from project instance
        cfg.sigClcCheck = cfg.utls.readProjectVariable("calculateSignature", "Yes")
        # read rapid ROI checkbox from project instance
        cfg.rpdROICheck = cfg.utls.readProjectVariable("rapidROI", "No")
        cfg.vegIndexCheck = cfg.utls.readProjectVariable("vegetationIndex", "Yes")
        cfg.ROIband = cfg.utls.readProjectVariable("rapidROIBand", str(cfg.ROIband))
        cfg.algName = cfg.utls.readProjectVariable("ClassAlgorithm", unicode(cfg.algName))
        cfg.prvwSz = cfg.utls.readProjectVariable("previewSize", str(cfg.prvwSz))
        cfg.minROISz = cfg.utls.readProjectVariable("minROISize", str(cfg.minROISz))
        cfg.maxROIWdth = cfg.utls.readProjectVariable("maxROIWidth", str(cfg.maxROIWdth))
        cfg.rngRad = cfg.utls.readProjectVariable("rangeRadius", str(cfg.rngRad))
        cfg.ROIID = cfg.utls.readProjectVariable("ROIIDField", str(cfg.ROIID))
        cfg.ROIInfo = cfg.utls.readProjectVariable("ROIInfoField", str(cfg.ROIInfo))
        cfg.ROIMacroClassInfo = cfg.utls.readProjectVariable("ROIMacroclassInfoField", str(cfg.ROIMacroClassInfo))
        cfg.customExpression = cfg.utls.readProjectVariable("customExpression", str(cfg.customExpression))
        cfg.ROIMacroID = cfg.utls.readProjectVariable("ROIMacroIDField", str(cfg.ROIMacroID))
        # mask option
        cfg.mskFlPath = cfg.utls.readProjectVariable("maskFilePath", unicode(cfg.mskFlPath))
        cfg.mskFlState = cfg.utls.readProjectVariable("maskFileState", str(cfg.mskFlState))
        # cfg.classD.setMaskCheckbox()
        # band set
        bSP = cfg.utls.readProjectVariable("bandSet", "")
        bSW = cfg.utls.readProjectVariable("bndSetWvLn", "")
        bSM = cfg.utls.readProjectVariable("bndSetMultF", "")
        bSA = cfg.utls.readProjectVariable("bndSetAddF", "")
        un = cfg.utls.readProjectVariable("bndSetUnit", cfg.noUnit)
        bSU = cfg.bst.unitNameConversion(un, "Yes")
        cfg.bndSetPresent = cfg.utls.readProjectVariable("bandSetPresent", "No")
        if cfg.bndSetPresent == "Yes":
            # add band set to table
            bs = eval(bSP)
            wlg = eval(bSW)
            try:
                multF = eval(bSM)
                addF = eval(bSA)
            except:
                pass
            t = cfg.ui.tableWidget
            it = 0
            cfg.BandTabEdited = "No"
            t.blockSignals(True)
            for x in sorted(wlg):
                b = wlg.index(x)
                # add item to table
                c = t.rowCount()
                # name of item of list
                iN = bs[it]
                # add list items to table
                t.setRowCount(c + 1)
                cfg.utls.addTableItem(t, iN, c, 0)
                cfg.utls.addTableItem(t, str(wlg[b]), c, 1)
                try:
                    cfg.utls.addTableItem(t, str(multF[it]), c, 2)
                except:
                    cfg.utls.addTableItem(t, "1", c, 2)
                try:
                    cfg.utls.addTableItem(t, str(addF[it]), c, 3)
                except:
                    cfg.utls.addTableItem(t, "0", c, 3)
                it = it + 1
            # load project unit in combo
            idU = cfg.ui.unit_combo.findText(bSU)
            cfg.ui.unit_combo.setCurrentIndex(idU)
            t.blockSignals(False)
            cfg.bst.readBandSet("Yes")
            cfg.BandTabEdited = "Yes"
        # read RGB list
        rgbList = cfg.utls.readProjectVariable("SCP_RGBList", str(cfg.RGBList))
        cfg.RGBList = eval(rgbList)
        try:
            cfg.utls.setComboboxItems(cfg.rgb_combo, cfg.RGBList)
        except:
            pass

    # get temporary directory
    def getTempDirectory(self):
        # temp directory
        if cfg.tmpDir is None:
            tmpDir0 = unicode(cfg.QDirSCP.tempPath() + "/" + cfg.tempDirName)
        else:
            tmpDir0 = cfg.tmpDir
        if not cfg.QDirSCP(tmpDir0).exists():
            try:
                cfg.osSCP.makedirs(tmpDir0)
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                cfg.sets.setQGISRegSetting(cfg.regTmpDir, tmpDir0)
                cfg.mx.msgWar17()
                if not cfg.QDirSCP(tmpDir0).exists():
                    cfg.osSCP.makedirs(tmpDir0)
        try:
            dT = cfg.utls.getTime()
            cfg.osSCP.makedirs(tmpDir0 + "/" + dT)
            cfg.tmpDir = unicode(tmpDir0 + "/" + dT)
        except Exception, err:
            # logger
            cfg.utls.logCondition(str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                                  " ERROR exception: " + str(err))
            cfg.mx.msgWar17()
            if not cfg.QDirSCP(cfg.tmpDir).exists():
                cfg.osSCP.makedirs(cfg.tmpDir)
        return tmpDir0

    # check and create directory
    def makeDirectory(self, path):
        if not cfg.QDirSCP(path).exists():
            try:
                cfg.osSCP.makedirs(path)
            except Exception, err:
                # logger
                cfg.utls.logCondition(
                    str(__name__) + "-" + str(cfg.inspectSCP.stack()[0][3]) + " " + cfg.utls.lineOfCode(),
                    " ERROR exception: " + str(err))
                return None
        return path

    # calculate md5
    def md5Calc(self, filePath):
        block = 2 ** 16
        md5 = cfg.hashlibSCP.md5()
        with open(filePath, 'rb') as inFile:
            fileBlock = inFile.read(block)
            while len(fileBlock) > 0:
                md5.update(fileBlock)
                fileBlock = inFile.read(block)
        return md5.digest()

    #############accuary_access#######################################
    def start_access(self):
        cfg.uiUtls.addProgressBar()
        cfg.uiUtls.updateBar(1)
        # get the  layer
        ref_layer = self.layerFromComboBox(cfg.uidc.referenceComboBox)
        comp_layer = self.layerFromComboBox(cfg.uidc.comparisonComboBox)
        # get the file name that's in the filename line edit (set in showFileSelectDialog)
        filename = str(cfg.uidc.outFileLineEdit.text())
        cfg.uiUtls.updateBar(2)
        # See if OK was pressed
        if ref_layer.type() == QgsMapLayer.RasterLayer and comp_layer.type() == QgsMapLayer.RasterLayer:

            # Define a counter
            cont = 1
            # While the counter is lower than 2, then repeats the structure of code
            while cont <= 2:
                # get some RasterDS objects (defined in raster_handling.py) so we can do
                # gdal stuff.
                if cont == 1:
                    ref_ds = RasterDS(ref_layer)
                elif cont == 2:
                    ref_ds = RasterDS(comp_layer)
                comp_ds = RasterDS(comp_layer)
                # get 2d arrays from datasets. I'm currently assuming the extents are
                # the same. I'll need to change that later. I should also check the shape
                # of the band array.
                ref_arr = ref_ds.band_array[0]
                comp_arr = comp_ds.band_array[0]
                # I only want to compare non-zero values so I need the indexes of nonzeros
                idx = ref_arr.nonzero()
                # get the error matrix
                em = error_matrix(ref_arr[idx], comp_arr[idx])

                if cont == 1:
                    filename1 = filename + "_temp_matrix.csv"
                    em.save_csv(filename1)
                elif cont == 2:
                    filename2 = filename + "_temp_area.csv"
                    em.save_csv(filename2)
                # Increments the counter by ones
                cont += 1
            # Open the files obtained the Raw confusion matrix and the surfaces matrix
            csv_em = open(filename1)
            csv_sup = open(filename2)
            csv_matrix = open(filename + ".csv", 'wb')
            writer_csv = csv.writer(csv_matrix)

            # Set a list to save the elements for the raw matrix
            matrix_error = []
            for rows_em in csv_em:
                row_em = rows_em.rstrip('\n')
                cell_mat = row_em.split(",")
                matrix_error.append(cell_mat)

            # Set a list to save the elements for the matrix of surfaces
            lis = []
            for rows_sup in csv_sup:
                row_sup = rows_sup.rstrip('\n')
                lis_sup = row_sup.split(",")
                lis.append(lis_sup)
            sum_surfaces = sum(np.array(lis, dtype=int))
            # Set array of the length of total of classes
            adjusted_matrix = np.zeros((len(lis), len(lis)))

            # Set array of type float
            m_e = np.array(matrix_error, dtype=float)
            l_s = np.array(lis, dtype=float)

            # Set the size of the column
            col = (np.arange(len(lis)) + 1).reshape((len(lis), 1))

            # set the title
            writer_csv.writerow([str(ref_layer.name()) + " (Reference Map) versus " + str(
                comp_layer.name()) + " (Map Under Assessment)"])
            writer_csv.writerows([""])
            writer_csv.writerow(["Raw Matrix"])
            writer_csv.writerow(np.append("Map", np.arange(len(lis)) + 1))
            writer_csv.writerows(np.c_[col, matrix_error])
            writer_csv.writerows([""])


            # Set the adjust confusion matrix
            sup_tot = np.sum(l_s)
            for r_i in range(len(lis)):
                for r_j in range(len(lis)):
                    per_sup = np.sum(l_s[r_i]) / sup_tot
                    adjusted_matrix[r_i][r_j] = (m_e[r_i][r_j] * per_sup) / np.sum(m_e[r_i])

            # Create a matrix for estimate the value, this will used for estimate the half-width CI of the user accuracy
            diagonal = np.diagonal(adjusted_matrix)
            mat_comp_1 = np.zeros((len(lis), len(lis)))
            for x_i in range(len(lis)):
                for x_j in range(len(lis)):
                    per_sup2 = np.sum(l_s[x_i]) / sup_tot
                    mat_comp_1[x_i][x_j] = adjusted_matrix[x_i][x_j] * (per_sup2 - adjusted_matrix[x_i][x_j]) / np.sum(
                        m_e[x_i])
            dia_comp_1 = np.diagonal(mat_comp_1)

            user_accuracy = []
            prod_accuracy = []
            hci_user = []
            hci_prod = []
            for u_i in range(len(lis)):
                # Estimates user accuracy
                user_cal = (diagonal[u_i] / np.sum(adjusted_matrix[u_i]))
                user_accuracy.append(user_cal)

                # Estimates producer accuracy
                prod_cal = (diagonal[u_i] / sum(adjusted_matrix, axis=0)[u_i])
                prod_accuracy.append(prod_cal)

                # Estimates half CI user
                hci_u = 1.96 * math.sqrt((diagonal[u_i] * (np.sum(adjusted_matrix[u_i]) - diagonal[u_i]) / (
                        np.sum(adjusted_matrix[u_i]) * np.sum(adjusted_matrix[u_i]) * np.sum(m_e[u_i]))))
                hci_user.append(hci_u)

                # Estimates half CI producer
                comp1 = diagonal[u_i] * (np.sum(adjusted_matrix, axis=0)[u_i]) ** -4
                comp2 = diagonal[u_i] * (sum(mat_comp_1, axis=0)[u_i] - dia_comp_1[u_i])
                comp3 = (np.sum(adjusted_matrix[u_i]) - diagonal[u_i]) * (
                        np.sum(adjusted_matrix, axis=0)[u_i] - diagonal[u_i]) ** 2 / sum(m_e, axis=1)[u_i]

                hci_p = 1.96 * math.sqrt(comp1 * (comp2 + comp3))
                hci_prod.append(hci_p)

                comp1 = diagonal[u_i] * (sum(mat_comp_1, axis=0)[u_i] - dia_comp_1[u_i])
                comp2 = (((np.sum(adjusted_matrix[u_i]) - diagonal[u_i])) * (
                        np.sum(adjusted_matrix, axis=0)[u_i] - diagonal[u_i]) ** 2) / sum(m_e, axis=1)[u_i]
                hci_p = 1.96 * math.sqrt(
                    (diagonal[u_i] * (np.sum(adjusted_matrix, axis=0)[u_i]) ** -4) * (comp1 + comp2))
                hci_prod.append(hci_p)

            ci_low_acc = []
            ci_upp_acc = []

            ci_low_prod = []
            ci_upp_prod = []

            # Estimates CI Lower Bound and CI Upper Bound for user and producer
            for low_up in range(len(lis)):
                cla_b = user_accuracy[low_up] - hci_user[low_up]
                cla = user_accuracy[low_up] + hci_user[low_up]

                clp_b = prod_accuracy[low_up] - hci_prod[low_up]
                clp = prod_accuracy[low_up] + hci_prod[low_up]
                if cla_b < 0: cla_b = 0
                if cla > 1: cla = 1

                if clp_b < 0: clp_b = 0
                if clp > 1: clp = 1

                ci_low_acc.append(cla_b)
                ci_upp_acc.append(cla)
                ci_low_prod.append(clp_b)
                ci_upp_prod.append(clp)

            adjusted_matrix_f = np.c_[col, adjusted_matrix]

            # Estimates HCI Overall accuracy
            hci_over_comp1 = np.array(diagonal, dtype=float) * (
                    (np.sum(l_s, axis=1, dtype=float) / np.sum(l_s, dtype=float)) - np.array(diagonal,
                                                                                             dtype=float)) / np.sum(
                m_e, axis=1, dtype=int)
            hci_overall = 1.96 * math.sqrt(sum(hci_over_comp1))

            # Save all indices in the csv file

            writer_csv.writerow(["Adjusted Confusion Matrix (Card Correction)"])
            writer_csv.writerow(np.append("Map", np.arange(len(lis)) + 1))
            writer_csv.writerows(adjusted_matrix_f)
            writer_csv.writerows([""])
            writer_csv.writerows([""])
            writer_csv.writerow(np.append("Adjust Overall accuracy", [sum(diagonal)]))
            writer_csv.writerow(np.append("HCI Overall accuracy", [hci_overall]))

            writer_csv.writerows([""])
            writer_csv.writerow(np.append("Category", np.arange(len(lis)) + 1))
            writer_csv.writerow(np.append("User Accuracy", user_accuracy))
            writer_csv.writerow(np.append("Half CI", hci_user))
            writer_csv.writerow(np.append("CI Lower Bound", ci_low_acc))
            writer_csv.writerow(np.append("CI Upper Bound", ci_upp_acc))
            writer_csv.writerow(np.append("Prod Accuracy", prod_accuracy))
            writer_csv.writerow(np.append("Half CI", hci_prod))
            writer_csv.writerow(np.append("CI Lower Bound", ci_low_prod))
            writer_csv.writerow(np.append("CI Upper Bound", ci_upp_prod))

            # Calculate proportion area and write in csv file
            writer_csv.writerow(np.append("Error Adjusted-Proportion", (np.sum(adjusted_matrix, axis=0))))

            # Estiamte the Half-Widht confidence interval for the estimated area proportion

            transpose_sum = np.array(np.transpose(np.matrix(np.sum(m_e, axis=1, dtype=int))))
            mul_diag_mat = np.divide(adjusted_matrix * transpose_sum, m_e)
            hci_adjusted_area = (mul_diag_mat ** 2) * ((m_e / transpose_sum) * (1 - m_e / transpose_sum)) / (
                    transpose_sum - 1)

            # Replace nan values with zeros
            nans = np.where(hci_adjusted_area == np.nan)
            # nans = isnan(hci_adjusted_area)
            hci_adjusted_area[nans] = 0

            half_ci_area = np.array(np.sum(hci_adjusted_area, axis=0))
            half_ci_class = []

            for hci_area in half_ci_area:
                elemen_hci = 1.96 * float(hci_area) ** .5
                half_ci_class.append(format(elemen_hci, '.10f'))

            # Indices Half CI, CI Lower and Upper Bound for the proportion area
            ci_low_area = np.sum(adjusted_matrix, axis=0) - np.array(half_ci_class, dtype=float)
            ci_up_area = np.sum(adjusted_matrix, axis=0) + np.array(half_ci_class, dtype=float)

            # Round CI Lower value if is less than zero or CI Upper value if is greater than one
            for i_area in range(len(ci_low_area)):
                if ci_low_area[i_area] < 0: ci_low_area[i_area] = 0
                if ci_up_area[i_area] > 1: ci_up_area[i_area] = 1

            #  Stored the Half CI and CI Lower and Upper indices
            writer_csv.writerow(np.append("Half CI", half_ci_class))
            writer_csv.writerow(np.append("CI Lower Bound", ci_low_area))
            writer_csv.writerow(np.append("CI Upper Bound", ci_up_area))
            # Close all files CSV that were opened
            csv_matrix.close()
            csv_em.close()
            csv_sup.close()
            os.remove(filename1)
            os.remove(filename2)

            # Show a finished message
            QMessageBox.information(cfg.uidc, QCoreApplication.translate('AccurAssess', "Finished"),
                                    QCoreApplication.translate('AccurAssess', "Operation completed successfully"))
        elif ref_layer.type() == QgsMapLayer.VectorLayer and comp_layer.type() == QgsMapLayer.VectorLayer:
            # Creates a CSV file to save all indices
            csv_matrix = open(filename + ".csv", 'wb')
            writer_csv = csv.writer(csv_matrix)
            # Calculates the area from each features in comparison layer
            areabypolygon = []
            clave_area = []
            for f in comp_layer.getFeatures():
                clave_area.append(f[0])
                area_polygon = f.geometry().area()
                # 添加当前图层当前要素的类型和面积
                areabypolygon.append(f[0])
                areabypolygon.append(area_polygon)

            # Make a intersect feature
            split_filename = filename.split(".")
            overlayAnalyzer = QgsOverlayAnalyzer()
            intersect = overlayAnalyzer.intersection(ref_layer, comp_layer, filename + ".shp")

            # Add layer to the table of contents
            layer_inter = QgsVectorLayer(filename + ".shp", "intersect", "ogr")
            add_inter = QgsMapLayerRegistry.instance().addMapLayer(layer_inter)

            # This stored in separate lists, each value in the intersect layer
            # This stored in separate lists, each value in the layer
            clave1 = []
            clave2 = []
            clave3 = []
            area_values = []
            for reg in add_inter.getFeatures():

                try:
                    a = int(reg[0])
                    b = int(reg[1])
                    clave1.append(str(a) + "_" + str(b))
                    clave2.append(b)
                    clave3.append(a)
                    area_values.append(str(b))
                    # QMessageBox.information(cfg.uidc, str(a),str(b))
                    # area_values.append(reg[2])
                except:
                    pass
            # 相交要素的所有组合类型，和类名
            unique_value = list(set(clave1))
            unique_class = list(set(clave3))
            # Set the size of the matrix
            matrix = np.zeros((len(unique_class), len(unique_class)))
            # QMessageBox.information(cfg.uidc, str(unique_class), str(unique_class))
            # 创建数组存放每种类型的面积
            # sum_areas = []
            # for l in range(len(lista)):
            #     sum_areas.append(lista[l][1])
            sum_areas = []
            suma_shp = 0
            c = 0
            d = 1
            # 外循环为当前验证图层类型数
            for m in range(len(unique_class)):
                # 内循环为当前图层元素数的2倍,areabypolygon中保存的是当前待评估图层的所有要素类型和面积
                for n in range(len(areabypolygon)):
                    try:
                        # 当前图层当前要素的类型
                        val_area = int(areabypolygon[c])
                        # 判断该要素类型是否和当前类型相等
                        if val_area == unique_class[m]:
                            suma_shp = suma_shp + float(areabypolygon[d])
                    except:
                        pass
                    c = c + 2
                    d = d + 2
                c = 0
                d = 1
                # 统计当前待评估图层中每种交叉类型的总面积
                sum_areas.append(suma_shp)
                suma_shp = 0

            # Estimates the proportion area by class
            # 计算当前图层每种待评估类型面积占总面积的比例
            # proportion_area = np.array(sum_areas) / np.sum(sum_areas)
            # Estimates the total points by class
            for x in range(len(unique_value)):
                # clave1中存储的为相交图层中不同的类型相交组合(字符串格式)
                # 计算相交图层中每种组合出现的次数
                tot_point_cve = clave1.count(unique_value[x])
                # 分离组合两边的类型
                split_unique = unique_value[x].split("_")
                x_id = np.where(np.asarray(unique_class) == int(split_unique[1]))[0]
                y_id = np.where(np.asarray(unique_class) == int(split_unique[0]))[0]
                # 把每种组合出现的次数记录在矩阵当中
                matrix[x_id, y_id] = tot_point_cve
            # # 把相交图层的所有组合方式的出现次数记录在numpy数组中
            # matrix_points = np.array(matrix)
            # 备份该矩阵
            adjusted_matrix = matrix

            # Set the title and stores the raw matrix
            writer_csv.writerow([u"verify_sample:" + str(ref_layer.name())])
            writer_csv.writerows([""])
            writer_csv.writerow([u"result_for_access:" + str(comp_layer.name())])
            writer_csv.writerows([""])
            writer_csv.writerow([u"raw matrix"])
            writer_csv.writerow(np.append(np.append(" ", unique_class),u"UA"))


            #计算真实的总体精度
            raw_sum = np.sum(matrix)
            raw_diagonal = np.diagonal(matrix)
            sum_raw_diagonal = np.sum(raw_diagonal)
            raw_OverAllAccuracy = np.round(float(sum_raw_diagonal)/raw_sum,4)

            # Makes lists to save user accuracy, producer accuracy, hci user and hci producer
            user_accuracy = []
            prod_accuracy = []
            for indice in range(len(unique_class)):
                # Calculate user accuracy
                try:
                    # QMessageBox.information(cfg.uidc, u'警告', str(np.sum(matrix[indice])))
                    # QMessageBox.information(cfg.uidc, u'警告', str(float(raw_diagonal[indice])))
                    # QMessageBox.information(cfg.uidc, u'成功', str(float(raw_diagonal[indice])/ np.sum(matrix[indice])))
                    if  np.sum(matrix[indice]) != 0 and (float(raw_diagonal[indice])/ np.sum(matrix[indice])) != 0:
                        user_cal = round((float(raw_diagonal[indice]) / np.sum(matrix[indice])), 4)
                        user_accuracy.append(user_cal*100)
                    else:
                        user_accuracy.append(0)
                except ZeroDivisionError:
                    QMessageBox.information(cfg.uidc, u'警告', u'存在被除数为0的情况！！！')
                    user_accuracy.append(0)
                try:
                    # Calculate producer accuracy
                    if  np.sum(matrix[indice]) != 0 and (float(raw_diagonal[indice]) / np.sum(matrix[indice])) != 0:
                        prod_cal = round((float(raw_diagonal[indice]) / np.sum(matrix, axis=0)[indice]), 4)
                        prod_accuracy.append(prod_cal*100)
                    else:
                        prod_accuracy.append(0)
                except ZeroDivisionError:
                    QMessageBox.information(cfg.uidc, u'警告', u'存在被除数为0的情况！！！')
                    prod_accuracy.append(0)
            writer_csv.writerows(np.c_[np.c_[unique_class, adjusted_matrix],user_accuracy])
            writer_csv.writerow(np.append(u"PA(%)", prod_accuracy))
            writer_csv.writerows([""])
            writer_csv.writerow(np.append(u"OA(%)", [raw_OverAllAccuracy*100]))
            writer_csv.writerow(np.append(u"KAPPA", [round(kappa(matrix),4)]))
            # Close CSV file
            csv_matrix.close()
            # Remove from table of contents the intersect layer
            remove_layer = QgsMapLayerRegistry.instance().removeMapLayer(layer_inter.id())
            # Delete temporal files
            temp_files = [".dbf", ".prj", ".qpj", ".shp", ".shx"]
            for temp_file in temp_files:
                os.remove(filename + temp_file)
            QgsApplication.processEvents()
            cfg.uiUtls.updateBar(100)
            cfg.uiUtls.removeProgressBar()
            QMessageBox.information(cfg.uidc, u'access',u'success！！！')
            # Displays an error message if the parameters are incorrect
        elif filename == "":
            QMessageBox.critical(cfg.uidc, QCoreApplication.translate('Error', "Error"),
                                 QCoreApplication.translate('Error',
                                                            "Error try again, make sure of give all parameters"))
        elif ref_layer.type() == QgsMapLayer.VectorLayer and comp_layer.type() == QgsMapLayer.RasterLayer:
            QMessageBox.critical(cfg.uidc, QCoreApplication.translate('Error', "Error"),
                                 QCoreApplication.translate('Error',
                                                            "Error try again, please, make sure of use two raster files or two shapefiles."))
        elif ref_layer.type() == QgsMapLayer.RasterLayer and comp_layer.type() == QgsMapLayer.VectorLayer:
            QMessageBox.critical(cfg.uidc, QCoreApplication.translate('Error', "Error"),
                                 QCoreApplication.translate('Error',
                                                            "Error try again, please, make sure of use two raster files or two shapefiles."))
        else:
            pass

###############accuary_access#####################
