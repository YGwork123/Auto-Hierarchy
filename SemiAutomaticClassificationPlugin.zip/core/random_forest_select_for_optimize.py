# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
def every_node_sample(n,B,nrow,node):
    for i in range(0,nrow):
        if node.iat[i,0] in B:
            node.iat[i,1] = (n+1)*10+1
        else:
            node.iat[i,1] = (n+1)*10+2
    new_node_z = node.loc[node['class_split'] == (n+1)*10+1, :].copy()
    new_node_y = node.loc[node['class_split'] == (n+1)*10+2, :].copy()
    new_nodes = (new_node_z,new_node_y,node)
    return new_nodes

def is_include(a,A):
    for i in range(0,len(a)):
        if a[i] not in A:
            return False
    return True

def split_varibles_class(sample_path):
    url1 = pd.read_csv(sample_path, header=0)
    varibles_class = url1.iloc[0,1:].values
    return varibles_class
def pub_split_nodes(sample_path,n,A):
    url1 = pd.read_csv(sample_path, header=0)
    node1 = url1.copy()
    node1.insert(1, 'class_split', 0)
    nodes = []
    #nodes_indicat = np.zeros([n],dtype = int)
    #nodes_indicat[0] = 1
    # judge_tree = TreeNode(np.unique(node1.iloc[:,0].values))
    # start_judge_tree = judge_tree
    # judge_tree.be_travel = True
    istravel = np.zeros((n,2),dtype=np.int)
    for i in range(1,n+1):
        new_node_z = every_node_sample(i,A[i-1],node1.shape[0],node1)[0].copy()
        new_node_y = every_node_sample(i,A[i-1],node1.shape[0],node1)[1].copy()
        node1 = every_node_sample(i,A[i-1],node1.shape[0],node1)[2].copy()
        nodes.append(node1.copy())
        if is_include(A[i-1],np.unique(new_node_z.iloc[:,0].values)):
            if(i<n):
                if is_include(A[i],np.unique(new_node_z.iloc[:,0].values)):
                    node1 = new_node_z.copy()
                    istravel[i-1][0] = 1
                else:
                    j = 0
                    while (j < i):
                        if istravel[j][0] == 0 and is_include(A[i],np.unique(nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, :].copy()
                            istravel[j][0] = 1
                            break
                        elif istravel[j][1] == 0 and is_include(A[i],np.unique(nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, :].copy()
                            istravel[j][1] = 1
                            break
                        j = j + 1
            #nodes_indicat[i] = 1
            # judge_tree.left.be_travel = True
            # judge_tree = judge_tree.left
        elif is_include(A[i-1],np.unique(new_node_y.iloc[:,0].values)):
            #判断是否为叶子结点
            if(i<n):
                if is_include(A[i],np.unique(new_node_y.iloc[:,0].values)):
                    node1 = new_node_y.copy()
                    istravel[i][1] = 0
                else:
                    j = 0
                    while (j < i):
                        if istravel[j][0] == 0 and is_include(A[i],np.unique(nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, :].copy()
                            istravel[j][0] = 1
                            break
                        elif istravel[j][1] == 0 and is_include(A[i],np.unique(nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, :].copy()
                            istravel[j][1] = 1
                            break
                        j = j+1
    return nodes


def hierarchy_class_sample(pd_node_z,split_value):
    class_name_z = np.unique(pd_node_z.loc[:,'class_name'])
    all_class_training = None
    all_class_verify = None
    for i in range(0,len(class_name_z)):
        every_class_pd = pd_node_z.loc[pd_node_z['class_name'] == class_name_z[i],:]
        split_break = int(every_class_pd.shape[0]*float(split_value))
        every_class_training = every_class_pd.iloc[0:split_break,:]
        every_class_verify = every_class_pd.iloc[split_break+1:every_class_pd.shape[0],:]
        all_class_training = pd.concat([all_class_training, every_class_training], axis=0, ignore_index=True)
        all_class_verify = pd.concat([all_class_verify,every_class_verify],axis=0,ignore_index=True)
    return all_class_training,all_class_verify




def split_samples(sample_path,n,A,split_value):
    nodes = pub_split_nodes(sample_path,n,A)
    traning_samples = []
    verify_samples = []
    node_columns = nodes[0].columns
    for i in range(0,n):
        np_node = nodes[i].values
        pd_node = np.random.permutation(np_node)
        pd_node = pd.DataFrame(pd_node)
        pd_node.columns = node_columns
        pd_node[['class_name', 'class_split']] = pd_node[['class_name','class_split']].astype(int)
        ###########################add###############################
        pd_node_z = pd_node.loc[pd_node['class_split'] == (i + 2) * 10 + 1,:]
        pd_node_y = pd_node.loc[pd_node['class_split'] == (i + 2) * 10 + 2,:]
        # split_break_z = int(pd_node_z.shape[0]*split_value)
        # split_break_y = int(pd_node_y.shape[0]*split_value)
        # traning_node_z = pd_node_z.iloc[0:split_break_z, :]
        # traning_node_y = pd_node_y.iloc[0:split_break_y, :]
        # verify_sample_z = pd_node_z.iloc[split_break_z:pd_node_z.shape[0],:]
        # verify_sample_y = pd_node_y.iloc[split_break_y:pd_node_y.shape[0],:]
        (traning_node_z_new,verify_node_z_new) = hierarchy_class_sample(pd_node_z,split_value)
        (traning_node_y_new,verify_node_y_new) = hierarchy_class_sample(pd_node_y,split_value)
        df_training = pd.concat([traning_node_z_new, traning_node_y_new], axis=0, ignore_index=True)
        df_verify = pd.concat([verify_node_z_new, verify_node_y_new], axis=0, ignore_index=True)
        ###########################add###############################
        # split_break = int(nodes[i].shape[0]*0.7)
        # traning_node = pd_node.iloc[0:split_break, :]
        # traning_samples.append(traning_node)
        # verify_samples.append(pd_node.iloc[split_break:nodes[i].shape[0], :])
        traning_samples.append(df_training)
        verify_samples.append(df_verify)
    ####################balanced#####################
    # balance_training_samples = []
    # balance_training_samples.append(traning_samples[0])
    # n_training_node = traning_samples[0].shape[0]
    # for j in range(1,n):
    #     balance_training_node = traning_samples[j].copy()
    #     consult_training = n_training_node/traning_samples[j].shape[0]
    #     remainder_training = n_training_node % traning_samples[j].shape[0]
    #     for k in range(0,(consult_training-1)):
    #         balance_training_node = pd.concat([balance_training_node,traning_samples[j]]).copy()
    #     remain_node = traning_samples[j].iloc[0:remainder_training,:].copy()
    #     balance_training_node = pd.concat([balance_training_node,remain_node]).copy()
    #     balance_training_samples.append(balance_training_node)
    return (traning_samples,verify_samples)

def get_lastnodes(sample_path,n,A):
    url1 = pd.read_csv(sample_path, header=0)
    node1 = url1.copy()
    node1.insert(1, 'class_split', 0)
    nodes = []
    lastnodes = np.zeros([n],dtype=np.int)
    istravel = np.zeros((n,2),dtype=np.int)
    for i in range(1,n+1):
        new_node_z = every_node_sample(i,A[i-1],node1.shape[0],node1)[0].copy()
        new_node_y = every_node_sample(i,A[i-1],node1.shape[0],node1)[1].copy()
        node1 = every_node_sample(i,A[i-1],node1.shape[0],node1)[2].copy()
        # judge_tree.left = TreeNode(np.unique(new_node_z.iloc[:,0].values))
        # judge_tree.right = TreeNode(np.unique(new_node_y.iloc[:,0].values))
        nodes.append(node1.copy())
        if is_include(A[i-1],np.unique(new_node_z.iloc[:,0].values)):
            if(i<n):
                if is_include(A[i],np.unique(new_node_z.iloc[:,0].values)):
                    node1 = new_node_z.copy()
                    istravel[i-1][0] = 1
                    if i > 0 and i < n:
                        lastnodes[i] = (i+1)*10+1
                else:
                    j = 0
                    while (j < i):
                        if istravel[j][0] == 0 and is_include(A[i],np.unique(nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, :].copy()
                            istravel[j][0] = 1
                            lastnodes[i] = (j + 2) * 10 + 1
                            break
                        elif istravel[j][1] == 0 and is_include(A[i],np.unique(nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, :].copy()
                            istravel[j][1] = 1
                            lastnodes[i] = (j + 2) * 10 + 2
                            break
                        j = j + 1
            #nodes_indicat[i] = 1
            # judge_tree.left.be_travel = True
            # judge_tree = judge_tree.left
        elif is_include(A[i-1],np.unique(new_node_y.iloc[:,0].values)):
            #判断是否为叶子结点
            if(i<n):
                if is_include(A[i],np.unique(new_node_y.iloc[:,0].values)):
                    node1 = new_node_y.copy()
                    istravel[i][1] = 0
                    if i > 0 and i < n:
                        lastnodes[i] = (i+1)*10+2
                else:
                    j = 0
                    while (j < i):
                        if istravel[j][0] == 0 and is_include(A[i],np.unique(nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 1, :].copy()
                            istravel[j][0] = 1
                            lastnodes[i] = (j + 2) * 10 + 1
                            break
                        elif istravel[j][1] == 0 and is_include(A[i],np.unique(nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, 'class_name'])):
                            node1 = nodes[j].loc[nodes[j]['class_split'] == (j + 2) * 10 + 2, :].copy()
                            istravel[j][1] = 1
                            lastnodes[i] = (j + 2) * 10 + 2
                            break
                        j = j+1
    return lastnodes


def  rf_select_best_variables_for_op(training_nodes,verify_nodes,sample_path):
    test_class_name = []
    varibles_class = split_varibles_class(sample_path)
    url1 =training_nodes[0].copy()
    url2 = verify_nodes[0].copy()
    n = len(training_nodes)
    #x为自变量y为因变量
    node_variables = []
    verify_varibles = []
    for k in range(0, n):
        x, y = training_nodes[k].iloc[:, 2:], training_nodes[k].iloc[:, 1]
        test_class_name.append(y)
        #feat_labels = url1.columns[1:]
        feat_labels = training_nodes[k].columns[2:].values
        # n_estimators：森林中树的数量
        # n_jobs  整数 可选（默认=1） 适合和预测并行运行的作业数，如果为-1，则将作业数设置为核心数
        forest = RandomForestClassifier(n_estimators=2000, random_state=0, n_jobs=-1)
        #forest.fit(x_train, y_train)
        forest.fit(x,y)
        #下面对训练好的随机森林完成重要性评估
        importances = forest.feature_importances_
        #取出除去第一列的所有变量名
        # x_columns = training_nodes[k].columns[1:]
        #argsort函数返回的是数组从小到大的索引值
        #[::-1]表示去除数组中全部元素并按倒序排列，这样的话indices数组里存储的便是数组从大到小的索引值
        indices = np.argsort(importances)[::-1]
        # for f in range(x.shape[1]):
        #     #对于最后需要逆序排序，我认为是做了类似决策树回溯的取值，从叶子收敛
        #     #到根，根部重要程度高于叶子。
        #筛选变量(筛选重要性比较高的变量)
        x_selected_fields = feat_labels[indices[:]]
        x_selected = url1[x_selected_fields]
        #add对变量等级进行重新排序
        selected_varibles_class = varibles_class[indices[:]]
        #用选出来的变量做相关性分析
        person_varibles = np.corrcoef(x_selected,rowvar=0)
        # person_varibles = pearsonr(x_selected)
        # x_selected_test = x_selected.iloc[:,:]
        # x_corref = np.corrcoef(x_selected_test)
        #去除相关性大于0.8的变量
        for i in range(0, len(x_selected_fields)):
            for j in range(0, i):
                if abs(person_varibles[i][j]) > 0.9:
                    if i < j:
                        if x_selected_fields[j] in x_selected.columns.values:
                            x_selected = x_selected.drop(columns=x_selected_fields[j])
                            selected_varibles_class[j] = 0
                    else:
                        if x_selected_fields[i] in x_selected.columns.values:
                            x_selected = x_selected.drop(columns=x_selected_fields[i])
                            selected_varibles_class[i] = 0
        final_selected = x_selected.iloc[:, 0:8].copy()
        selected_for_random = training_nodes[k][final_selected.columns.values].copy()
        verify_selected = verify_nodes[k][final_selected.columns.values].copy()
        node_variables.append(selected_for_random)
        verify_varibles.append(verify_selected)
    return (node_variables,verify_varibles,test_class_name)

def creat_tests(training_nodes,verify_nodes,last_nodes,A):
    # url1 = pd.read_csv(sample_path, header=0)
    # node1 = url1.copy()
    # node1 = split_samples(sample_path,n,A)
    n = len(training_nodes)
    node1 = training_nodes[0].iloc[:,0:3].copy()
    node2 = verify_nodes[0].iloc[:,0:3].copy()
    training_tests = []
    training_tests.append(node1.copy())
    verify_tests = []
    verify_tests.append(node2.copy())
    for j in range(2,n+1):
        for i in range(0, node1.shape[0]):
            if node1.iat[i,1] == last_nodes[j-1]:
                if node1.iat[i, 0] in A[j-1]:
                    node1.iat[i, 1] = (j + 1) * 10 + 1
                else:
                    node1.iat[i, 1] = (j + 1) * 10 + 2
        for i in range(0, node2.shape[0]):
            if node2.iat[i,1] == last_nodes[j-1]:
                if node2.iat[i, 0] in A[j-1]:
                    node2.iat[i, 1] = (j + 1) * 10 + 1
                else:
                    node2.iat[i, 1] = (j + 1) * 10 + 2
        training_tests.append(node1.copy())
        verify_tests.append(node2.copy())
    return (training_tests,verify_tests)






