# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'TreeClassSelect.ui'
#
# Created: Wed Dec 04 16:49:42 2019
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName(_fromUtf8("Form"))
        Form.resize(541, 553)
        self.horizontalLayoutWidget_4 = QtGui.QWidget(Form)
        self.horizontalLayoutWidget_4.setGeometry(QtCore.QRect(10, 30, 511, 431))
        self.horizontalLayoutWidget_4.setObjectName(_fromUtf8("horizontalLayoutWidget_4"))
        self.horizontalLayout_4 = QtGui.QHBoxLayout(self.horizontalLayoutWidget_4)
        self.horizontalLayout_4.setMargin(0)
        self.horizontalLayout_4.setObjectName(_fromUtf8("horizontalLayout_4"))
        self.groupBox_3 = QtGui.QGroupBox(self.horizontalLayoutWidget_4)
        self.groupBox_3.setObjectName(_fromUtf8("groupBox_3"))
        self.avaliable_class_list = QtGui.QListWidget(self.groupBox_3)
        self.avaliable_class_list.setGeometry(QtCore.QRect(10, 20, 231, 391))
        self.avaliable_class_list.setObjectName(_fromUtf8("avaliable_class_list"))
        self.horizontalLayout_4.addWidget(self.groupBox_3)
        self.groupBox_4 = QtGui.QGroupBox(self.horizontalLayoutWidget_4)
        self.groupBox_4.setObjectName(_fromUtf8("groupBox_4"))
        self.select_class_list = QtGui.QListWidget(self.groupBox_4)
        self.select_class_list.setGeometry(QtCore.QRect(10, 20, 231, 391))
        self.select_class_list.setObjectName(_fromUtf8("select_class_list"))
        self.horizontalLayout_4.addWidget(self.groupBox_4)
        self.horizontalLayoutWidget_3 = QtGui.QWidget(Form)
        self.horizontalLayoutWidget_3.setGeometry(QtCore.QRect(110, 470, 311, 41))
        self.horizontalLayoutWidget_3.setObjectName(_fromUtf8("horizontalLayoutWidget_3"))
        self.horizontalLayout_3 = QtGui.QHBoxLayout(self.horizontalLayoutWidget_3)
        self.horizontalLayout_3.setMargin(0)
        self.horizontalLayout_3.setObjectName(_fromUtf8("horizontalLayout_3"))
        self.pushButtonOk = QtGui.QPushButton(self.horizontalLayoutWidget_3)
        self.pushButtonOk.setObjectName(_fromUtf8("pushButtonOk"))
        self.horizontalLayout_3.addWidget(self.pushButtonOk)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_3.addItem(spacerItem)
        self.pushButtonCancel = QtGui.QPushButton(self.horizontalLayoutWidget_3)
        self.pushButtonCancel.setObjectName(_fromUtf8("pushButtonCancel"))
        self.horizontalLayout_3.addWidget(self.pushButtonCancel)

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        Form.setWindowTitle(_translate("Form", "Form", None))
        self.groupBox_3.setTitle(_translate("Form", "可用树种", None))
        self.groupBox_4.setTitle(_translate("Form", "选择的树种", None))
        self.pushButtonOk.setText(_translate("Form", "确定", None))
        self.pushButtonCancel.setText(_translate("Form", "取消", None))

