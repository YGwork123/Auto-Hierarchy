# -*- coding: utf-8 -*-
"""
/***************************************************************************
 HierarchicalClassifierDialog
                                 A QGIS plugin
 This plugin classifies artificial forests by tree species.
                             -------------------
        begin                : 2019-01-17
        git sha              : $Format:%H$
        copyright            : (C) 2019 by FJNU
        email                : YGwork123@163.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from ui_semiautomaticclassificationplugin_dock_class import Ui_DockClass
from PyQt4 import QtGui,QtCore
from qgis.gui import *
from PyQt4.QtCore import *
from PyQt4.QtGui import *
#from SemiAutomaticClassificationPlugin.ui.about_dialog import AboutDialog
# from qgis.core import *
# import os
#from TreeClassInit import TreeClassInit
# FORM_CLASS, _ = uic.loadUiType(os.path.join(
#     os.path.dirname(__file__), 'hierachical_classifier_dialog_base.ui'))


try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s
try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class ClassificationDock_Init(QDockWidget,Ui_DockClass):
    def __init__(self,parent=None):
        """Constructor."""
        super(ClassificationDock_Init, self).__init__(parent)
        # self.about_dialog = AboutDialog()
        self.button = None
        self.setupUi(self)
        # self.pButtonHelp.clicked.connect(self.about_dialog.show)

        # #widgets-and-dialogs-with-auto-connect
    ##############################add_tree_class_modle#########################
    def get_tree_height(self, button):
        i = 0
        if button.left_button != None:
            temp = self.get_tree_height(button.left_button)
            i = temp if temp > i else i
        if button.right_button != None:
            temp = self.get_tree_height(button.right_button)
            i = temp if temp > i else i
        return i + 1

    def get_tree_width(self, button):
        if button.left_button == None and button.right_button == None:
            return 1
        else:
            right = 0
            left = 0
            if button.left_button != None:
                left = self.get_tree_height(button.left_button)
            if button.right_button != None:
                right = self.get_tree_height(button.right_button)
        return left + right

    def draw_tree(self, button, leaflet_pos=None, i=0):
        if leaflet_pos is None:
            leaflet_pos = [0]
        left_Position = 0
        right_Position = 0
        if button.left_button != None:
            left_Position = self.draw_tree(button.left_button, leaflet_pos, i + 1)
        if button.right_button != None:
            right_Position = self.draw_tree(button.right_button, leaflet_pos, i + 1)
        if button.left_button == None and button.right_button == None:
            button.set_button_center(leaflet_pos[0] * 80 + 20, i * 40 + 20)
            leaflet_pos[0] += 1
        else:
            button.set_button_center((left_Position + right_Position) / 2, i * 40 + 20)
        return button.center_left

    def refresh(self):
        self.height_size = self.get_tree_height(self.button)
        self.width_size = self.get_tree_width(self.button)
        self.tree_width = (self.width_size + 1) * 80
        self.tree_height = (self.height_size + 1) * 40
        self.widget_class_modle.setMinimumHeight(self.tree_height)
        self.widget_class_modle.setMinimumWidth(self.tree_width)
        self.draw_tree(self.button)
        pass
    ###################################################################
    # ###############accuary_access#####################
    # def showFileSelectDialog(self):
    #     fname = QFileDialog.getSaveFileName(cfg.uidc, 'Save File', os.path.expanduser('~'))
    #     cfg.uidc.outFileLineEdit.setText(fname)
    #
    # def initLayerCombobox(self, combobox, default):
    #     combobox.clear()
    #     reg = QgsMapLayerRegistry.instance()
    #     for (key, layer) in reg.mapLayers().iteritems():
    #
    #         if layer.type() == QgsMapLayer.RasterLayer or layer.type() == QgsMapLayer.VectorLayer:  # This doesn't work in QGIS2.0. Can I do without?: and ( layer.usesProvider() and layer.providerKey() == 'gdal' ):
    #             combobox.addItem(layer.name(), key)
    #
    #     idx = combobox.findData(default)
    #     if idx != -1:
    #         combobox.setCurrentIndex(idx)
    #
    # def layerFromComboBox(self, combobox):
    #     layerID = str(combobox.itemData(combobox.currentIndex()))
    #     return QgsMapLayerRegistry.instance().mapLayer(layerID)
    #
    # ###############accuary_access#####################





class new_button(QtGui.QPushButton):
    #@QtCore.pyqtSlot()
    def __init__(self,widget = None,tree_Form = None):
        super(new_button, self).__init__(widget)
        self.tree_Form = tree_Form
        self.left_button = None
        self.widget = widget
        self.right_button = None
        self.show()

        # self.parent=parent
        self.hovered = False
        self.pressed = False
        # self.count = 0
        self.class_list = []
        self.createContextMenu()

    def new_children(self):
        self.left_button = new_button(self.widget,tree_Form = self.tree_Form)
        self.left_button.set_button_center(self.center_left - 40,self.center_top + 20)
        self.right_button = new_button(self.widget,tree_Form = self.tree_Form)
        self.right_button.set_button_center(self.center_left + 40,self.center_top + 20)
        self.tree_Form.refresh()

    def set_button_center(self,center_left,center_top):
        self.setGeometry(QtCore.QRect(center_left-20, center_top-10, 40, 20))
        self.center_top = center_top
        self.center_left = center_left

    def createContextMenu(self):
        # 必须将ContextMenuPolicy设置为Qt.CustomContextMenu
        # 否则无法使用customContextMenuRequested信号
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.showContextMenu)
        # 创建QMenu
        self.contextMenu = QMenu(self)
        self.actionA = self.contextMenu.addAction(u'| 添加子节点')
        self.actionB = self.contextMenu.addAction(u'| 删除子节点')
        self.actionC = self.contextMenu.addAction(u'| 编辑树种类别')
        # 添加二级菜单
        self.second = self.contextMenu.addMenu(u"| 二级菜单")
        self.actionD = self.second.addAction(u'| 动作A')
        self.actionE = self.second.addAction(u'| 动作B')
        self.actionF = self.second.addAction(u'| 动作C')
        # 将动作与处理函数相关联
        # 这里为了简单，将所有action与同一个处理函数相关联，
        # 当然也可以将他们分别与不同函数关联，实现不同的功能
        self.actionA.triggered.connect(self.new_children)
        self.actionC.triggered.connect(self.edit_class)

    def showContextMenu(self, pos):
        # self.count += 1
        # 菜单显示前，将它移动到鼠标点击的位置
        self.contextMenu.exec_(QCursor.pos())  # 在鼠标位置显示
        self.contextMenu.show()



    def edit_class(self):
        #self.contextMenu.close()
        # if self.class_list == []:
        #     self.class_list = self.tree_Form.TreeClassSelectdlg.child_paraList
        self.tree_Form.TreeClassSelectdlg.removeAll()
        QMessageBox.information(None, "   ", str(self.class_list))
        self.tree_Form.TreeClassSelectdlg.setPara(paraList = self.class_list,child_paraList_left=self.left_button.class_list
                                                  if self.left_button!=None else None,child_paraList_right=self.right_button.class_list)
        self.tree_Form.TreeClassSelectdlg.show()



