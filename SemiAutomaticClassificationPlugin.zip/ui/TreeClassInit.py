from PyQt4.QtGui import QDialog
from qgis.PyQt import QtCore

from TreeClassSelect import Ui_Form


class TreeClassInit(Ui_Form,QDialog):
    childcliked = QtCore.pyqtSignal(str)
    def __init__(self,parent = None):
        super(TreeClassInit, self).__init__(parent)
        self.setupUi(self)
        self.parent = parent
        # self.class_list = class_list
        self.avaliable_class_list.itemDoubleClicked.connect(self.doubleClickTreeClassItem)
        self.select_class_list.itemDoubleClicked.connect(self.doubleClickSelectClassItem)
        # self.setPara(paraList=self.class_list)
        self.pushButtonOk.clicked.connect(self.ensure)
        self.pushButtonCancel.clicked.connect(self.quit)

    def doubleClickTreeClassItem(self):
        self.select_class_list.addItem(str(self.avaliable_class_list.currentItem().text()))
        self.avaliable_class_list.takeItem(self.avaliable_class_list.currentRow())
        self.select_class_list.sortItems()

    def doubleClickSelectClassItem(self):
        self.avaliable_class_list.addItem(str(self.select_class_list.currentItem().text()))
        self.select_class_list.takeItem(self.select_class_list.currentRow())
        self.avaliable_class_list.sortItems()

    def quit(self):
        self.removeAll()
        self.hide()
        pass


    def ensure(self):
        [self.child_paraList_left.append(int(self.select_class_list.item(i).text())) for i in range(self.select_class_list.count())]
        # QMessageBox.information(None,str(self.select_class_list.count()),str(self.child_paraList))
        [self.child_paraList_right.append(int(self.avaliable_class_list.item(i).text())) for i in range(self.avaliable_class_list.count())]

        # self.tree_Form.TreeClassSelectdlg.setPara(paraList = self.class_list, child_paraList = self.left_button.class_list)
        # self.tree_Form.TreeClassSelectdlg.setPara(paraList=self.class_list, child_paraList=self.right_button.class_list)

        self.removeAll()
        self.hide()

    def removeAll(self):
        for i in range(0,self.avaliable_class_list.count()):
            self.avaliable_class_list.takeItem(0)
        for i in range(0, self.select_class_list.count()):
            self.select_class_list.takeItem(0)


    def setPara(self,paraList = [],child_paraList_left = [],child_paraList_right = []):
        self.child_paraList_left = child_paraList_left
        self.child_paraList_right = child_paraList_right
        [self.avaliable_class_list.addItem(str(s)) for s in paraList]


